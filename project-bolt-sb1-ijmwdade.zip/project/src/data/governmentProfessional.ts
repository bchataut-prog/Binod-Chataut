import type { ResumeData } from '../types/resume';

export const governmentProfessionalData: ResumeData = {
  personalInfo: {
    fullName: 'Jennifer L. Okonkwo',
    title: 'Development Program Coordinator',
    email: 'jennifer.okonkwo@email.gov',
    phone: '(202) 555-1056',
    location: 'Washington, DC',
    linkedin: 'linkedin.com/in/jenniferokonkwo'
  },
  summary: 'International Development Professional with 10 years of experience designing, managing, and evaluating programs across Africa, Asia, and Latin America. Expert in USAID regulations, stakeholder coordination, and results-based management. Successfully managed $85M in development programming in health, education, and economic growth sectors with demonstrated impact on 2.5M+ beneficiaries.',
  experience: [
    {
      id: '1',
      title: 'Development Program Coordinator',
      company: 'United States Agency for International Development (USAID)',
      location: 'Washington, DC',
      startDate: '2020',
      endDate: 'Present',
      current: true,
      highlights: [
        'Manage $35M Health Systems Strengthening portfolio across 8 countries in Sub-Saharan Africa',
        'Lead interagency coordination with State Department, CDC, and implementing partners',
        'Designed innovative public-private partnership mobilizing $12M in co-investment',
        'Oversaw evaluation of 15 programs resulting in evidence-based portfolio adjustments',
        'Represented USAID at international conferences and donor coordination meetings',
        'Managed team of 4 program officers and provided technical guidance to 12 implementing partners'
      ]
    },
    {
      id: '2',
      title: 'Program Management specialist',
      company: 'United States Agency for International Development (USAID) - Nigeria',
      location: 'Abuja, Nigeria',
      startDate: '2017',
      endDate: '2020',
      highlights: [
        'Managed $28M economic growth program supporting 450,000 smallholder farmers',
        'Led implementation of Feed the Future initiative in 12 Nigerian states',
        'Coordinated with Nigerian government ministries on policy reforms for agricultural markets',
        'Established monitoring system improving data quality scores from 65% to 92%',
        'Facilitated $8M in private sector partnerships for agricultural value chain development'
      ]
    },
    {
      id: '3',
      title: 'Program Officer',
      company: 'U.S. Peace Corps',
      location: 'Washington, DC',
      startDate: '2014',
      endDate: '2017',
      highlights: [
        'Designed and managed community development programs in 15 countries',
        'Trained 200+ Peace Corps volunteers in program design and monitoring',
        'Developed partnership framework with 30 international NGOs',
        'Managed $5M grant portfolio for youth development initiatives'
      ]
    }
  ],
  education: [
    {
      id: '1',
      degree: 'Master of International Development',
      field: 'Development Policy & Management',
      institution: 'Georgetown University, Walsh School of Foreign Service',
      location: 'Washington, DC',
      graduationDate: '2014',
      gpa: '3.88/4.0'
    },
    {
      id: '2',
      degree: 'Bachelor of Arts',
      field: 'International Relations & Economics',
      institution: 'University of California, Los Angeles',
      location: 'Los Angeles, CA',
      graduationDate: '2010',
      gpa: '3.72/4.0',
      honors: ['Dean\'s List', 'Departmental Honors']
    }
  ],
  skills: [
    { name: 'Program Design & Management', level: 'expert' },
    { name: 'USAID Regulations & Compliance', level: 'expert' },
    { name: 'Results-Based Management', level: 'expert' },
    { name: 'Monitoring & Evaluation', level: 'expert' },
    { name: 'Stakeholder Coordination', level: 'expert' },
    { name: 'Budget & Financial Management', level: 'advanced' },
    { name: 'Grant Management', level: 'expert' },
    { name: 'Policy Analysis', level: 'advanced' },
    { name: 'Cross-Cultural Communication', level: 'expert' },
    { name: 'Technical Writing & Reporting', level: 'expert' }
  ],
  certifications: [
    { id: '1', name: 'Project Management Professional (PMP)', issuer: 'Project Management Institute', date: '2019', credentialId: 'PMP-1985624' },
    { id: '2', name: 'USAID Acquisition & Assistance Certifications', issuer: 'USAID', date: '2018' },
    { id: '3', name: 'Data for Development Professional Certificate', issuer: 'World Bank Group', date: '2021' }
  ],
  projects: [
    {
      id: '1',
      name: 'Health Systems Strengthening Initiative',
      description: 'Multi-country program strengthening primary healthcare delivery systems.',
      highlights: ['Reached 1.2M beneficiaries', 'Trained 3,500 health workers', 'Improved immunization rates by 24%']
    },
    {
      id: '2',
      name: 'Agricultural Value Chain Development Program',
      description: 'Market systems approach connecting smallholder farmers to commercial markets.',
      highlights: ['Increased farmer incomes by 45%', 'Established 28 farmer cooperatives', 'Created 12,000 jobs']
    }
  ],
  achievements: [
    { id: '1', title: 'USAID Meritorious Honor Award', description: 'Recognition for exceptional leadership during pandemic response programming', date: '2021' },
    { id: '2', title: 'Peace Corps Outstanding Service Award', description: 'For contributions to program innovation', date: '2016' },
    { id: '3', title: 'Senior Foreign Service Selection', description: 'Selected for Senior Foreign Service cohort', date: '2023' }
  ],
  languages: [
    { name: 'English', proficiency: 'native' },
    { name: 'French', proficiency: 'fluent' },
    { name: 'Spanish', proficiency: 'professional' },
    { name: 'Hausa', proficiency: 'conversational' }
  ],
  memberships: [
    { id: '1', organization: 'Society for International Development', role: 'Chapter Board Member', startDate: '2018', current: true },
    { id: '2', organization: 'Association of Professional Women in Development', startDate: '2016', current: true },
    { id: '3', organization: 'American Evaluation Association', startDate: '2015', current: true }
  ],
  volunteer: [
    {
      id: '1',
      role: 'Mentor',
      organization: 'Pickering Foreign Affairs Fellowship Program',
      location: 'Washington, DC',
      startDate: '2020',
      current: true,
      description: 'Mentor underrepresented students pursuing careers in international development and foreign affairs'
    },
    {
      id: '2',
      role: 'Board Member',
      organization: 'Girls Education Initiative',
      location: 'Washington, DC',
      startDate: '2019',
      current: true,
      description: 'Support organization providing scholarships to girls in Sub-Saharan Africa'
    }
  ],
  references: [
    { id: '1', name: 'Ambassador Thomas Richardson', title: 'Former Assistant Administrator', company: 'USAID Bureau for Africa', email: 't.richardson@state.gov', phone: '(202) 555-0100' },
    { id: '2', name: 'Dr. Fatima Ahmed', title: 'Country Director', company: 'CARE International - Nigeria', email: 'f.ahmed@care.org' }
  ]
};
