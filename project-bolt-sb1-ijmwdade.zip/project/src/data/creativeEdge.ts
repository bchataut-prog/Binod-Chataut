import type { ResumeData } from '../types/resume';

export const creativeEdgeData: ResumeData = {
  personalInfo: {
    fullName: 'Sofia Martinez-Clark',
    title: 'Creative Director',
    email: 'sofia.martinez.clark@email.com',
    phone: '(310) 555-2398',
    location: 'Los Angeles, CA',
    website: 'www.sofiamartinez.design',
    linkedin: 'linkedin.com/in/sofiamartinezdesign',
    photo: 'https://images.pexels.com/photos/3764119/pexels-photo-3764119.jpeg?auto=compress&cs=tinysrgb&w=300'
  },
  summary: 'Award-winning Creative Director with 12 years of experience crafting brand identities, digital experiences, and advertising campaigns for Fortune 500 clients and innovative startups. Expert in building and leading cross-functional creative teams, developing comprehensive brand strategies, and delivering measurable business outcomes. Recipient of 25+ industry awards including Cannes Lions, Clios, and Webby Awards.',
  experience: [
    {
      id: '1',
      title: 'Creative Director',
      company: 'R/GA',
      location: 'Los Angeles, CA',
      startDate: '2020',
      endDate: 'Present',
      current: true,
      highlights: [
        'Lead creative strategy and execution for Nike, Google, and Samsung accounts representing $15M annual revenue',
        'Built and directed team of 28 creatives including art directors, copywriters, and experience designers',
        'Developed Nike Metaverse campaign achieving 450M impressions and 3 Cannes Lions awards',
        'Redesigned Google Pixel brand identity resulting in 28% increase in brand consideration scores',
        'Pioneered inclusive design practice adopted across 5 global R/GA offices',
        'Mentored 12 junior creatives with 100% promotion rate to senior roles'
      ]
    },
    {
      id: '2',
      title: 'Associate Creative Director',
      company: 'Wieden+Kennedy',
      location: 'Portland, OR',
      startDate: '2016',
      endDate: '2020',
      highlights: [
        'Led creative team on Old Spice account developing viral campaigns with 200M+ views',
        'Directed brand identity overhaul achieving 40% increase in brand recognition metrics',
        'Conceptualized and executed award-winning Super Bowl campaign ranked #1 USA Today Ad Meter',
        'Presented creative concepts to CMOs and brand stakeholders winning $8M in new business',
        'Established internship program advancing 15 individuals to full-time creative roles'
      ]
    },
    {
      id: '3',
      title: 'Senior Art Director',
      company: 'Mother Los Angeles',
      location: 'Los Angeles, CA',
      startDate: '2012',
      endDate: '2016',
      highlights: [
        'Created visual identities and campaigns for Netflix, Tesla, and Slack',
        'Developed Tesla Model 3 launch campaign generating 400,000 pre-orders in 48 hours',
        'Built content creation process reducing production timelines by 60%',
        'Art directed photo and video shoots with budgets up to $2M'
      ]
    }
  ],
  education: [
    {
      id: '1',
      degree: 'Master of Fine Arts (MFA)',
      field: 'Graphic Design',
      institution: 'Rhode Island School of Design',
      location: 'Providence, RI',
      graduationDate: '2012',
      honors: ['Thesis awarded Gold ADDY']
    },
    {
      id: '2',
      degree: 'Bachelor of Fine Arts (BFA)',
      field: 'Visual Communication',
      institution: 'Parsons School of Design',
      location: 'New York, NY',
      graduationDate: '2009',
      gpa: '3.85/4.0',
      honors: ['Summa Cum Laude', 'Design Excellence Award']
    }
  ],
  skills: [
    { name: 'Brand Strategy & Identity', level: 'expert' },
    { name: 'Creative Direction', level: 'expert' },
    { name: 'Art Direction', level: 'expert' },
    { name: 'Campaign Development', level: 'expert' },
    { name: 'Visual Design Systems', level: 'expert' },
    { name: 'User Experience Design', level: 'advanced' },
    { name: 'Motion Graphics', level: 'advanced' },
    { name: 'Figma & Adobe Creative Suite', level: 'expert' },
    { name: 'Presentation & Storytelling', level: 'expert' },
    { name: 'Team Leadership', level: 'expert' }
  ],
  certifications: [
    { id: '1', name: 'Google UX Design Professional Certificate', issuer: 'Google', date: '2022' },
    { id: '2', name: 'IDEO Design Thinking Certificate', issuer: 'IDEO U', date: '2018' }
  ],
  projects: [
    {
      id: '1',
      name: 'Nike "Beyond the Field" Campaign',
      description: 'Multi-platform campaign celebrating athlete activism and community impact.',
      technologies: ['After Effects', 'Cinema 4D', 'Premiere Pro', 'Figma'],
      highlights: ['450M impressions', '3 Cannes Lions Gold', 'Featured in Apple Keynote']
    },
    {
      id: '2',
      name: 'Google Pixel Brand System',
      description: 'Comprehensive design system spanning digital, retail, and advertising.',
      technologies: ['Figma', 'Principle', 'Adobe CC', 'Motion'],
      highlights: ['28% brand consideration lift', 'Deployed across 50+ countries', 'Won Clio Award']
    }
  ],
  achievements: [
    { id: '1', title: 'Cannes Lions Grand Prix', description: 'Nike "Beyond the Field" campaign for Branded Content', date: '2023' },
    { id: '2', title: 'Clio Awards - Gold', description: 'Multiple wins across Film, Digital, and Brand Identity categories', date: '2019-2023' },
    { id: '3', title: 'Webby Awards Judge', description: 'Selected as judge for Advertising and Brand categories', date: '2024' },
    { id: '4', title: 'AdWeek Creative 100', description: 'Recognized among most creative people in advertising', date: '2022' }
  ],
  languages: [
    { name: 'English', proficiency: 'native' },
    { name: 'Spanish', proficiency: 'native' },
    { name: 'French', proficiency: 'conversational' }
  ],
  memberships: [
    { id: '1', organization: 'The One Club for Creativity', role: 'Education Committee Member', startDate: '2019', current: true },
    { id: '2', organization: 'AIGA - American Institute of Graphic Arts', startDate: '2012', current: true },
    { id: '3', organization: 'Advertising Women of New York (AWNY)', startDate: '2018', current: true }
  ],
  volunteer: [
    {
      id: '1',
      role: 'Board Member',
      organization: 'Inner-City Arts',
      location: 'Los Angeles, CA',
      startDate: '2021',
      current: true,
      description: 'Support arts education programs for underserved youth in Los Angeles schools'
    },
    {
      id: '2',
      role: 'Industry Mentor',
      organization: 'CreativeEquals',
      location: 'Remote',
      startDate: '2020',
      current: true,
      description: 'Mentor aspiring creatives from underrepresented backgrounds seeking careers in advertising'
    }
  ],
  references: [
    { id: '1', name: 'Mark Bennett', title: 'Executive Creative Director', company: 'R/GA', email: 'm.bennett@rga.com', phone: '(310) 555-0100' },
    { id: '2', name: 'Lisa Wong', title: 'VP of Marketing', company: 'Nike', email: 'l.wong@nike.com', phone: '(503) 555-0200' }
  ]
};
