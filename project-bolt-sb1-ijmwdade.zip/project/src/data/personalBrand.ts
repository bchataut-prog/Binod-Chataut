import type { ResumeData } from '../types/resume';

export const personalBrandData: ResumeData = {
  personalInfo: {
    fullName: 'Alexandra "Alex" Reeves',
    title: 'Strategy Consultant & Advisor',
    email: 'alex@alexreeves.co',
    phone: '(646) 555-3421',
    location: 'New York, NY',
    website: 'www.alexreeves.co',
    linkedin: 'linkedin.com/in/alexreeves',
    photo: 'https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=300'
  },
  summary: 'Strategic consultant, executive advisor, and entrepreneur with 15 years advising C-suite leaders on digital transformation, growth strategy, and organizational change. Built and sold a consulting practice to Big 4. Author of "Strategic Pivot" (Harper Business) and keynote speaker at Fortune 500 leadership events. Trusted advisor generating $500M+ in client value through transformational initiatives.',
  experience: [
    {
      id: '1',
      title: 'Founder & Principal Consultant',
      company: 'Alex Reeves Consulting',
      location: 'New York, NY',
      startDate: '2020',
      endDate: 'Present',
      current: true,
      highlights: [
        'Advising 12 clients across technology, healthcare, and financial services on growth and transformation strategy',
        'Generated $85M in client revenue growth through strategic initiatives',
        'Coached 25 C-suite executives on leadership, scaling operations, and market expansion',
        'Developed proprietary strategy framework adopted by Fortune 500 strategy teams',
        'Delivered keynotes at Google, Microsoft, and PepsiCo executive leadership programs',
        'Created online executive education program with 5,000+ enrolled leaders'
      ]
    },
    {
      id: '2',
      title: 'Partner',
      company: 'Accenture Strategy',
      location: 'New York, NY',
      startDate: '2015',
      endDate: '2020',
      highlights: [
        'Led $120M consulting portfolio spanning 28 clients in technology and media sectors',
        'Directed enterprise digital transformation for Fortune 100 media company generating $400M in value',
        'Built and managed consulting team of 65 professionals across 4 global offices',
        'Spearheaded go-to-market strategy for $2B acquisition of European competitor',
        'Pioneered sustainability consulting practice now representing $50M annual revenue'
      ]
    },
    {
      id: '3',
      title: 'Senior Manager',
      company: 'McKinsey & Company',
      location: 'New York, NY',
      startDate: '2010',
      endDate: '2015',
      highlights: [
        'Led strategy engagements for Fortune 500 clients in retail, healthcare, and technology',
        'Developed growth strategy for retail client achieving 45% revenue increase',
        'Coached executive teams on organizational design and change management',
        'Authored 8 McKinsey white papers cited by Fortune and Harvard Business Review'
      ]
    }
  ],
  education: [
    {
      id: '1',
      degree: 'Master of Business Administration (MBA)',
      field: 'Strategy & Entrepreneurship',
      institution: 'Stanford Graduate School of Business',
      location: 'Stanford, CA',
      graduationDate: '2010',
      honors: ['Arbuckle Leadership Fellow', 'Miller Social Change Fellow']
    },
    {
      id: '2',
      degree: 'Bachelor of Arts',
      field: 'Economics & Women\'s Studies',
      institution: 'Columbia University',
      location: 'New York, NY',
      graduationDate: '2005',
      gpa: '3.91/4.0',
      honors: ['Magna Cum Laude', 'Phi Beta Kappa']
    }
  ],
  skills: [
    { name: 'Strategic Consulting', level: 'expert' },
    { name: 'Executive Coaching', level: 'expert' },
    { name: 'M&A Strategy & Integration', level: 'expert' },
    { name: 'Digital Transformation', level: 'expert' },
    { name: 'Organizational Change', level: 'expert' },
    { name: 'Public Speaking & Keynotes', level: 'expert' },
    { name: 'Business Model Innovation', level: 'expert' },
    { name: 'Board Governance', level: 'advanced' },
    { name: 'Leadership Development', level: 'expert' },
    { name: 'Workshop Facilitation', level: 'expert' }
  ],
  certifications: [
    { id: '1', name: 'Executive Coach Certification', issuer: 'International Coach Federation', date: '2018', credentialId: 'ICF-284751' },
    { id: '2', name: 'Certified Management Consultant (CMC)', issuer: 'Institute of Management Consultants', date: '2016' },
    { id: '3', name: 'YPO Executive Education - Scaling Ventures', issuer: 'Young Presidents\' Organization', date: '2022' }
  ],
  achievements: [
    { id: '1', title: 'Thinkers50 Radar Award', description: 'Recognized among top management thinkers to watch', date: '2023' },
    { id: '2', title: 'Best Business Book of 2022', description: '"Strategic Pivot" - 800-CEO-READ', date: '2022' },
    { id: '3', title: 'Entrepreneur 100 Women', description: 'Featured in Entrepreneur magazine\'s top women entrepreneurs', date: '2021' },
    { id: '4', title: 'TEDx Speaker', description: '"The Art of Strategic Reinvention" - 2.5M views', date: '2021' }
  ],
  languages: [
    { name: 'English', proficiency: 'native' },
    { name: 'Portuguese', proficiency: 'fluent' },
    { name: 'Spanish', proficiency: 'professional' }
  ],
  memberships: [
    { id: '1', organization: 'Young Presidents\' Organization (YPO)', role: 'Chapter Chair', startDate: '2021', current: true },
    { id: '2', organization: 'Institute of Management Consultants', startDate: '2016', current: true },
    { id: '3', organization: 'Strategic Management Society', startDate: '2012', current: true }
  ],
  volunteer: [
    {
      id: '1',
      role: 'Board Member',
      organization: 'Year Up',
      location: 'New York, NY',
      startDate: '2020',
      current: true,
      description: 'Support organization providing career training and internships to young adults'
    },
    {
      id: '2',
      role: 'Mentor',
      organization: 'Defy Ventures',
      location: 'New York, NY',
      startDate: '2018',
      current: true,
      description: 'Mentor formerly incarcerated individuals starting their own businesses'
    },
    {
      id: '3',
      role: 'Advisory Board',
      organization: 'Girls Who Invest',
      location: 'New York, NY',
      startDate: '2019',
      current: true,
      description: 'Advise organization focused on increasing women in asset management'
    }
  ],
  references: [
    { id: '1', name: 'Robert Chen', title: 'Former CEO', company: 'Maverick Media (Client)', email: 'r.chen@mm.com', phone: '(212) 555-0100' },
    { id: '2', name: 'Jennifer Walsh', title: 'Managing Director', company: 'Accenture Strategy', email: 'j.walsh@accenture.com', phone: '(212) 555-0200' }
  ]
};
