import type { ResumeData } from '../types/resume';

export const corporateProData: ResumeData = {
  personalInfo: {
    fullName: 'David Chen Rodriguez',
    title: 'Senior Project Manager',
    email: 'david.chen.rodriguez@email.com',
    phone: '(415) 555-0289',
    location: 'San Francisco, CA',
    linkedin: 'linkedin.com/in/davidchenrodriguez'
  },
  summary: 'Results-driven Senior Project Manager with 12+ years of experience delivering complex enterprise initiatives across technology, operations, and digital transformation domains. Certified PMP and Agile practitioner with proven success managing multi-million dollar portfolios and cross-functional teams of 50+ members. Expert in establishing PMOs, optimizing resource allocation, and driving stakeholder alignment to achieve strategic objectives.',
  experience: [
    {
      id: '1',
      title: 'Senior Project Manager',
      company: 'TechVentures Inc.',
      location: 'San Francisco, CA',
      startDate: '2019',
      endDate: 'Present',
      current: true,
      highlights: [
        'Lead enterprise portfolio of 15 concurrent projects valued at $45M with 96% on-time delivery rate',
        'Established Agile transformation program increasing team velocity by 35% across 8 development squads',
        'Designed and implemented project governance framework adopted across 4 global offices',
        'Reduced project delivery costs by $2.8M through process standardization and tool consolidation',
        'Mentored team of 7 junior PMs achieving 100% PMP certification pass rate',
        'Managed critical cloud migration project for 200+ applications with zero customer-facing outages'
      ]
    },
    {
      id: '2',
      title: 'Program Manager',
      company: 'Pacific Logistics Corporation',
      location: 'Oakland, CA',
      startDate: '2015',
      endDate: '2019',
      highlights: [
        'Directed $18M warehouse modernization program spanning 3 facilities and 400 staff',
        'Implemented WMS (Warehouse Management System) reducing fulfillment time by 40%',
        'Coordinated cross-functional teams across operations, IT, and supply chain departments',
        'Established vendor management program overseeing $25M in annual contracts',
        'Led change management initiatives achieving 89% employee adoption within 6 months'
      ]
    },
    {
      id: '3',
      title: 'Project Manager',
      company: 'Continental Healthcare Systems',
      location: 'Los Angeles, CA',
      startDate: '2012',
      endDate: '2015',
      highlights: [
        'Managed EHR implementation across 12 medical facilities serving 500,000 patients',
        'Delivered HIPAA-compliant patient portal project under budget by $450K',
        'Established project reporting standards reducing status meeting time by 60%',
        'Led process improvement initiative increasing patient satisfaction scores by 22%'
      ]
    }
  ],
  education: [
    {
      id: '1',
      degree: 'Master of Science',
      field: 'Project Management',
      institution: 'Stanford University',
      location: 'Stanford, CA',
      graduationDate: '2012',
      gpa: '3.85/4.0'
    },
    {
      id: '2',
      degree: 'Bachelor of Science',
      field: 'Industrial Engineering',
      institution: 'University of California, Berkeley',
      location: 'Berkeley, CA',
      graduationDate: '2009',
      gpa: '3.72/4.0',
      honors: ['Dean\'s List']
    }
  ],
  skills: [
    { name: 'Project Portfolio Management', level: 'expert' },
    { name: 'Agile & Scrum Methodologies', level: 'expert' },
    { name: 'Stakeholder Management', level: 'expert' },
    { name: 'Risk Assessment & Mitigation', level: 'expert' },
    { name: 'Resource Planning & Optimization', level: 'expert' },
    { name: 'Change Management', level: 'advanced' },
    { name: 'Budget & Cost Control', level: 'expert' },
    { name: 'Jira & Confluence Administration', level: 'advanced' },
    { name: 'Microsoft Project & Azure DevOps', level: 'advanced' },
    { name: 'Vendor Management', level: 'advanced' }
  ],
  certifications: [
    { id: '1', name: 'Project Management Professional (PMP)', issuer: 'Project Management Institute', date: '2014', credentialId: 'PMP-1685432' },
    { id: '2', name: 'Certified Scrum Master (CSM)', issuer: 'Scrum Alliance', date: '2017', credentialId: 'CSM-284571' },
    { id: '3', name: 'PMI Agile Certified Practitioner (PMI-ACP)', issuer: 'Project Management Institute', date: '2019', credentialId: 'ACP-892341' },
    { id: '4', name: 'ITIL Foundation Certification', issuer: 'AXELOS', date: '2016' }
  ],
  projects: [
    {
      id: '1',
      name: 'Enterprise Resource Planning Migration',
      description: 'Led $12M SAP S/4HANA migration replacing legacy systems across 8 business units.',
      technologies: ['SAP', 'Azure', 'Power BI', 'ServiceNow'],
      highlights: ['Completed 2 weeks ahead of schedule', 'Achieved 99.8% data integrity', 'Trained 1,200 end users']
    },
    {
      id: '2',
      name: 'Digital Customer Experience Platform',
      description: 'Built omnichannel customer engagement platform integrating web, mobile, and call center operations.',
      technologies: ['Salesforce', 'AWS', 'Twilio', 'Zendesk'],
      highlights: ['Increased NPS by 28 points', 'Reduced support tickets by 45%', 'Generated $3.2M in cross-sell revenue']
    }
  ],
  achievements: [
    { id: '1', title: 'Project Excellence Award', description: 'TechVentures Inc. - recognition for zero-defect ERP migration', date: '2022' },
    { id: '2', title: 'Best PM Blog Award', description: 'PMI Northern California Chapter for project management thought leadership', date: '2021' }
  ],
  languages: [
    { name: 'English', proficiency: 'native' },
    { name: 'Mandarin Chinese', proficiency: 'fluent' },
    { name: 'Spanish', proficiency: 'professional' }
  ],
  memberships: [
    { id: '1', organization: 'Project Management Institute', role: 'Chapter President', startDate: '2020', current: true },
    { id: '2', organization: 'Scrum Alliance', startDate: '2017', current: true }
  ],
  volunteer: [
    {
      id: '1',
      role: 'STEM Education Mentor',
      organization: 'Girls Who Code',
      location: 'San Francisco, CA',
      startDate: '2020',
      current: true,
      description: 'Mentor high school students in computational thinking and project management fundamentals'
    }
  ],
  references: [
    { id: '1', name: 'Sarah Mitchell', title: 'VP of Operations', company: 'TechVentures Inc.', email: 's.mitchell@techventures.com', phone: '(415) 555-0156' },
    { id: '2', name: 'Thomas Park', title: 'Director of PMO', company: 'Pacific Logistics Corporation', email: 't.park@pacificlogistics.com' }
  ]
};
