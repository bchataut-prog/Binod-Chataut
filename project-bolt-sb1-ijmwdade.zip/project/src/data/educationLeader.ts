import type { ResumeData } from '../types/resume';

export const educationLeaderData: ResumeData = {
  personalInfo: {
    fullName: 'Dr. Robert J. Morrison',
    title: 'University Professor & Department Chair',
    email: 'dr.morrison@email.edu',
    phone: '(617) 555-0923',
    location: 'Cambridge, MA',
    website: 'www.morrisonresearch.edu',
    linkedin: 'linkedin.com/in/drmorrison'
  },
  summary: 'Distinguished Professor of Education with 18 years of experience in higher education leadership, curriculum innovation, and educational research. Department Chair with proven record of building academic programs, securing $6M+ in research funding, and mentoring doctoral students toward successful careers. Published author of 3 books and 45+ peer-reviewed articles on educational policy, equity, and instructional effectiveness.',
  experience: [
    {
      id: '1',
      title: 'Department Chair & Professor of Education',
      company: 'Harvard Graduate School of Education',
      location: 'Cambridge, MA',
      startDate: '2018',
      endDate: 'Present',
      current: true,
      highlights: [
        'Lead department of 35 faculty members and 450 graduate students with $12M annual operating budget',
        'Redesigned doctoral curriculum resulting in 40% increase in 4-year completion rates',
        'Secured $3.2M federal grant for teacher effectiveness research initiative',
        'Established partnership network with 25 school districts for research-practice collaboration',
        'Mentored 18 doctoral students to completion with 95% achieving academic positions',
        'Built diversity initiative increasing underrepresented faculty representation by 28%'
      ]
    },
    {
      id: '2',
      title: 'Associate Professor of Education',
      company: 'Stanford Graduate School of Education',
      location: 'Stanford, CA',
      startDate: '2012',
      endDate: '2018',
      highlights: [
        'Developed and taught graduate courses on educational policy, research methods, and leadership',
        'Directed research center focusing on K-12 equity and access issues',
        'Secured $2.4M in foundation and government grants for longitudinal education studies',
        'Published 12 peer-reviewed articles in top-tier education journals',
        'Served on university tenure and promotion committee for 3 years',
        'Created executive education program for school superintendents serving 200+ leaders'
      ]
    },
    {
      id: '3',
      title: 'Assistant Professor of Education',
      company: 'University of Michigan School of Education',
      location: 'Ann Arbor, MI',
      startDate: '2006',
      endDate: '2012',
      highlights: [
        'Taught undergraduate and graduate courses in curriculum design and assessment',
        'Conducted mixed-methods research on teacher professional development',
        'Supervised student teacher placements in 15 partner schools',
        'Published first book: "Transforming Urban Education: A Framework for Change"'
      ]
    }
  ],
  education: [
    {
      id: '1',
      degree: 'Doctor of Education (Ed.D.)',
      field: 'Educational Leadership',
      institution: 'Columbia University Teachers College',
      location: 'New York, NY',
      graduationDate: '2006',
      honors: ['Dissertation Fellowship', 'Outstanding Dissertation Award']
    },
    {
      id: '2',
      degree: 'Master of Education (M.Ed.)',
      field: 'Curriculum & Instruction',
      institution: 'University of Virginia',
      location: 'Charlottesville, VA',
      graduationDate: '2001',
      gpa: '3.94/4.0'
    },
    {
      id: '3',
      degree: 'Bachelor of Arts',
      field: 'History & Secondary Education',
      institution: 'Duke University',
      location: 'Durham, NC',
      graduationDate: '1998',
      gpa: '3.75/4.0',
      honors: ['Cum Laude', 'Secondary Education Teaching Credential']
    }
  ],
  skills: [
    { name: 'Academic Leadership & Administration', level: 'expert' },
    { name: 'Curriculum Development', level: 'expert' },
    { name: 'Educational Research (Mixed Methods)', level: 'expert' },
    { name: 'Grant Writing & Management', level: 'expert' },
    { name: 'Faculty Development & Mentoring', level: 'expert' },
    { name: 'Quantitative & Qualitative Analysis', level: 'advanced' },
    { name: 'Program Evaluation', level: 'expert' },
    { name: 'Policy Analysis & Development', level: 'advanced' },
    { name: 'Stakeholder Engagement', level: 'expert' },
    { name: 'Academic Publishing', level: 'expert' }
  ],
  certifications: [
    { id: '1', name: 'Certified Educational Planner', issuer: 'American Institute of Certified Educational Planners', date: '2015' },
    { id: '2', name: 'Harvard Leadership Development Program', issuer: 'Harvard Kennedy School', date: '2020' }
  ],
  projects: [
    {
      id: '1',
      name: 'Teacher Effectiveness Research Initiative',
      description: 'Multi-site longitudinal study examining professional development impact on teaching quality.',
      technologies: ['SPSS', 'NVivo', 'Qualtrics', 'R'],
      highlights: ['Published 8 peer-reviewed papers', 'Informed policy in 12 states', 'Trained 150+ research assistants']
    },
    {
      id: '2',
      name: 'Equity in Education Policy Lab',
      description: 'Research-practice partnership developing evidence-based interventions for underserved schools.',
      highlights: ['Partnered with 45 schools', 'Developed evaluation framework', 'Secured $1.5M continuation grant']
    }
  ],
  achievements: [
    { id: '1', title: 'AERA Early Career Award', description: 'American Educational Research Association recognition for outstanding research contributions', date: '2014' },
    { id: '2', title: 'Outstanding Professor Award', description: 'Stanford Graduate School of Education student-selected honor', date: '2016' },
    { id: '3', title: 'Elected Fellow - American Educational Research Association', description: 'Recognition for distinguished contributions to education research', date: '2020' }
  ],
  languages: [
    { name: 'English', proficiency: 'native' },
    { name: 'Spanish', proficiency: 'professional' }
  ],
  memberships: [
    { id: '1', organization: 'American Educational Research Association', role: 'Division Vice President', startDate: '2008', current: true },
    { id: '2', organization: 'American Association of Colleges for Teacher Education', startDate: '2010', current: true },
    { id: '3', organization: 'National Association for the Education of Young Children', startDate: '2006', current: true }
  ],
  volunteer: [
    {
      id: '1',
      role: 'School Board Member',
      organization: 'Cambridge Public Schools',
      location: 'Cambridge, MA',
      startDate: '2021',
      current: true,
      description: 'Elected board member contributing policy expertise and educational research insights'
    },
    {
      id: '2',
      role: 'Education Advisor',
      organization: 'UNICEF',
      location: 'Remote',
      startDate: '2019',
      current: true,
      description: 'Advise on global education initiatives and teacher professional development programs'
    }
  ],
  references: [
    { id: '1', name: 'Dr. Sarah Williams, Ed.D.', title: 'Dean', company: 'Harvard Graduate School of Education', email: 's.williams@gse.harvard.edu', phone: '(617) 555-0100' },
    { id: '2', name: 'Dr. Michael Chen, PhD', title: 'Professor Emeritus', company: 'Stanford University', email: 'm.chen@stanford.edu', phone: '(650) 555-0200' }
  ]
};
