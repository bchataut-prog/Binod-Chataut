import type { ResumeData } from '../types/resume';

export const executiveEliteData: ResumeData = {
  personalInfo: {
    fullName: 'Margaret A. Sterling',
    title: 'Chief Financial Officer',
    email: 'margaret.sterling@email.com',
    phone: '(212) 555-0147',
    location: 'New York, NY',
    website: 'www.margaretsterling.com',
    linkedin: 'linkedin.com/in/margaretsterling'
  },
  summary: 'Strategic financial executive with 18+ years driving corporate growth and operational excellence for Fortune 500 companies. Proven track record of orchestrating multi-billion dollar M&A transactions, implementing digital transformation initiatives, and building world-class finance teams. Recognized for developing innovative financial strategies that delivered $2.3B in shareholder value while maintaining rigorous compliance standards.',
  experience: [
    {
      id: '1',
      title: 'Chief Financial Officer',
      company: 'Global Dynamics Corporation',
      location: 'New York, NY',
      startDate: '2018',
      endDate: 'Present',
      current: true,
      highlights: [
        'Direct all financial operations for $8.2B global technology company with 12,000 employees across 28 countries',
        'Led successful restructuring initiative resulting in $340M annual cost savings and 15% margin improvement',
        'Oversaw $1.2B acquisition of European competitor, achieving 93% integration targets within 18 months',
        'Implemented AI-driven financial planning platform reducing forecast cycle from 14 to 5 days',
        'Managed investor relations during IPO preparation, driving 40% institutional investor interest',
        'Built and mentored 85-person finance organization with 100% SOX compliance record'
      ]
    },
    {
      id: '2',
      title: 'Senior Vice President, Finance',
      company: 'Merrill Financial Services',
      location: 'Boston, MA',
      startDate: '2012',
      endDate: '2018',
      highlights: [
        'Managed $4.5B investment portfolio and treasury operations for North American division',
        'Led due diligence for 8 strategic acquisitions totaling $2.1B in transaction value',
        'Redesigned capital allocation framework, improving ROI by 23% across business units',
        'Established enterprise risk management program achieving AA+ credit rating upgrade',
        'Developed and executed hedging strategy protecting against $580M currency exposure'
      ]
    },
    {
      id: '3',
      title: 'Vice President, Corporate Finance',
      company: 'Continental Manufacturing Group',
      location: 'Chicago, IL',
      startDate: '2006',
      endDate: '2012',
      highlights: [
        'Directed financial planning and analysis for $2.8B industrial manufacturing operations',
        'Led successful spin-off transaction creating $800M market value for shareholders',
        'Implemented activity-based costing model identifying $45M process improvement opportunities',
        'Managed relationships with 12 global banking institutions securing $1.5B credit facilities'
      ]
    }
  ],
  education: [
    {
      id: '1',
      degree: 'Master of Business Administration',
      field: 'Finance & Strategy',
      institution: 'Harvard Business School',
      location: 'Boston, MA',
      graduationDate: '2004',
      honors: ['Baker Scholar (top 5%)', 'Dean\'s Award for Academic Excellence']
    },
    {
      id: '2',
      degree: 'Bachelor of Science',
      field: 'Accounting',
      institution: 'University of Pennsylvania, Wharton School',
      location: 'Philadelphia, PA',
      graduationDate: '2002',
      gpa: '3.92/4.0',
      honors: ['Summa Cum Laude', 'Beta Alpha Psi Honor Society']
    }
  ],
  skills: [
    { name: 'Strategic Financial Planning', level: 'expert' },
    { name: 'Mergers & Acquisitions', level: 'expert' },
    { name: 'Capital Markets & Fundraising', level: 'expert' },
    { name: 'Risk Management', level: 'expert' },
    { name: 'Financial Modeling & Valuation', level: 'expert' },
    { name: 'Treasury & Cash Management', level: 'expert' },
    { name: 'Board Relations & Governance', level: 'advanced' },
    { name: 'Digital Transformation', level: 'advanced' },
    { name: 'Global Operations', level: 'advanced' },
    { name: 'Team Leadership & Development', level: 'expert' }
  ],
  certifications: [
    { id: '1', name: 'Certified Public Accountant (CPA)', issuer: 'AICPA', date: '2005' },
    { id: '2', name: 'Chartered Financial Analyst (CFA)', issuer: 'CFA Institute', date: '2008' },
    { id: '3', name: 'Certified Management Accountant (CMA)', issuer: 'IMA', date: '2010' }
  ],
  achievements: [
    { id: '1', title: 'CFO of the Year', description: 'Recognized by Financial Times for exceptional leadership during 2020 crisis response', date: '2021' },
    { id: '2', title: 'Excellence in Corporate Finance Award', description: 'American Finance Association for innovative capital structure optimization', date: '2019' },
    { id: '3', title: 'Top 50 CFOs in Technology', description: 'Featured in Institutional Investor magazine', date: '2022' }
  ],
  languages: [
    { name: 'English', proficiency: 'native' },
    { name: 'Spanish', proficiency: 'professional' },
    { name: 'French', proficiency: 'conversational' }
  ],
  memberships: [
    { id: '1', organization: 'National Association of Corporate Directors', role: 'Fellow', startDate: '2019', current: true },
    { id: '2', organization: 'Financial Executives International', role: 'Board Member', startDate: '2020', current: true },
    { id: '3', organization: 'CFA Institute', startDate: '2008', current: true }
  ],
  volunteer: [
    {
      id: '1',
      role: 'Board Trustee',
      organization: 'New York Children\'s Hospital Foundation',
      location: 'New York, NY',
      startDate: '2019',
      current: true,
      description: 'Leading fundraising initiatives that generated $12M for pediatric cancer research programs'
    },
    {
      id: '2',
      role: 'Finance Committee Chair',
      organization: 'Metropolitan Museum of Art',
      location: 'New York, NY',
      startDate: '2021',
      current: true,
      description: 'Oversight of $300M annual operating budget and endowment management'
    }
  ],
  references: [
    { id: '1', name: 'Robert J. Harrison', title: 'Chief Executive Officer', company: 'Global Dynamics Corporation', email: 'r.harrison@globaldynamics.com', phone: '(212) 555-0101' },
    { id: '2', name: 'Jennifer M. Walsh', title: 'Managing Partner', company: 'Deloitte & Touche LLP', email: 'j.walsh@deloitte.com', phone: '(212) 555-0202' }
  ]
};
