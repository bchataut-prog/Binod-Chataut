import type { ResumeData } from '../types/resume';

export const healthcareProfessionalData: ResumeData = {
  personalInfo: {
    fullName: 'Dr. Priya Sharma',
    title: 'Public Health Specialist',
    email: 'dr.priya.sharma@email.com',
    phone: '(202) 555-0678',
    location: 'Washington, DC',
    linkedin: 'linkedin.com/in/drpriyasharma'
  },
  summary: 'Doctorate-level Public Health Specialist with 11 years of experience in epidemiology, health policy development, and community health program management. Expertise in designing and implementing evidence-based interventions addressing health disparities, infectious disease prevention, and maternal-child health. Leading researcher with 25+ peer-reviewed publications and $8M in secured grant funding from NIH and CDC.',
  experience: [
    {
      id: '1',
      title: 'Senior Public Health Specialist',
      company: 'Centers for Disease Control and Prevention (CDC)',
      location: 'Atlanta, GA',
      startDate: '2019',
      endDate: 'Present',
      current: true,
      highlights: [
        'Lead epidemiological surveillance team for emerging infectious diseases across 12-state region',
        'Designed community health intervention reducing vaccine-preventable disease rates by 34%',
        'Manage $4.2M annual program budget with 100% grant compliance record',
        'Coordinate multi-agency response efforts during public health emergencies',
        'Authored 8 peer-reviewed publications in high-impact journals (Lancet, NEJM, MMWR)',
        'Develop training curricula for 200+ public health professionals annually'
      ]
    },
    {
      id: '2',
      title: 'Epidemiologist',
      company: 'World Health Organization (WHO)',
      location: 'Geneva, Switzerland',
      startDate: '2016',
      endDate: '2019',
      highlights: [
        'Conducted outbreak investigations and response coordination in 15 countries across Africa and Asia',
        'Led development of disease surveillance protocols adopted by 28 member states',
        'Managed $2.5M research project on vaccine efficacy in low-resource settings',
        'Trained 150+ healthcare workers in infection prevention and control measures',
        'Authored technical guidelines on pandemic preparedness published in 5 languages'
      ]
    },
    {
      id: '3',
      title: 'Research Associate',
      company: 'Johns Hopkins Bloomberg School of Public Health',
      location: 'Baltimore, MD',
      startDate: '2013',
      endDate: '2016',
      highlights: [
        'Conducted CDC-funded research on maternal mortality in underserved populations',
        'Analyzed health disparities data using SAS and STATA for policy recommendations',
        'Co-authored 6 publications in peer-reviewed public health journals',
        'Presented research findings at 12 international conferences'
      ]
    }
  ],
  education: [
    {
      id: '1',
      degree: 'Doctor of Public Health (DrPH)',
      field: 'Epidemiology',
      institution: 'Johns Hopkins Bloomberg School of Public Health',
      location: 'Baltimore, MD',
      graduationDate: '2016',
      honors: ['Delta Omega Honorary Society']
    },
    {
      id: '2',
      degree: 'Master of Science',
      field: 'Global Health',
      institution: 'Harvard T.H. Chan School of Public Health',
      location: 'Boston, MA',
      graduationDate: '2013',
      gpa: '3.91/4.0'
    },
    {
      id: '3',
      degree: 'Bachelor of Medicine, Bachelor of Surgery (MBBS)',
      field: 'Medicine',
      institution: 'Armed Forces Medical College',
      location: 'Pune, India',
      graduationDate: '2010'
    }
  ],
  skills: [
    { name: 'Epidemiological Surveillance', level: 'expert' },
    { name: 'Outbreak Investigation & Response', level: 'expert' },
    { name: 'Statistical Analysis (SAS, STATA, R)', level: 'expert' },
    { name: 'Grant Writing & Management', level: 'expert' },
    { name: 'Program Evaluation', level: 'expert' },
    { name: 'Health Policy Development', level: 'advanced' },
    { name: 'Community Health Assessment', level: 'expert' },
    { name: 'Infectious Disease Prevention', level: 'expert' },
    { name: 'Training & Capacity Building', level: 'advanced' },
    { name: 'Scientific Writing & Publication', level: 'expert' }
  ],
  certifications: [
    { id: '1', name: 'Board Certified in Public Health (CPH)', issuer: 'National Board of Public Health Examiners', date: '2017' },
    { id: '2', name: 'Certified in Infection Control (CIC)', issuer: 'Certification Board of Infection Control', date: '2019' },
    { id: '3', name: 'Emergency Management Specialist', issuer: 'FEMA Emergency Management Institute', date: '2020' }
  ],
  projects: [
    {
      id: '1',
      name: 'Maternal Mortality Reduction Initiative',
      description: 'Led community-based intervention reducing maternal mortality by 28% in rural communities.',
      highlights: ['Trained 120 community health workers', 'Established 25 birthing centers', 'Published outcomes in Lancet Global Health']
    },
    {
      id: '2',
      name: 'COVID-19 Vaccine Equity Program',
      description: 'Designed and implemented vaccine access program serving 500,000 underserved individuals.',
      highlights: ['Achieved 89% vaccination coverage', 'Partnered with 45 community organizations', 'Model adopted by 8 state health departments']
    }
  ],
  achievements: [
    { id: '1', title: 'CDC Honor Award for Excellence', description: 'Recognition for leadership during regional outbreak response', date: '2022' },
    { id: '2', title: 'WHO Director-General\'s Special Recognition', description: 'For contributions to global health security', date: '2019' },
    { id: '3', title: 'AMA Emerging Leader in Public Health', description: 'Recognized for innovative health equity programs', date: '2021' }
  ],
  languages: [
    { name: 'English', proficiency: 'native' },
    { name: 'Hindi', proficiency: 'native' },
    { name: 'French', proficiency: 'professional' }
  ],
  memberships: [
    { id: '1', organization: 'American Public Health Association', role: 'Section Council Member', startDate: '2018', current: true },
    { id: '2', organization: 'Society for Epidemiologic Research', startDate: '2014', current: true },
    { id: '3', organization: 'International Society for Infectious Diseases', startDate: '2016', current: true }
  ],
  volunteer: [
    {
      id: '1',
      role: 'Medical Volunteer',
      organization: 'Doctors Without Borders (MSF)',
      location: 'Various',
      startDate: '2015',
      current: true,
      description: 'Provide emergency medical care during humanitarian crises and disaster response missions'
    },
    {
      id: '2',
      role: 'Public Health Advisor',
      organization: 'International Rescue Committee',
      location: 'Washington, DC',
      startDate: '2020',
      current: true,
      description: 'Advise on refugee health programs and capacity building in crisis-affected regions'
    }
  ],
  references: [
    { id: '1', name: 'Dr. Robert Anderson, MD, MPH', title: 'Division Director', company: 'CDC - Division of Global Health Protection', email: 'r.anderson@cdc.gov', phone: '(404) 555-0123' },
    { id: '2', name: 'Dr. Maria Garcia, PhD', title: 'Professor of Epidemiology', company: 'Johns Hopkins University', email: 'm.garcia@jhu.edu', phone: '(410) 555-0456' }
  ]
};
