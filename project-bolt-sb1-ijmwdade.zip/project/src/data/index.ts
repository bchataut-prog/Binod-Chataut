export { executiveEliteData } from './executiveElite';
export { corporateProData } from './corporatePro';
export { financeAuthorityData } from './financeAuthority';
export { healthcareProfessionalData } from './healthcareProfessional';
export { legalProfessionalData } from './legalProfessional';
export { educationLeaderData } from './educationLeader';
export { governmentProfessionalData } from './governmentProfessional';
export { modernTechData } from './modernTech';
export { creativeEdgeData } from './creativeEdge';
export { personalBrandData } from './personalBrand';

import { executiveEliteData } from './executiveElite';
import { corporateProData } from './corporatePro';
import { financeAuthorityData } from './financeAuthority';
import { healthcareProfessionalData } from './healthcareProfessional';
import { legalProfessionalData } from './legalProfessional';
import { educationLeaderData } from './educationLeader';
import { governmentProfessionalData } from './governmentProfessional';
import { modernTechData } from './modernTech';
import { creativeEdgeData } from './creativeEdge';
import { personalBrandData } from './personalBrand';

export const sampleDataMap = {
  'executive-elite': executiveEliteData,
  'corporate-pro': corporateProData,
  'finance-authority': financeAuthorityData,
  'healthcare-professional': healthcareProfessionalData,
  'legal-professional': legalProfessionalData,
  'education-leader': educationLeaderData,
  'government-professional': governmentProfessionalData,
  'modern-tech': modernTechData,
  'creative-edge': creativeEdgeData,
  'personal-brand': personalBrandData,
};
