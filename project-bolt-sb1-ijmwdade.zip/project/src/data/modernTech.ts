import type { ResumeData } from '../types/resume';

export const modernTechData: ResumeData = {
  personalInfo: {
    fullName: 'Michael Zhang',
    title: 'Senior Software Engineer',
    email: 'michael.zhang@email.dev',
    phone: '(650) 555-1872',
    location: 'Mountain View, CA',
    website: 'www.michaelzhang.dev',
    linkedin: 'linkedin.com/in/michaelzhangdev',
    photo: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=300'
  },
  summary: 'Full-stack Software Engineer with 8 years of experience building scalable distributed systems and consumer-facing applications at FAANG and high-growth startups. Expert in cloud-native architecture, microservices, and developer tooling. Led teams of 12 engineers delivering products serving 50M+ users. Open source contributor and technical writer with 15K+ GitHub followers.',
  experience: [
    {
      id: '1',
      title: 'Senior Software Engineer',
      company: 'Google',
      location: 'Mountain View, CA',
      startDate: '2021',
      endDate: 'Present',
      current: true,
      highlights: [
        'Architected real-time analytics platform processing 2B events daily with 99.99% uptime',
        'Led migration from monolith to microservices reducing deployment time from 4 hours to 15 minutes',
        'Mentored team of 6 engineers on system design and distributed computing best practices',
        'Open-sourced internal library achieving 8,000+ GitHub stars and 50+ contributors',
        'Reduced cloud infrastructure costs by $3.2M annually through optimization initiatives',
        'Design and implemented CI/CD pipeline reducing release cycle from 2 weeks to daily'
      ]
    },
    {
      id: '2',
      title: 'Software Engineer',
      company: 'Airbnb',
      location: 'San Francisco, CA',
      startDate: '2018',
      endDate: '2021',
      highlights: [
        'Built search ranking infrastructure improving booking conversion by 12%',
        'Developed A/B testing framework handling 200+ experiments monthly',
        'Implemented fraud detection system reducing fraudulent bookings by 40%',
        'Led backend development for host messaging product serving 10M daily users',
        'Contributed to internal GraphQL framework used across 50+ services'
      ]
    },
    {
      id: '3',
      title: 'Software Engineer',
      company: 'Stripe',
      location: 'San Francisco, CA',
      startDate: '2016',
      endDate: '2018',
      highlights: [
        'Developed payment processing APIs handling $2B+ in annual transaction volume',
        'Built merchant dashboard serving 500K+ businesses worldwide',
        'Implemented webhook delivery system with 99.95% reliability',
        'Contributed to open-source Stripe SDKs (Python, Ruby, Go)'
      ]
    }
  ],
  education: [
    {
      id: '1',
      degree: 'Master of Science',
      field: 'Computer Science',
      institution: 'Stanford University',
      location: 'Stanford, CA',
      graduationDate: '2016',
      gpa: '3.92/4.0'
    },
    {
      id: '2',
      degree: 'Bachelor of Science',
      field: 'Computer Engineering',
      institution: 'University of California, San Diego',
      location: 'San Diego, CA',
      graduationDate: '2014',
      gpa: '3.88/4.0',
      honors: ['Magna Cum Laude', 'Tau Beta Pi Engineering Honor Society']
    }
  ],
  skills: [
    { name: 'Go (Golang)', level: 'expert' },
    { name: 'Python', level: 'expert' },
    { name: 'TypeScript/JavaScript', level: 'expert' },
    { name: 'React & Next.js', level: 'advanced' },
    { name: 'Kubernetes & Docker', level: 'expert' },
    { name: 'Google Cloud Platform', level: 'expert' },
    { name: 'AWS', level: 'advanced' },
    { name: 'PostgreSQL & MySQL', level: 'expert' },
    { name: 'Redis & Memcached', level: 'advanced' },
    { name: 'Apache Kafka', level: 'expert' },
    { name: 'GraphQL & REST APIs', level: 'expert' },
    { name: 'System Design', level: 'expert' }
  ],
  certifications: [
    { id: '1', name: 'Google Cloud Professional Cloud Architect', issuer: 'Google Cloud', date: '2022', credentialId: 'GCP-284751' },
    { id: '2', name: 'AWS Solutions Architect Professional', issuer: 'Amazon Web Services', date: '2021', credentialId: 'AWS-829463' },
    { id: '3', name: 'Certified Kubernetes Administrator (CKA)', issuer: 'CNCF', date: '2020', credentialId: 'CKA-152847' }
  ],
  projects: [
    {
      id: '1',
      name: 'Distributed Task Queue',
      description: 'Open-source task queue handling millions of jobs with fault tolerance and exactly-once semantics.',
      technologies: ['Go', 'Redis', 'PostgreSQL', 'Docker'],
      url: 'github.com/mzhang/taskq',
      highlights: ['8,000+ GitHub stars', '50+ contributors', 'Used by 200+ companies']
    },
    {
      id: '2',
      name: 'Real-time Collaboration Engine',
      description: 'CRDT-based collaborative editing for documents, spreadsheets, and diagrams.',
      technologies: ['TypeScript', 'Rust', 'WebSocket', 'PostgreSQL'],
      highlights: ['Latency under 50ms', 'Handles 10K concurrent users', 'Patent pending']
    }
  ],
  achievements: [
    { id: '1', title: 'Google Peer Bonus Award', description: 'Recognition for exceptional open-source contributions', date: '2023' },
    { id: '2', title: 'Stripe Engineering Excellence Award', description: 'For fraud detection system impact', date: '2018' },
    { id: '3', title: 'Airbnb Superhost Hackathon Winner', description: 'Built AI-powered host pricing tool', date: '2020' }
  ],
  languages: [
    { name: 'English', proficiency: 'native' },
    { name: 'Mandarin Chinese', proficiency: 'native' },
    { name: 'Japanese', proficiency: 'conversational' }
  ],
  memberships: [
    { id: '1', organization: 'ACM - Association for Computing Machinery', startDate: '2016', current: true },
    { id: '2', organization: 'IEEE Computer Society', startDate: '2016', current: true }
  ],
  volunteer: [
    {
      id: '1',
      role: 'Code Squad Mentor',
      organization: 'CodeNow',
      location: 'San Francisco, CA',
      startDate: '2019',
      current: true,
      description: 'Teach programming fundamentals to underrepresented high school students'
    },
    {
      id: '2',
      role: 'Technical Advisor',
      organization: 'Climate Action Tech',
      location: 'Remote',
      startDate: '2022',
      current: true,
      description: 'Advise climate tech startups on scalable architecture and engineering practices'
    }
  ],
  references: [
    { id: '1', name: 'Sarah Kim', title: 'Engineering Director', company: 'Google', email: 's.kim@google.com', phone: '(650) 555-0100' },
    { id: '2', name: 'David Park', title: 'Principal Engineer', company: 'Airbnb', email: 'd.park@airbnb.com' }
  ]
};
