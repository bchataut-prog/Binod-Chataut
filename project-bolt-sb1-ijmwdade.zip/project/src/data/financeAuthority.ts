import type { ResumeData } from '../types/resume';

export const financeAuthorityData: ResumeData = {
  personalInfo: {
    fullName: 'Amanda K. Fitzgerald',
    title: 'Senior Financial Analyst',
    email: 'amanda.fitzgerald@email.com',
    phone: '(617) 555-0392',
    location: 'Boston, MA',
    linkedin: 'linkedin.com/in/amandafitzgerald'
  },
  summary: 'Detail-oriented Senior Financial Analyst with 9+ years of experience in financial modeling, forecasting, and strategic analysis for Fortune 500 financial institutions. Expert in building sophisticated financial models, conducting variance analysis, and delivering actionable insights to executive leadership. Proven track record of identifying revenue optimization opportunities worth $15M+ and implementing process improvements that enhanced reporting accuracy by 40%.',
  experience: [
    {
      id: '1',
      title: 'Senior Financial Analyst',
      company: 'State Street Global Advisors',
      location: 'Boston, MA',
      startDate: '2020',
      endDate: 'Present',
      current: true,
      highlights: [
        'Develop and maintain financial models for $25B portfolio covering P&L, balance sheet, and cash flow projections',
        'Lead monthly variance analysis and quarterly forecasting processes for CFO leadership team',
        'Built automated reporting dashboard reducing manual data compilation by 60 hours monthly',
        'Partner with business unit leaders to develop annual operating budgets totaling $180M',
        'Conducted ROI analysis for digital transformation initiative resulting in $12M approved investment',
        'Train and mentor team of 4 junior analysts on financial modeling best practices'
      ]
    },
    {
      id: '2',
      title: 'Financial Analyst',
      company: 'Fidelity Investments',
      location: 'Boston, MA',
      startDate: '2017',
      endDate: '2020',
      highlights: [
        'Prepared monthly management reports for technology division with $250M operating budget',
        'Developed scenario analysis models supporting strategic planning decisions',
        'Implemented rolling forecast methodology improving projection accuracy from 78% to 94%',
        'Co-led Sarbanes-Oxley compliance testing for revenue recognition controls',
        'Created training materials for financial systems serving 200+ end users'
      ]
    },
    {
      id: '3',
      title: 'Junior Financial Analyst',
      company: 'Liberty Mutual Insurance',
      location: 'Boston, MA',
      startDate: '2015',
      endDate: '2017',
      highlights: [
        'Supported annual budget development for claims operations department',
        'Performed ad-hoc financial analysis for regional business units',
        'Maintained accuracy of financial data in Hyperion planning system',
        'Prepared board presentation materials summarizing quarterly results'
      ]
    }
  ],
  education: [
    {
      id: '1',
      degree: 'Master of Science',
      field: 'Finance',
      institution: 'Boston College, Carroll School of Management',
      location: 'Chestnut Hill, MA',
      graduationDate: '2015',
      gpa: '3.88/4.0'
    },
    {
      id: '2',
      degree: 'Bachelor of Business Administration',
      field: 'Accounting',
      institution: 'University of Massachusetts Amherst',
      location: 'Amherst, MA',
      graduationDate: '2013',
      gpa: '3.75/4.0',
      honors: ['Cum Laude', 'Dean\'s List 6 semesters']
    }
  ],
  skills: [
    { name: 'Financial Modeling & Valuation', level: 'expert' },
    { name: 'Budgeting & Forecasting', level: 'expert' },
    { name: 'Variance Analysis', level: 'expert' },
    { name: 'Data Analysis (SQL, Python)', level: 'advanced' },
    { name: 'Microsoft Excel (Advanced)', level: 'expert' },
    { name: 'Power BI & Tableau', level: 'advanced' },
    { name: 'Hyperion Planning & Essbase', level: 'advanced' },
    { name: 'SAP ERP', level: 'intermediate' },
    { name: 'SOX Compliance', level: 'advanced' },
    { name: 'Executive Reporting', level: 'expert' }
  ],
  certifications: [
    { id: '1', name: 'Chartered Financial Analyst (CFA) Level III Candidate', issuer: 'CFA Institute', date: '2023' },
    { id: '2', name: 'Certified Public Accountant (CPA)', issuer: 'Massachusetts Board of Public Accountancy', date: '2018', credentialId: 'CPA-MA-45892' },
    { id: '3', name: 'Financial Modeling & Valuation Analyst (FMVA)', issuer: 'Corporate Finance Institute', date: '2021' }
  ],
  projects: [
    {
      id: '1',
      name: 'Revenue Attribution Model',
      description: 'Built multi-dimensional model attributing revenue to products, channels, and customer segments for $500M business.',
      technologies: ['Python', 'SQL', 'Power BI', 'Excel'],
      highlights: ['Identified $8M pricing optimization opportunity', 'Reduced reporting cycle from 5 days to 4 hours']
    },
    {
      id: '2',
      name: 'Zero-Based Budgeting Implementation',
      description: 'Led redesign of annual budgeting process implementing zero-based approach for IT department.',
      technologies: ['Hyperion Planning', 'Anaplan', 'PowerPoint'],
      highlights: ['Achieved 18% cost reduction', 'Improved budget variance to under 3%']
    }
  ],
  achievements: [
    { id: '1', title: 'Analyst of the Year', description: 'State Street Global Advisors - recognition for exceptional financial insights', date: '2022' },
    { id: '2', title: 'Innovation Award', description: 'Developed automated forecasting tool adopted globally', date: '2021' }
  ],
  languages: [
    { name: 'English', proficiency: 'native' },
    { name: 'French', proficiency: 'professional' }
  ],
  memberships: [
    { id: '1', organization: 'CFA Institute', startDate: '2018', current: true },
    { id: '2', organization: 'Financial Executives International - Boston Chapter', startDate: '2020', current: true },
    { id: '3', organization: 'American Institute of CPAs', startDate: '2018', current: true }
  ],
  volunteer: [
    {
      id: '1',
      role: 'Treasurer',
      organization: 'Boston Healthcare Finance Association',
      location: 'Boston, MA',
      startDate: '2021',
      current: true,
      description: 'Manage $45K annual budget and coordinate speaker events for 200+ member professional network'
    }
  ],
  references: [
    { id: '1', name: 'Michael R. Thompson', title: 'VP of Financial Planning & Analysis', company: 'State Street Global Advisors', email: 'm.thompson@ssga.com', phone: '(617) 555-0187' },
    { id: '2', name: 'Lisa Chen', title: 'Director of Finance', company: 'Fidelity Investments', email: 'l.chen@fidelity.com' }
  ]
};
