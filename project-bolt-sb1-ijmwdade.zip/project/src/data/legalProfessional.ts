import type { ResumeData } from '../types/resume';

export const legalProfessionalData: ResumeData = {
  personalInfo: {
    fullName: 'Jonathan R. Blackwell',
    title: 'Senior Corporate Attorney',
    email: 'jonathan.blackwell@email.com',
    phone: '(312) 555-0845',
    location: 'Chicago, IL',
    website: 'www.blackwell.law',
    linkedin: 'linkedin.com/in/jonathanblackwell'
  },
  summary: 'Accomplished Corporate Attorney with 14 years of experience in M&A, securities law, and corporate governance for Fortune 500 clients. Partner-track lawyer with proven track record of successfully closing 60+ M&A transactions valued at $12B+. Expert in regulatory compliance, due diligence, and complex negotiations. Recognized for building trusted advisor relationships with C-suite executives and boards while delivering pragmatic legal solutions that advance business objectives.',
  experience: [
    {
      id: '1',
      title: 'Senior Corporate Attorney',
      company: 'Morrison & Stern, LLP',
      location: 'Chicago, IL',
      startDate: '2018',
      endDate: 'Present',
      current: true,
      highlights: [
        'Lead M&A practice managing 15+ transactions annually valued at $500M-$2B',
        'Served as primary outside counsel for 8 publicly traded companies on corporate matters',
        'Successfully defended client in $850M hostile takeover attempt through strategic proxy fight',
        'Negotiated and closed 12 cross-border acquisitions across Europe and Asia',
        'Advise boards of directors on fiduciary duties, governance, and regulatory compliance',
        'Mentor associate attorneys and supervise legal team of 12 professionals'
      ]
    },
    {
      id: '2',
      title: 'Corporate Associate',
      company: 'Baker McKenzie',
      location: 'Chicago, IL',
      startDate: '2014',
      endDate: '2018',
      highlights: [
        'Supported senior partners on M&A transactions totaling $4.2B in deal value',
        'Conducted due diligence and drafted transaction documents for complex acquisitions',
        'Advised clients on SEC reporting obligations and corporate governance requirements',
        'Managed regulatory filings with DOJ and FTC for Hart-Scott-Rodino compliance',
        'Published 4 articles on corporate law topics in legal journals and industry publications'
      ]
    },
    {
      id: '3',
      title: 'Associate Attorney',
      company: 'Jenner & Block LLP',
      location: 'Chicago, IL',
      startDate: '2012',
      endDate: '2014',
      highlights: [
        'Conducted legal research and drafted memoranda on corporate and securities matters',
        'Assisted with litigation matters including shareholder derivative suits',
        'Participated in pro bono program representing nonprofit organizations'
      ]
    }
  ],
  education: [
    {
      id: '1',
      degree: 'Juris Doctor (JD)',
      field: 'Law',
      institution: 'Northwestern University Pritzker School of Law',
      location: 'Chicago, IL',
      graduationDate: '2012',
      honors: ['Order of the Coif', 'Northwestern University Law Review - Articles Editor', 'Cum Laude']
    },
    {
      id: '2',
      degree: 'Bachelor of Arts',
      field: 'Economics & Political Science',
      institution: 'University of Michigan',
      location: 'Ann Arbor, MI',
      graduationDate: '2009',
      gpa: '3.82/4.0',
      honors: ['Magna Cum Laude', 'Phi Beta Kappa']
    }
  ],
  skills: [
    { name: 'Mergers & Acquisitions', level: 'expert' },
    { name: 'Securities Law & SEC Compliance', level: 'expert' },
    { name: 'Corporate Governance', level: 'expert' },
    { name: 'Contract Negotiation & Drafting', level: 'expert' },
    { name: 'Due Diligence Management', level: 'expert' },
    { name: 'Regulatory Compliance', level: 'advanced' },
    { name: 'Board Advisory & Governance', level: 'expert' },
    { name: 'Cross-Border Transactions', level: 'advanced' },
    { name: 'Legal Research & Writing', level: 'expert' },
    { name: 'Client Relationship Management', level: 'expert' }
  ],
  certifications: [
    { id: '1', name: 'Licensed to Practice Law - Illinois', issuer: 'Illinois Supreme Court', date: '2012', credentialId: 'Bar No. 6328941' },
    { id: '2', name: 'Licensed to Practice Law - New York', issuer: 'New York Supreme Court', date: '2015', credentialId: 'Bar No. 5498237' },
    { id: '3', name: 'Certified Compliance & Ethics Professional (CCEP)', issuer: 'SCCE', date: '2019' }
  ],
  achievements: [
    { id: '1', title: 'Illinois Super Lawyers - Rising Star', description: 'Recognized as top young attorney in corporate law', date: '2018-2022' },
    { id: '2', title: 'Best Lawyers in America - Corporate Law', description: 'Peer-reviewed recognition for legal excellence', date: '2023' },
    { id: '3', title: 'Pro Bono Service Award', description: 'Chicago Bar Foundation for 500+ hours of pro bono legal work', date: '2021' }
  ],
  languages: [
    { name: 'English', proficiency: 'native' },
    { name: 'German', proficiency: 'professional' }
  ],
  memberships: [
    { id: '1', organization: 'American Bar Association - Business Law Section', role: 'Committee Vice Chair', startDate: '2019', current: true },
    { id: '2', organization: 'Chicago Bar Association', role: 'Corporate Law Committee Member', startDate: '2015', current: true },
    { id: '3', organization: 'Society of Corporate Secretaries & Governance Professionals', startDate: '2017', current: true }
  ],
  volunteer: [
    {
      id: '1',
      role: 'Pro Bono Counsel',
      organization: 'Greater Chicago Food Depository',
      location: 'Chicago, IL',
      startDate: '2019',
      current: true,
      description: 'Provide legal counsel on corporate governance, contracts, and regulatory compliance matters'
    },
    {
      id: '2',
      role: 'Board Member',
      organization: 'Chicago Legal Clinic',
      location: 'Chicago, IL',
      startDate: '2020',
      current: true,
      description: 'Support organization providing free legal services to underserved communities'
    }
  ],
  references: [
    { id: '1', name: 'William J. Harrington', title: 'Managing Partner', company: 'Morrison & Stern, LLP', email: 'w.harrington@morrisonstern.com', phone: '(312) 555-0100' },
    { id: '2', name: 'Catherine M. Davis', title: 'General Counsel', company: 'Midmark Industries', email: 'c.davis@midmark.com', phone: '(312) 555-0200' }
  ]
};
