import TemplateGallery from './components/TemplateGallery';

function App() {
  return <TemplateGallery />;
}

export default App;
