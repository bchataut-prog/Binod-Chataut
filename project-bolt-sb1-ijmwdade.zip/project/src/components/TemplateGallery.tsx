import { useState } from 'react';
import { templateMetadata, getTemplatesByCategory } from '../templates/templateRegistry';
import { sampleDataMap } from '../data';
import { Check,Award, Users, FileText, Image, Layers } from 'lucide-react';

import ExecutiveElite from '../templates/ExecutiveElite';
import CorporatePro from '../templates/CorporatePro';
import FinanceAuthority from '../templates/FinanceAuthority';
import HealthcareProfessional from '../templates/HealthcareProfessional';
import LegalProfessional from '../templates/LegalProfessional';
import EducationLeader from '../templates/EducationLeader';
import GovernmentProfessional from '../templates/GovernmentProfessional';
import ModernTech from '../templates/ModernTech';
import CreativeEdge from '../templates/CreativeEdge';
import PersonalBrand from '../templates/PersonalBrand';

const templateComponents: Record<string, React.ComponentType<{ data: any; className?: string }>> = {
  'executive-elite': ExecutiveElite,
  'corporate-pro': CorporatePro,
  'finance-authority': FinanceAuthority,
  'healthcare-professional': HealthcareProfessional,
  'legal-professional': LegalProfessional,
  'education-leader': EducationLeader,
  'government-professional': GovernmentProfessional,
  'modern-tech': ModernTech,
  'creative-edge': CreativeEdge,
  'personal-brand': PersonalBrand,
};

export default function TemplateGallery() {
  const [selectedTemplate, setSelectedTemplate] = useState('executive-elite');
  const [activeCategory, setActiveCategory] = useState<'all' | 'professional' | 'modern'>('all');

  const filteredTemplates = activeCategory === 'all'
    ? templateMetadata
    : getTemplatesByCategory(activeCategory);

  const SelectedComponent = templateComponents[selectedTemplate];
  const selectedData = sampleDataMap[selectedTemplate as keyof typeof sampleDataMap];
  const selectedMeta = templateMetadata.find(t => t.id === selectedTemplate);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <header className="bg-slate-900/80 backdrop-blur-sm border-b border-slate-700 sticky top-0 z-50">
        <div className="max-w-[1800px] mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-white">
                Resume Template Library
              </h1>
              <p className="text-sm text-slate-400 mt-1">
                10 production-ready templates for LunchResume
              </p>
            </div>
            <div className="flex items-center gap-4">
              <div className="flex gap-2">
                {(['all', 'professional', 'modern'] as const).map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setActiveCategory(cat)}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                      activeCategory === cat
                        ? 'bg-amber-500 text-slate-900'
                        : 'bg-slate-700 text-slate-300 hover:bg-slate-600'
                    }`}
                  >
                    {cat.charAt(0).toUpperCase() + cat.slice(1)}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-[1800px] mx-auto px-6 py-6">
        <div className="flex gap-6">
          {/* Template Selection Sidebar */}
          <aside className="w-80 shrink-0">
            <div className="bg-slate-800/50 rounded-xl border border-slate-700 p-4 sticky top-24">
              <h2 className="text-sm font-semibold text-slate-300 uppercase tracking-wider mb-4">
                Select Template
              </h2>
              <div className="space-y-2">
                {filteredTemplates.map((template) => (
                  <button
                    key={template.id}
                    onClick={() => setSelectedTemplate(template.id)}
                    className={`w-full text-left p-3 rounded-lg transition-all ${
                      selectedTemplate === template.id
                        ? 'bg-amber-500/20 border-amber-500/50 border'
                        : 'bg-slate-700/50 border border-transparent hover:bg-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className={`font-medium ${
                        selectedTemplate === template.id ? 'text-amber-400' : 'text-white'
                      }`}>
                        {template.name}
                      </span>
                      {selectedTemplate === template.id && (
                        <Check className="w-4 h-4 text-amber-400" />
                      )}
                    </div>
                    <p className="text-xs text-slate-400 mt-1 line-clamp-2">
                      {template.description}
                    </p>
                  </button>
                ))}
              </div>
            </div>
          </aside>

          {/* Main Preview Area */}
          <main className="flex-1">
            {/* Template Info Bar */}
            {selectedMeta && (
              <div className="bg-slate-800/50 rounded-xl border border-slate-700 p-4 mb-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-bold text-white">{selectedMeta.name}</h3>
                    <p className="text-sm text-slate-400">{selectedMeta.description}</p>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2 px-3 py-1.5 bg-green-500/20 rounded-lg">
                      <Award className="w-4 h-4 text-green-400" />
                      <span className="text-sm font-semibold text-green-400">
                        ATS Score: {selectedMeta.atsScore}%
                      </span>
                    </div>
                    <div className={`px-3 py-1.5 rounded-lg text-sm font-medium ${
                      selectedMeta.category === 'professional'
                        ? 'bg-blue-500/20 text-blue-400'
                        : 'bg-pink-500/20 text-pink-400'
                    }`}>
                      {selectedMeta.category.charAt(0).toUpperCase() + selectedMeta.category.slice(1)}
                    </div>
                  </div>
                </div>

                {/* Meta Info */}
                <div className="flex items-center gap-6 mt-4 pt-4 border-t border-slate-700">
                  <div className="flex items-center gap-2 text-sm text-slate-400">
                    <Users className="w-4 h-4" />
                    <span>{selectedMeta.targetAudience.slice(0, 3).join(', ')}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-slate-400">
                    <FileText className="w-4 h-4" />
                    <span>{selectedMeta.pagesSupported.length} page{selectedMeta.pagesSupported.length > 1 ? 's' : ''} supported</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-slate-400">
                    <Image className="w-4 h-4" />
                    <span>{selectedMeta.photoSupported ? 'Photo supported' : 'No photo'}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-slate-400">
                    <Layers className="w-4 h-4" />
                    <span>Best for: {selectedMeta.bestFor.slice(0, 3).join(', ')}</span>
                  </div>
                </div>
              </div>
            )}

            {/* Resume Preview */}
            <div className="bg-slate-800/30 rounded-xl border border-slate-700 p-6 overflow-auto">
              <div className="flex justify-center">
                <div className="shadow-2xl" style={{ transform: 'scale(0.75)', transformOrigin: 'top center' }}>
                  {SelectedComponent && selectedData && (
                    <SelectedComponent data={selectedData} />
                  )}
                </div>
              </div>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
}
