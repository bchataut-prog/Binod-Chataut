import React from 'react';

export interface SharedTemplateItem {
  slug: string;
  name: string;
  tag: string;
  type: '1-page' | '2-page';
  atsPercent: number;
  designDescription: string;
  preview: React.ReactNode;
}

export const resumeTemplates1Page: SharedTemplateItem[] = [
  {
    slug: "classic",
    name: "Classic Executive",
    tag: "Corporate",
    type: "1-page",
    atsPercent: 99,
    designDescription: "A conservative serif blueprint utilizing a rigid single-column structure to guarantee 100% accurate parser alignment. Ideal for finance and legal fields.",
    preview: (
      <div className="p-[2.2cqw] bg-white h-full flex flex-col justify-between text-left overflow-hidden" style={{fontFamily: 'Georgia, serif'}}>
        <div>
          {/* Name & Title Header */}
          <div className="border-b-[0.3cqw] border-[#1C2B33] pb-[0.8cqw] mb-[1.2cqw] text-center">
            <div style={{fontSize:'6.8cqw', fontWeight:'bold', color:'#1C2B33', letterSpacing:'0.05em', lineHeight:'1.1'}}>MARGARET CHEN, CPA</div>
            <div style={{fontSize:'3.5cqw', color:'#0F766E', fontWeight:'600', marginTop:'0.3cqw', letterSpacing:'0.08em'}}>CHIEF FINANCIAL OFFICER (CFO)</div>
            <div style={{fontSize:'2.1cqw', color:'#46504D', marginTop:'0.3cqw'}}>New York, NY • m.chen@email.com • (212) 555-0182</div>
          </div>

          {/* Summary */}
          <div className="mb-[1.2cqw]">
            <div style={{fontSize:'2.7cqw', fontWeight:'bold', color:'#1C2B33', textTransform:'uppercase', letterSpacing:'0.08em', borderBottom:'0.5px solid #E2E8E6', paddingBottom:'0.3cqw', marginBottom:'0.6cqw'}}>PROFESSIONAL SUMMARY</div>
            <div style={{fontSize:'2.1cqw', color:'#46504D', lineHeight:'1.3'}}>Strategic, high-impact CFO with 14+ years scaling multi-national finance divisions. Expert in corporate development, capital restructuring, and board reporting. Orchestrated Series C debt refinancing, securing $45M, and facilitated IPO with $400M valuation. Deliver double-digit margin enhancements.</div>
          </div>

          {/* Experience */}
          <div className="mb-[1.2cqw]">
            <div style={{fontSize:'2.7cqw', fontWeight:'bold', color:'#1C2B33', textTransform:'uppercase', letterSpacing:'0.08em', borderBottom:'0.5px solid #E2E8E6', paddingBottom:'0.3cqw', marginBottom:'0.6cqw'}}>PROFESSIONAL EXPERIENCE</div>
            
            <div style={{marginBottom:'0.6cqw'}}>
              <div style={{display:'flex', justifyContent:'space-between', fontSize:'2.3cqw', fontWeight:'bold', color:'#1C2B33'}}>
                <span>CFO — Meridian Capital Group</span><span style={{color:'#46504D', fontWeight:'400'}}>2020 – Pres</span>
              </div>
              <div style={{fontSize:'2.1cqw', color:'#46504D', lineHeight:'1.3', marginTop:'0.3cqw'}}>
                • Spearheaded global risk assessment, treasury, and $180M multi-entity budgets.<br/>
                • Reduced quarterly overhead by 18% through workflow automation.<br/>
                • Led finance team of 24 in raising $45M series C financing and debt restructuring.
              </div>
            </div>

            <div style={{marginBottom:'0.6cqw'}}>
              <div style={{display:'flex', justifyContent:'space-between', fontSize:'2.3cqw', fontWeight:'bold', color:'#1C2B33'}}>
                <span>VP of Finance — Sterling Holdings</span><span style={{color:'#46504D', fontWeight:'400'}}>2016 – 2020</span>
              </div>
              <div style={{fontSize:'2.1cqw', color:'#46504D', lineHeight:'1.3', marginTop:'0.3cqw'}}>
                • Governed strict P&L accountability for $75M capital portfolio, auditing tax structures.<br/>
                • Accelerated close processes by 4 days utilizing SAP S/4HANA ERP migration.
              </div>
            </div>

            <div style={{marginBottom:'0.6cqw'}}>
              <div style={{display:'flex', justifyContent:'space-between', fontSize:'2.3cqw', fontWeight:'bold', color:'#1C2B33'}}>
                <span>Financial Analyst — Goldman Sachs</span><span style={{color:'#46504D', fontWeight:'400'}}>2011 – 2016</span>
              </div>
              <div style={{fontSize:'2.1cqw', color:'#46504D', lineHeight:'1.3', marginTop:'0.3cqw'}}>
                • Executed statistical modeling for tech portfolios, advising on 11 transactions.
              </div>
            </div>
          </div>

          {/* Education & Certs split row */}
          <div style={{display:'grid', gridTemplateColumns:'55% 45%', gap:'2.5cqw', marginBottom:'1.2cqw'}}>
            <div>
              <div style={{fontSize:'2.7cqw', fontWeight:'bold', color:'#1C2B33', textTransform:'uppercase', letterSpacing:'0.08em', borderBottom:'0.5px solid #E2E8E6', paddingBottom:'0.3cqw', marginBottom:'0.6cqw'}}>EDUCATION</div>
              <div style={{fontSize:'2.2cqw', color:'#1C2B33', fontWeight:'600'}}>MBA, Finance — Wharton</div>
              <div style={{fontSize:'2.1cqw', color:'#46504D'}}>UPenn • GPA 3.9</div>
              <div style={{fontSize:'2.2cqw', color:'#1C2B33', fontWeight:'600', marginTop:'0.3cqw'}}>B.S. Economics — NYU Stern</div>
            </div>
            <div>
              <div style={{fontSize:'2.7cqw', fontWeight:'bold', color:'#1C2B33', textTransform:'uppercase', letterSpacing:'0.08em', borderBottom:'0.5px solid #E2E8E6', paddingBottom:'0.3cqw', marginBottom:'0.6cqw'}}>CERTIFICATIONS</div>
              <div style={{fontSize:'2.1cqw', color:'#46504D', lineHeight:'1.3'}}>
                • Certified Public Accountant (CPA)<br/>
                • Chartered Financial Analyst (CFA)<br/>
                • Wharton CFO Academy (2021)
              </div>
            </div>
          </div>
        </div>

        {/* Skills / Footer */}
        <div>
          <div style={{fontSize:'2.7cqw', fontWeight:'bold', color:'#1C2B33', textTransform:'uppercase', letterSpacing:'0.08em', borderBottom:'0.5px solid #E2E8E6', paddingBottom:'0.3cqw', marginBottom:'0.6cqw'}}>CORE COMPETENCIES</div>
          <div style={{fontSize:'2.1cqw', color:'#46504D', lineHeight:'1.3'}}>
            Financial Planning (FP&A) • Treasury • GAAP/IFRS Standards • M&A Due Diligence • ERP Systems Configuration • Board Communications • SOX Compliance • Restructuring • Risk Governance
          </div>
        </div>
      </div>
    )
  },
  {
    slug: "modern",
    name: "Tech Pro",
    tag: "Popular",
    type: "1-page",
    atsPercent: 98,
    designDescription: "A high-density sans-serif layout complete with clean structural dividers. Engineered specifically for technology, engineering, and product roles.",
    preview: (
      <div className="p-[2.2cqw] bg-white h-full flex flex-col justify-between text-left overflow-hidden" style={{fontFamily: 'system-ui, sans-serif'}}>
        <div>
          {/* Header */}
          <div className="mb-[1.2cqw]">
            <div style={{fontSize:'6.8cqw', fontWeight:'800', color:'#1C2B33'}}>ALEX RIVERA</div>
            <div style={{fontSize:'3.5cqw', color:'#0F766E', fontWeight:'700', marginTop:'0.3cqw'}}>Senior Full-Stack Engineer</div>
            <div style={{fontSize:'2cqw', color:'#46504D', marginTop:'0.3cqw'}}>San Francisco, CA • a.rivera@dev.io • (415) 555-0293</div>
            <div style={{height:'1px', background:'#0F766E', marginTop:'1cqw'}}></div>
          </div>

          {/* Summary */}
          <div className="mb-[1.2cqw]">
            <div style={{fontSize:'2.1cqw', color:'#46504D', lineHeight:'1.3'}}>Results-driven Full-Stack Engineer with 7+ years of experience engineering secure, scalable software products. Achieved major architectural upgrades for 2M+ active environments. Proficient in TypeScript, React, Go, and multi-cloud systems.</div>
          </div>

          {/* Experience */}
          <div className="mb-[1.2cqw]">
            <div style={{fontSize:'2.7cqw', fontWeight:'700', color:'#0F766E', textTransform:'uppercase', letterSpacing:'0.1em', marginBottom:'0.6cqw'}}>WORK EXPERIENCE</div>
            
            <div style={{marginBottom:'0.6cqw'}}>
              <div style={{display:'flex', justifyContent:'space-between', fontSize:'2.3cqw', fontWeight:'700', color:'#1C2B33'}}>
                <span>Senior Software Engineer — Notion</span><span style={{color:'#46504D', fontWeight:'400'}}>2022 – Pres</span>
              </div>
              <div style={{fontSize:'2.1cqw', color:'#46504D', lineHeight:'1.3', marginTop:'0.3cqw'}}>
                • Rebuilt editor pipeline, reducing load latency by 55% across 1.8M workspaces.<br/>
                • Spearheaded Webpack migration to Vite, reducing build times from 14 to 3.5 minutes.
              </div>
            </div>

            <div style={{marginBottom:'0.6cqw'}}>
              <div style={{display:'flex', justifyContent:'space-between', fontSize:'2.3cqw', fontWeight:'700', color:'#1C2B33'}}>
                <span>Software Engineer II — Stripe</span><span style={{color:'#46504D', fontWeight:'400'}}>2019 – 2022</span>
              </div>
              <div style={{fontSize:'2.1cqw', color:'#46504D', lineHeight:'1.3', marginTop:'0.3cqw'}}>
                • Designed dispute resolution platform processing $4B+ in transaction volume.<br/>
                • Architected high-throughput Redis caching, scaling API endpoint performance.
              </div>
            </div>
          </div>

          {/* Certifications */}
          <div style={{marginBottom:'1.2cqw', borderTop:'0.5px solid #E2E8E6', paddingTop:'1cqw'}}>
            <div style={{fontSize:'2.7cqw', fontWeight:'700', color:'#0F766E', textTransform:'uppercase', letterSpacing:'0.1em', marginBottom:'0.3cqw'}}>CERTIFICATIONS</div>
            <div style={{fontSize:'2.1cqw', color:'#46504D', lineHeight:'1.3'}}>
              • AWS Certified Solutions Architect &nbsp;&bull;&nbsp; Certified Kubernetes (CKA)
            </div>
          </div>
        </div>

        <div>
          {/* Tech Stack */}
          <div style={{fontSize:'2.7cqw', fontWeight:'700', color:'#0F766E', textTransform:'uppercase', letterSpacing:'0.1em', marginBottom:'0.6cqw'}}>TECH STACK & SKILLS</div>
          <div style={{display:'flex', flexWrap:'wrap', gap:'0.8cqw'}}>
            {['TypeScript','React','Node.js','Go','PostgreSQL','Redis','AWS','Docker','Kubernetes','CI/CD'].map(s => (
              <span key={s} style={{fontSize:'1.8cqw', background:'#F7F9F8', border:'0.5px solid #E2E8E6', color:'#0F766E', padding:'0.3cqw 1cqw', borderRadius:'1.5px', fontWeight:'600'}}>{s}</span>
            ))}
          </div>
          
          {/* Education */}
          <div style={{display:'flex', justifyContent:'space-between', alignItems:'baseline', marginTop:'1.2cqw', borderTop:'0.5px solid #E2E8E6', paddingTop:'1.2cqw'}}>
            <span style={{fontSize:'2.2cqw', fontWeight:'700', color:'#1C2B33'}}>B.S. CS — UC Berkeley</span>
            <span style={{fontSize:'2.1cqw', color:'#46504D'}}>GPA 3.8 / Class of 2018</span>
          </div>
        </div>
      </div>
    )
  },
  {
    slug: "minimalist",
    name: "Minimalist Slate",
    tag: "ATS Safe",
    type: "1-page",
    atsPercent: 99,
    designDescription: "An elegant, distraction-free aesthetic with generous margins and subtle details. Excellent for corporate directors, operations, and consultants.",
    preview: (
      <div className="p-[2.2cqw] bg-white h-full flex flex-col justify-between text-left overflow-hidden" style={{fontFamily:'system-ui, sans-serif'}}>
        <div>
          {/* Header */}
          <div className="mb-[1.2cqw]">
            <div style={{fontSize:'6.8cqw', fontWeight:'300', color:'#1C2B33', letterSpacing:'-0.02em', lineHeight:'1.1'}}>James Whitmore, PMP</div>
            <div style={{fontSize:'3.5cqw', color:'#46504D', marginTop:'0.3cqw', fontWeight:'400'}}>Operations & Logistics Director</div>
            <div style={{height:'0.5px', background:'#E2E8E6', margin:'1.5cqw 0'}}></div>
            <div style={{fontSize:'2cqw', color:'#46504D'}}>Chicago, IL  •  j.whitmore@ops.com  •  (312) 555-0147</div>
          </div>

          {/* Profile Summary */}
          <div className="mb-[1.2cqw]">
            <div style={{fontSize:'2.7cqw', fontWeight:'600', color:'#1C2B33', textTransform:'uppercase', letterSpacing:'0.15em', borderBottom:'0.5px solid #E2E8E6', paddingBottom:'0.3cqw', marginBottom:'0.6cqw'}}>Professional Profile</div>
            <div style={{fontSize:'2.1cqw', color:'#46504D', lineHeight:'1.3'}}>Efficient, strategic Director of Operations with 10+ years scaling shipping, warehouse, and logistics networks. Proven leader in boosting last-mile efficiency metrics and introducing modern WMS.</div>
          </div>

          {/* Experience */}
          <div className="mb-[1.2cqw]">
            <div style={{fontSize:'2.7cqw', fontWeight:'600', color:'#1C2B33', textTransform:'uppercase', letterSpacing:'0.15em', borderBottom:'0.5px solid #E2E8E6', paddingBottom:'0.3cqw', marginBottom:'0.6cqw'}}>Experience</div>
            
            <div style={{marginBottom:'0.6cqw'}}>
              <div style={{display:'flex', justifyContent:'space-between', fontSize:'2.3cqw', color:'#1C2B33', fontWeight:'600'}}>
                <span>Director of Operations — Apex Logistics</span><span style={{fontWeight:'400', color:'#46504D'}}>2021 – Pres</span>
              </div>
              <div style={{fontSize:'2.1cqw', color:'#46504D', lineHeight:'1.3', marginTop:'0.3cqw'}}>
                • Directed operations across 3 regional hubs with 34 personnel.<br/>
                • Reduced regional last-mile shipping overhead by 23% via routing.<br/>
                • Secured 99.2% SLA fulfillment rating across enterprise accounts.
              </div>
            </div>

            <div style={{marginBottom:'0.6cqw'}}>
              <div style={{display:'flex', justifyContent:'space-between', fontSize:'2.3cqw', color:'#1C2B33', fontWeight:'600'}}>
                <span>Operations Manager — BlueLine Supply</span><span style={{fontWeight:'400', color:'#46504D'}}>2017 – 2021</span>
              </div>
              <div style={{fontSize:'2.1cqw', color:'#46504D', lineHeight:'1.3', marginTop:'0.3cqw'}}>
                • Managed $28M supply assets, reducing physical shrinkage by 11%.
              </div>
            </div>
          </div>

          {/* Certifications & Education Split Column */}
          <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:'2.5cqw'}}>
            <div>
              <div style={{fontSize:'2.7cqw', fontWeight:'600', color:'#1C2B33', textTransform:'uppercase', letterSpacing:'0.15em', borderBottom:'0.5px solid #E2E8E6', paddingBottom:'0.3cqw', marginBottom:'0.6cqw'}}>Certifications</div>
              <div style={{fontSize:'2.1cqw', color:'#46504D', lineHeight:'1.3'}}>
                • Project Management (PMP)<br/>
                • Lean Six Sigma Green Belt
              </div>
            </div>
            <div>
              <div style={{fontSize:'2.7cqw', fontWeight:'600', color:'#1C2B33', textTransform:'uppercase', letterSpacing:'0.15em', borderBottom:'0.5px solid #E2E8E6', paddingBottom:'0.3cqw', marginBottom:'0.6cqw'}}>Education</div>
              <div style={{fontSize:'2.2cqw', color:'#1C2B33', fontWeight:'500'}}>B.S. Business Admin</div>
              <div style={{fontSize:'2.1cqw', color:'#46504D'}}>Univ of Illinois • GPA 3.7</div>
            </div>
          </div>
        </div>

        <div style={{borderTop:'0.5px solid #E2E8E6', paddingTop:'1cqw', marginTop:'1cqw'}}>
          <div style={{fontSize:'2.7cqw', fontWeight:'600', color:'#1C2B33', textTransform:'uppercase', letterSpacing:'0.15em', marginBottom:'0.3cqw'}}>Strategic Skills</div>
          <div style={{fontSize:'2.1cqw', color:'#46504D', lineHeight:'1.3'}}>
            Routing Optimization • Budgeting • WMS ERP Systems • Lean Workflows • Vendor Negotiation • KPI Metrics
          </div>
        </div>
      </div>
    )
  },
  {
    slug: "creative",
    name: "Creative Canvas",
    tag: "Bold",
    type: "1-page",
    atsPercent: 96,
    designDescription: "An asymmetrical layout with clean color blocks and custom grids. Designed to stand out in creative agencies, digital marketing, and design portfolios.",
    preview: (
      <div className="bg-white h-full flex text-left overflow-hidden" style={{fontFamily:'system-ui, sans-serif'}}>
        {/* Dark Sidebar */}
        <div className="flex flex-col justify-between p-[1.8cqw]" style={{width:'33%', background:'#1C2B33', minHeight:'100%'}}>
          {/* Initials & details */}
          <div>
            <div style={{fontSize:'8cqw', fontWeight:'800', color:'#8CFBD4', lineHeight:'1', marginBottom:'2cqw'}}>SL</div>
            <div style={{height:'1px', background:'rgba(140,251,212,0.3)', marginBottom:'2cqw'}}></div>
            
            <div style={{fontSize:'2.7cqw', fontWeight:'700', color:'#8CFBD4', textTransform:'uppercase', letterSpacing:'0.1em', marginBottom:'1cqw'}}>Contact</div>
            <div style={{fontSize:'2cqw', color:'rgba(255,255,255,0.7)', lineHeight:'1.4'}}>Sofia Lark<br/>Brooklyn, NY<br/>s.lark@studio.io</div>
            
            <div style={{height:'1px', background:'rgba(140,251,212,0.2)', margin:'2cqw 0'}}></div>
            
            <div style={{fontSize:'2.7cqw', fontWeight:'700', color:'#8CFBD4', textTransform:'uppercase', letterSpacing:'0.1em', marginBottom:'1cqw'}}>Expertise</div>
            <div style={{fontSize:'2cqw', color:'rgba(255,255,255,0.75)', lineHeight:'1.4'}}>Figma / Sketch<br/>Motion Design<br/>B2C Strategy<br/>React / Framer</div>

            <div style={{height:'1px', background:'rgba(140,251,212,0.2)', margin:'2cqw 0'}}></div>

            <div style={{fontSize:'2.7cqw', fontWeight:'700', color:'#8CFBD4', textTransform:'uppercase', letterSpacing:'0.1em', marginBottom:'1cqw'}}>Awards</div>
            <div style={{fontSize:'2cqw', color:'rgba(255,255,255,0.7)', lineHeight:'1.4'}}>• Awwwards SOTD<br/>• Webby UX 2024</div>
          </div>
          <div style={{fontSize:'2cqw', color:'rgba(140,251,212,0.5)', textTransform:'uppercase', letterSpacing:'0.1em', marginTop:'3cqw'}}>sofialark.design</div>
        </div>

        {/* Main Content */}
        <div className="flex flex-col justify-between p-[2.2cqw]" style={{width:'67%'}}>
          <div>
            <div style={{marginBottom:'1.2cqw'}}>
              <div style={{fontSize:'6.8cqw', fontWeight:'800', color:'#1C2B33', lineHeight:'1.1'}}>SOFIA LARK</div>
              <div style={{fontSize:'3.5cqw', color:'#0F766E', fontWeight:'700', marginTop:'0.3cqw'}}>Creative Director & Experience Lead</div>
              <div style={{height:'1px', background:'#8CFBD4', marginTop:'1cqw', width:'60%'}}></div>
            </div>

            <div style={{fontSize:'2.1cqw', color:'#46504D', lineHeight:'1.3', marginBottom:'1.5cqw'}}>
              Award-winning creative director with 9+ years defining unified digital experience and brand design infrastructure for global clients.
            </div>

            <div style={{fontSize:'2.7cqw', fontWeight:'700', color:'#1C2B33', textTransform:'uppercase', letterSpacing:'0.12em', marginBottom:'1cqw', borderBottom:'0.5px solid #E2E8E6', paddingBottom:'0.3cqw'}}>Experience</div>

            <div style={{marginBottom:'1.2cqw'}}>
              <div style={{display:'flex', justifyContent:'space-between', fontSize:'2.3cqw', fontWeight:'700', color:'#1C2B33'}}>
                <span>Creative Director — Wren Studio</span><span style={{color:'#46504D', fontWeight:'400'}}>2021 – Pres</span>
              </div>
              <div style={{fontSize:'2.1cqw', color:'#46504D', lineHeight:'1.3', marginTop:'0.3cqw'}}>
                • Rebranded for 20+ consumer tech products, raising conversion by 38%.<br/>
                • Mentored high-performing creative team of 7 senior artists.
              </div>
            </div>

            <div style={{marginBottom:'1.2cqw'}}>
              <div style={{display:'flex', justifyContent:'space-between', fontSize:'2.3cqw', fontWeight:'700', color:'#1C2B33'}}>
                <span>Senior UX — Instrument</span><span style={{color:'#46504D', fontWeight:'400'}}>2018 – 2021</span>
              </div>
              <div style={{fontSize:'2.1cqw', color:'#46504D', lineHeight:'1.3', marginTop:'0.3cqw'}}>
                • Designed Nike Mobile app workflows, elevating Day-30 customer retention by 28%.
              </div>
            </div>
          </div>

          <div>
            {/* Special Projects & Education */}
            <div style={{borderTop:'0.5px solid #E2E8E6', paddingTop:'1.2cqw'}}>
              <div>
                <div style={{fontSize:'2.5cqw', fontWeight:'700', color:'#1C2B33', textTransform:'uppercase', letterSpacing:'0.12em', paddingBottom:'0.3cqw', marginBottom:'0.3cqw'}}>Education</div>
                <div style={{fontSize:'2.2cqw', fontWeight:'600', color:'#1C2B33'}}>BFA — Parsons</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  },
  {
    slug: "healthcare",
    name: "Clinical Director",
    tag: "Healthcare",
    type: "1-page",
    atsPercent: 98,
    designDescription: "A crisp, structured healthcare blueprint with clinical blue accents, designed for nurse directors, medical managers, and senior clinical staff.",
    preview: (
      <div className="p-[2.2cqw] bg-white h-full flex flex-col justify-between text-left overflow-hidden" style={{fontFamily: 'system-ui, sans-serif'}}>
        <div>
          <div className="border-b-[0.3cqw] border-sky-800 pb-[0.8cqw] mb-[1.2cqw]">
            <div style={{fontSize:'6.8cqw', fontWeight:'bold', color:'#0369A1'}}>DR. SARAH JENKINS, DNP</div>
            <div style={{fontSize:'3.5cqw', color:'#0284C7', fontWeight:'600', marginTop:'0.3cqw'}}>CLINICAL NURSE DIRECTOR</div>
          </div>
          <div style={{fontSize:'2.1cqw', color:'#46504D'}}>Denver, CO • s.jenkins@health-lead.com</div>
        </div>
      </div>
    )
  },
  {
    slug: "data-analyst",
    name: "Analytics Prime",
    tag: "Data Science",
    type: "1-page",
    atsPercent: 99,
    designDescription: "A high-density data-rich blueprint with deep navy accents, designed for data analysts, business intelligence leads, and data scientists.",
    preview: (
      <div className="p-[2.2cqw] bg-white h-full flex flex-col justify-between text-left overflow-hidden" style={{fontFamily: 'system-ui, sans-serif'}}>
        <div>
          <div className="border-b-[0.3cqw] border-indigo-900 pb-[0.8cqw] mb-[1.2cqw]">
            <div style={{fontSize:'6.8cqw', fontWeight:'bold', color:'#1E1B4B'}}>ELENA ROSTOVA</div>
            <div style={{fontSize:'3.5cqw', color:'#312E81', fontWeight:'600', marginTop:'0.3cqw'}}>LEAD BUSINESS INTELLIGENCE ANALYST</div>
          </div>
          <div style={{fontSize:'2.1cqw', color:'#46504D'}}>Austin, TX • e.rostova@data-insights.net</div>
        </div>
      </div>
    )
  }
];

export const resumeTemplates2Page: SharedTemplateItem[] = [
  {
    slug: "classic",
    name: "Classic Executive Extended",
    tag: "Leadership",
    type: "2-page",
    atsPercent: 99,
    designDescription: "An expansive traditional serif system designed for senior leaders, C-suite executives, and distinguished officers requiring standard chronological precision.",
    preview: (
      <div className="relative w-full h-full bg-[#fcfdfd] overflow-hidden" style={{fontFamily:'Georgia, serif'}}>
        {/* PAGE 2 */}
        <div className="absolute right-[3%] bottom-[3%] w-[84%] h-[84%] p-[2cqw] bg-white border border-stone-200/60 rounded-xl shadow-md overflow-hidden transform rotate-2 origin-bottom-right transition-transform duration-300 group-hover:rotate-4 flex flex-col justify-between" style={{ containerType: 'inline-size' }}>
          <div style={{position:'absolute', top:'1cqw', right:'2cqw', fontSize:'2.2cqw', color:'#0F766E', fontWeight:'bold', textTransform:'uppercase', letterSpacing:'0.1em'}}>Page 2</div>
          <div>
            {/* Experience continued */}
            <div style={{marginBottom:'1cqw'}}>
              <div style={{fontSize:'2.6cqw', fontWeight:'bold', textTransform:'uppercase', letterSpacing:'0.1em', color:'#1C2B33', borderBottom:'0.5px solid #E2E8E6', paddingBottom:'0.3cqw', marginBottom:'0.6cqw'}}>EXPERIENCE (CONTINUED)</div>
              <div style={{marginBottom:'0.6cqw'}}>
                <div style={{display:'flex', justifyContent:'space-between', fontSize:'2.3cqw', fontWeight:'bold', color:'#1C2B33'}}>
                  <span>President & COO — Meridian Tech</span><span style={{color:'#46504D', fontWeight:'400', fontSize:'2cqw'}}>2015 – 19</span>
                </div>
                <div style={{fontSize:'2.1cqw', color:'#46504D', lineHeight:'1.3', marginTop:'0.2cqw'}}>
                  • Directed day-to-day operations across 6 offices.<br/>
                  • Standardized corporate objectives via OKRs.
                </div>
              </div>
            </div>

            {/* Board & Advisory */}
            <div style={{marginBottom:'1cqw'}}>
              <div style={{fontSize:'2.6cqw', fontWeight:'bold', textTransform:'uppercase', letterSpacing:'0.1em', color:'#1C2B33', borderBottom:'0.5px solid #E2E8E6', paddingBottom:'0.3cqw', marginBottom:'0.6cqw'}}>BOARD & ADVISORY</div>
              <div style={{fontSize:'2.1cqw', color:'#46504D', lineHeight:'1.3'}}>
                • <strong>Director:</strong> Elevate Ventures — 2022 – Pres<br/>
                • <strong>Advisory:</strong> TechStars Boston Cohort Panel
              </div>
            </div>
          </div>

          <div>
            {/* Education */}
            <div style={{marginBottom:'0.6cqw', borderTop:'0.5px solid #E2E8E6', paddingTop:'1cqw'}}>
              <div style={{fontSize:'2.6cqw', fontWeight:'bold', textTransform:'uppercase', letterSpacing:'0.1em', color:'#1C2B33', marginBottom:'0.2cqw'}}>EDUCATION</div>
              <div style={{display:'flex', justifyContent:'space-between', fontSize:'2.2cqw', fontWeight:'700', color:'#1C2B33'}}>
                <span>MBA — Harvard Business School</span>
                <span style={{color:'#46504D', fontWeight:'400', fontSize:'2cqw'}}>2006</span>
              </div>
            </div>
          </div>
        </div>

        {/* PAGE 1 */}
        <div className="absolute left-[3%] top-[3%] w-[84%] h-[84%] p-[2cqw] bg-white border border-stone-200/80 rounded-xl shadow-lg overflow-hidden transform -rotate-1 origin-bottom-left transition-transform duration-300 group-hover:-rotate-3 flex flex-col justify-between" style={{ containerType: 'inline-size' }}>
          <div style={{position:'absolute', top:'1cqw', right:'2cqw', fontSize:'2.2cqw', color:'#0F766E', fontWeight:'bold', textTransform:'uppercase', letterSpacing:'0.1em'}}>Page 1</div>
          
          <div>
            {/* Header */}
            <div style={{textAlign:'center', borderBottom:'1px solid #1C2B33', paddingBottom:'0.6cqw', marginBottom:'1cqw'}}>
              <div style={{fontSize:'6cqw', fontWeight:'bold', color:'#1C2B33', letterSpacing:'0.05em', lineHeight:'1.1'}}>RICHARD HARLOW, CFA</div>
              <div style={{fontSize:'3.2cqw', color:'#0F766E', fontWeight:'600', marginTop:'0.2cqw', letterSpacing:'0.08em'}}>CHIEF EXECUTIVE OFFICER</div>
              <div style={{fontSize:'2.1cqw', color:'#46504D', marginTop:'0.3cqw'}}>Boston, MA • r.harlow@executive.com</div>
            </div>

            {/* Executive Summary */}
            <div style={{marginBottom:'1cqw'}}>
              <div style={{fontSize:'2.6cqw', fontWeight:'bold', textTransform:'uppercase', letterSpacing:'0.1em', color:'#1C2B33', borderBottom:'0.5px solid #E2E8E6', paddingBottom:'0.3cqw', marginBottom:'0.6cqw'}}>EXECUTIVE SUMMARY</div>
              <div style={{fontSize:'2.1cqw', color:'#46504D', lineHeight:'1.3'}}>Visionary CEO scaling B2B SaaS firms from growth-stage to acquisition with significant value. Raised $120M in venture capital across 3 rounds.</div>
            </div>

            {/* Core Competencies */}
            <div style={{marginBottom:'1cqw'}}>
              <div style={{fontSize:'2.6cqw', fontWeight:'bold', textTransform:'uppercase', letterSpacing:'0.1em', color:'#1C2B33', borderBottom:'0.5px solid #E2E8E6', paddingBottom:'0.3cqw', marginBottom:'0.6cqw'}}>CORE STRATEGIC COMPETENCIES</div>
              <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:'0.3cqw', fontSize:'2cqw', color:'#46504D'}}>
                <span>• P&L Management ($120M+)</span><span>• Enterprise M&A Strategy</span>
                <span>• Joint Ventures & Alliances</span><span>• SaaS Scaled Expansion</span>
              </div>
            </div>
          </div>

          {/* Experience P1 */}
          <div>
            <div style={{fontSize:'2.6cqw', fontWeight:'bold', textTransform:'uppercase', letterSpacing:'0.1em', color:'#1C2B33', borderBottom:'0.5px solid #E2E8E6', paddingBottom:'0.3cqw', marginBottom:'0.6cqw'}}>PROFESSIONAL EXPERIENCE</div>
            <div>
              <div style={{display:'flex', justifyContent:'space-between', fontSize:'2.3cqw', fontWeight:'bold', color:'#1C2B33'}}>
                <span>CEO — Vantage Systems Inc.</span><span style={{color:'#46504D', fontWeight:'400', fontSize:'2cqw'}}>2019 – Pres</span>
              </div>
              <div style={{fontSize:'2.1cqw', color:'#46504D', lineHeight:'1.3', marginTop:'0.2cqw'}}>
                • Expanded ARR from $18M to $104M in 4 years.<br/>
                • Slashed net monthly churn from 4.2% to 0.9%.
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  },
  {
    slug: "modern",
    name: "Tech Pro Extended",
    tag: "Engineering",
    type: "2-page",
    atsPercent: 98,
    designDescription: "A massive, deep data-density layout ideal for Senior Architects, Principal Engineers, and Directors requiring extensive room for patents, projects, and skills.",
    preview: (
      <div className="relative w-full h-full bg-[#fcfdfd] overflow-hidden" style={{fontFamily:'system-ui, sans-serif'}}>
        {/* PAGE 2 */}
        <div className="absolute right-[3%] bottom-[3%] w-[84%] h-[84%] p-[2cqw] bg-white border border-stone-200/60 rounded-xl shadow-md overflow-hidden transform rotate-2 origin-bottom-right transition-transform duration-300 group-hover:rotate-4 flex flex-col justify-between" style={{ containerType: 'inline-size' }}>
          <div style={{position:'absolute', top:'1cqw', right:'2cqw', fontSize:'2.2cqw', color:'#0F766E', fontWeight:'bold', textTransform:'uppercase', letterSpacing:'0.1em'}}>Page 2</div>
          <div>
            {/* Experience continued */}
            <div style={{marginBottom:'1cqw'}}>
              <div style={{fontSize:'2.5cqw', fontWeight:'700', color:'#0F766E', textTransform:'uppercase', letterSpacing:'0.12em', borderBottom:'0.5px solid #E2E8E6', paddingBottom:'0.3cqw', marginBottom:'0.6cqw'}}>EXPERIENCE (CONTINUED)</div>
              <div style={{marginBottom:'0.6cqw'}}>
                <div style={{display:'flex', justifyContent:'space-between', fontSize:'2.2cqw', fontWeight:'700', color:'#1C2B33'}}>
                  <span>Staff Systems Engineer — Uber</span><span style={{color:'#46504D', fontWeight:'400', fontSize:'2cqw'}}>2016 – 20</span>
                </div>
                <div style={{fontSize:'2.1cqw', color:'#46504D', lineHeight:'1.3', marginTop:'0.2cqw'}}>
                  • Overhauled driver dispatch matching algorithm, decreasing ETAs by 22% globally.<br/>
                  • Standardized gRPC across 40+ microservices, trimming bandwidth by 35%.
                </div>
              </div>
            </div>

            {/* Certs and Open Source */}
            <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:'1.5cqw', marginBottom:'0.6cqw'}}>
              <div>
                <div style={{fontSize:'2.5cqw', fontWeight:'700', color:'#0F766E', textTransform:'uppercase', letterSpacing:'0.12em', borderBottom:'0.5px solid #E2E8E6', paddingBottom:'0.3cqw', marginBottom:'0.3cqw'}}>OPEN SOURCE</div>
                <div style={{fontSize:'2.1cqw', color:'#46504D', lineHeight:'1.3'}}>
                  • <strong>distrib-cache:</strong> High-perf Go cache.
                </div>
              </div>
              <div>
                <div style={{fontSize:'2.5cqw', fontWeight:'700', color:'#0F766E', textTransform:'uppercase', letterSpacing:'0.12em', borderBottom:'0.5px solid #E2E8E6', paddingBottom:'0.3cqw', marginBottom:'0.3cqw'}}>CERTIFICATIONS</div>
                <div style={{fontSize:'2.1cqw', color:'#46504D', lineHeight:'1.3'}}>
                  • Kubernetes Security (CKS)
                </div>
              </div>
            </div>
          </div>

          <div>
            {/* Patents */}
            <div style={{marginBottom:'0.6cqw', borderTop:'0.5px solid #E2E8E6', paddingTop:'1cqw'}}>
              <div style={{fontSize:'2.5cqw', fontWeight:'700', color:'#0F766E', textTransform:'uppercase', letterSpacing:'0.12em', marginBottom:'0.2cqw'}}>PATENTS</div>
              <div style={{fontSize:'2.1cqw', color:'#46504D', lineHeight:'1.3'}}>
                • US Patent #11,234,567: "Adaptive Routing Protocols"
              </div>
            </div>
          </div>
        </div>

        {/* PAGE 1 */}
        <div className="absolute left-[3%] top-[3%] w-[84%] h-[84%] p-[2cqw] bg-white border border-stone-200/80 rounded-xl shadow-lg overflow-hidden transform -rotate-1 origin-bottom-left transition-transform duration-300 group-hover:-rotate-3 flex flex-col justify-between" style={{ containerType: 'inline-size' }}>
          <div style={{position:'absolute', top:'1cqw', right:'2cqw', fontSize:'2.2cqw', color:'#0F766E', fontWeight:'bold', textTransform:'uppercase', letterSpacing:'0.1em'}}>Page 1</div>
          <div>
            {/* Header */}
            <div style={{marginBottom:'1cqw'}}>
              <div style={{fontSize:'6cqw', fontWeight:'800', color:'#1C2B33'}}>PRIYA NAIR</div>
              <div style={{fontSize:'3.2cqw', color:'#0F766E', fontWeight:'700', marginTop:'0.2cqw'}}>Principal Software Architect</div>
              <div style={{height:'1px', background:'#0F766E', margin:'0.6cqw 0'}}></div>
              <div style={{fontSize:'2.1cqw', color:'#46504D'}}>Seattle, WA • p.nair@arch.dev</div>
            </div>

            {/* Summary */}
            <div style={{fontSize:'2.1cqw', color:'#46504D', lineHeight:'1.3', marginBottom:'1cqw'}}>
              Systems Architect with 12+ years of expertise designing globally distributed databases, transaction engines, and core SaaS platforms.
            </div>

            {/* Skills Grid */}
            <div style={{marginBottom:'1cqw'}}>
              <div style={{fontSize:'2.5cqw', fontWeight:'700', color:'#0F766E', textTransform:'uppercase', letterSpacing:'0.12em', borderBottom:'0.5px solid #E2E8E6', paddingBottom:'0.3cqw', marginBottom:'0.6cqw'}}>TECH STACK & CORE EXPERTISE</div>
              <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:'0.3cqw'}}>
                {[
                  ['Languages','Go, Rust, TypeScript, SQL'],
                  ['Cloud & Infra','Kubernetes, Terraform, AWS']
                ].map(([k,v]) => (
                  <div key={k} style={{fontSize:'2cqw'}}>
                    <span style={{fontWeight:'700', color:'#1C2B33'}}>{k}: </span>
                    <span style={{color:'#46504D'}}>{v}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Experience P1 */}
          <div>
            <div style={{fontSize:'2.5cqw', fontWeight:'700', color:'#0F766E', textTransform:'uppercase', letterSpacing:'0.12em', borderBottom:'0.5px solid #E2E8E6', paddingBottom:'0.3cqw', marginBottom:'0.6cqw'}}>PROFESSIONAL EXPERIENCE</div>
            <div>
              <div style={{display:'flex', justifyContent:'space-between', fontSize:'2.2cqw', fontWeight:'700', color:'#1C2B33'}}>
                <span>Principal Architect — AWS</span><span style={{color:'#46504D', fontWeight:'400', fontSize:'2cqw'}}>2020 – Pres</span>
              </div>
              <div style={{fontSize:'2.1cqw', color:'#46504D', lineHeight:'1.3', marginTop:'0.2cqw'}}>
                • Designed multi-region replication, facilitating 800M requests daily.<br/>
                • Optimized container clusters, reducing cloud spend by 64%.
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  },
  {
    slug: "minimalist",
    name: "Minimalist Slate Extended",
    tag: "ATS Safe",
    type: "2-page",
    atsPercent: 99,
    designDescription: "A minimalist, space-conscious double-page system. Tailored for researchers, general managers, and operational experts needing high structure with zero clutter.",
    preview: (
      <div className="relative w-full h-full bg-[#fcfdfd] overflow-hidden" style={{fontFamily:'system-ui, sans-serif'}}>
        {/* PAGE 2 */}
        <div className="absolute right-[3%] bottom-[3%] w-[84%] h-[84%] p-[2cqw] bg-white border border-stone-200/60 rounded-xl shadow-md overflow-hidden transform rotate-2 origin-bottom-right transition-transform duration-300 group-hover:rotate-4 flex flex-col justify-between" style={{ containerType: 'inline-size' }}>
          <div style={{position:'absolute', top:'1cqw', right:'2cqw', fontSize:'2.2cqw', color:'#0F766E', fontWeight:'bold', textTransform:'uppercase', letterSpacing:'0.1em'}}>Page 2</div>
          <div>
            {/* Experience Continued */}
            <div style={{marginBottom:'1cqw'}}>
              <div style={{fontSize:'2.5cqw', fontWeight:'600', color:'#1C2B33', textTransform:'uppercase', letterSpacing:'0.12em', borderBottom:'0.5px solid #E2E8E6', paddingBottom:'0.3cqw', marginBottom:'0.6cqw'}}>EXPERIENCE (CONTINUED)</div>
              <div style={{marginBottom:'0.6cqw'}}>
                <div style={{display:'flex', justifyContent:'space-between', fontSize:'2.2cqw', fontWeight:'600', color:'#1C2B33'}}>
                  <span>General Manager — BlueLine</span><span style={{color:'#46504D', fontWeight:'400', fontSize:'2cqw'}}>2017 – 21</span>
                </div>
                <div style={{fontSize:'2.1cqw', color:'#46504D', lineHeight:'1.3', marginTop:'0.2cqw'}}>
                  • Governed inventory tracking $28M in assets, reducing shrinkage by 11%.<br/>
                  • Standardized automated WMS software, reducing errors to 0.4%.
                </div>
              </div>
            </div>

            {/* Credentials */}
            <div style={{marginBottom:'1cqw'}}>
              <div style={{fontSize:'2.5cqw', fontWeight:'600', color:'#1C2B33', textTransform:'uppercase', letterSpacing:'0.12em', borderBottom:'0.5px solid #E2E8E6', paddingBottom:'0.3cqw', marginBottom:'0.3cqw'}}>CREDENTIALS</div>
              <div style={{fontSize:'2.1cqw', color:'#46504D', lineHeight:'1.3'}}>
                • Project Management (PMP)
              </div>
            </div>
          </div>

          <div>
            {/* Education */}
            <div style={{borderTop:'0.5px solid #E2E8E6', paddingTop:'1cqw'}}>
              <div style={{fontSize:'2.5cqw', fontWeight:'600', color:'#1C2B33', textTransform:'uppercase', letterSpacing:'0.12em', marginBottom:'0.2cqw'}}>ACADEMIC COMPLIANCE</div>
              <div style={{fontSize:'2.1cqw', fontWeight:'700', color:'#1C2B33'}}>
                B.S. Business Admin — Univ of Illinois
              </div>
            </div>
          </div>
        </div>

        {/* PAGE 1 */}
        <div className="absolute left-[3%] top-[3%] w-[84%] h-[84%] p-[2cqw] bg-white border border-stone-200/80 rounded-xl shadow-lg overflow-hidden transform -rotate-1 origin-bottom-left transition-transform duration-300 group-hover:-rotate-3 flex flex-col justify-between" style={{ containerType: 'inline-size' }}>
          <div style={{position:'absolute', top:'1cqw', right:'2cqw', fontSize:'2.2cqw', color:'#0F766E', fontWeight:'bold', textTransform:'uppercase', letterSpacing:'0.1em'}}>Page 1</div>
          <div>
            {/* Header */}
            <div style={{marginBottom:'1cqw'}}>
              <div style={{fontSize:'6cqw', fontWeight:'300', color:'#1C2B33', letterSpacing:'-0.01em'}}>JAMES WHITMORE, PMP</div>
              <div style={{fontSize:'3.2cqw', color:'#46504D', marginTop:'0.2cqw', fontWeight:'500'}}>DIRECTOR OF OPERATIONS & LOGISTICS</div>
              <div style={{height:'1px', background:'#E2E8E6', margin:'0.6cqw 0'}}></div>
              <div style={{fontSize:'2.1cqw', color:'#46504D'}}>Chicago, IL • j.whitmore@ops.com</div>
            </div>

            {/* Profile Summary */}
            <div style={{marginBottom:'1cqw'}}>
              <div style={{fontSize:'2.5cqw', fontWeight:'600', color:'#1C2B33', textTransform:'uppercase', letterSpacing:'0.12em', borderBottom:'0.5px solid #E2E8E6', paddingBottom:'0.3cqw', marginBottom:'0.6cqw'}}>PROFESSIONAL MATRIX</div>
              <div style={{fontSize:'2.1cqw', color:'#46504D', lineHeight:'1.3'}}>Director with 10+ years scaling shipping networks, logistics hubs, and vendor relations. Slashed operations spend by 23%.</div>
            </div>

            {/* Core Competencies */}
            <div style={{marginBottom:'1cqw'}}>
              <div style={{fontSize:'2.5cqw', fontWeight:'600', color:'#1C2B33', textTransform:'uppercase', letterSpacing:'0.12em', borderBottom:'0.5px solid #E2E8E6', paddingBottom:'0.3cqw', marginBottom:'0.6cqw'}}>OPERATING RANGE</div>
              <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:'0.3cqw', fontSize:'2cqw', color:'#46504D'}}>
                <span>• Supply Chain Logistics Setup</span><span>• ERP & WMS Administration</span>
                <span>• P&L Operating Budget Setup</span><span>• Project Governance (PMP)</span>
              </div>
            </div>
          </div>

          {/* Work Experience P1 */}
          <div>
            <div style={{fontSize:'2.5cqw', fontWeight:'600', color:'#1C2B33', textTransform:'uppercase', letterSpacing:'0.12em', borderBottom:'0.5px solid #E2E8E6', paddingBottom:'0.3cqw', marginBottom:'0.6cqw'}}>WORK EXPERIENCE</div>
            <div>
              <div style={{display:'flex', justifyContent:'space-between', fontSize:'2.2cqw', fontWeight:'600', color:'#1C2B33'}}>
                <span>Director — Apex Logistics Ltd.</span><span style={{color:'#46504D', fontWeight:'400', fontSize:'2cqw'}}>2021 – Pres</span>
              </div>
              <div style={{fontSize:'2.1cqw', color:'#46504D', lineHeight:'1.3', marginTop:'0.2cqw'}}>
                • Slashed freight expenses by 23% by centralizing routes.<br/>
                • Achieved 99.2% customer performance ratings.
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  },
  {
    slug: "creative",
    name: "Creative Canvas Extended",
    tag: "Bold",
    type: "2-page",
    atsPercent: 96,
    designDescription: "An immersive, two-page layout featuring a striking dark lateral panel and rich creative formatting. Ideal for designers, media creators, and marketing directors.",
    preview: (
      <div className="relative w-full h-full bg-[#fcfdfd] overflow-hidden" style={{fontFamily:'system-ui, sans-serif'}}>
        {/* PAGE 2 */}
        <div className="absolute right-[3%] bottom-[3%] w-[84%] h-[84%] bg-white border border-stone-200/60 rounded-xl shadow-md overflow-hidden transform rotate-2 origin-bottom-right transition-transform duration-300 group-hover:rotate-4 flex" style={{ containerType: 'inline-size' }}>
          <div style={{position:'absolute', top:'1cqw', right:'2cqw', fontSize:'2.2cqw', color:'#8CFBD4', fontWeight:'bold', textTransform:'uppercase', letterSpacing:'0.1em', zIndex:10}}>Page 2</div>

          {/* Sidebar Left Page 2 */}
          <div style={{width:'32%', background:'#1C2B33', padding:'2cqw', color:'white', display:'flex', flexDirection:'column', justifyContent:'space-between'}}>
            <div>
              <div style={{fontSize:'2.3cqw', fontWeight:'700', color:'#8CFBD4', textTransform:'uppercase', letterSpacing:'0.05em', marginBottom:'0.3cqw'}}>RECOGNITIONS</div>
              <div style={{fontSize:'2cqw', color:'rgba(255,255,255,0.8)', lineHeight:'1.3'}}>
                • Awwwards SOTD<br/>
                • Webby UX Honoree
              </div>
            </div>
          </div>

          {/* Main column Page 2 */}
          <div style={{width:'68%', padding:'2cqw', display:'flex', flexDirection:'column', justifyContent:'space-between'}}>
            <div>
              <div style={{fontSize:'2.5cqw', fontWeight:'700', color:'#1C2B33', textTransform:'uppercase', letterSpacing:'0.1em', paddingBottom:'0.3cqw', marginBottom:'0.6cqw', borderBottom:'0.5px solid #E2E8E6'}}>EXPERIENCE (CONTINUED)</div>
              
              <div>
                <div style={{display:'flex', justifyContent:'space-between', fontSize:'2.2cqw', fontWeight:'700', color:'#1C2B33'}}>
                  <span>Senior UX — Instrument</span><span style={{color:'#46504D', fontWeight:'400', fontSize:'2cqw'}}>2018 – 21</span>
                </div>
                <div style={{fontSize:'2.1cqw', color:'#46504D', lineHeight:'1.3', marginTop:'0.2cqw'}}>
                  • Spearheaded app design, boosting repeat engagement indexes by 28%.
                </div>
              </div>
            </div>

            <div>
              {/* Academic credentials */}
              <div style={{borderTop:'0.5px solid #E2E8E6', paddingTop:'1cqw', marginTop:'0.6cqw'}}>
                <div style={{fontSize:'2.3cqw', fontWeight:'700', color:'#1C2B33', textTransform:'uppercase', letterSpacing:'0.05em', marginBottom:'0.2cqw'}}>EDUCATION</div>
                <div style={{fontSize:'2.1cqw', fontWeight:'700', color:'#1C2B33'}}>
                  BFA — Parsons School
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* PAGE 1 */}
        <div className="absolute left-[3%] top-[3%] w-[84%] h-[84%] bg-white border border-stone-200/80 rounded-xl shadow-lg overflow-hidden transform -rotate-1 origin-bottom-left transition-transform duration-300 group-hover:-rotate-3 flex" style={{ containerType: 'inline-size' }}>
          <div style={{position:'absolute', top:'1cqw', right:'2cqw', fontSize:'2.2cqw', color:'#0F766E', fontWeight:'bold', textTransform:'uppercase', letterSpacing:'0.1em', zIndex:10}}>Page 1</div>
          
          {/* Sidebar Left */}
          <div style={{width:'32%', background:'#1C2B33', padding:'2cqw', color:'white', display:'flex', flexDirection:'column', justifyContent:'space-between'}}>
            <div>
              <div style={{fontSize:'5.5cqw', fontWeight:'900', color:'#8CFBD4', marginBottom:'1cqw'}}>SL</div>
              <div style={{height:'1px', background:'rgba(140,251,212,0.3)', marginBottom:'1cqw'}}></div>
              
              <div style={{fontSize:'2.3cqw', fontWeight:'700', color:'#8CFBD4', textTransform:'uppercase', letterSpacing:'0.05em', marginBottom:'0.2cqw'}}>Contact</div>
              <div style={{fontSize:'2cqw', color:'rgba(255,255,255,0.8)', lineHeight:'1.3', marginBottom:'1cqw'}}>
                Sofia Lark<br/>Brooklyn, NY<br/>s.lark@studio.io
              </div>

              <div style={{fontSize:'2.3cqw', fontWeight:'700', color:'#8CFBD4', textTransform:'uppercase', letterSpacing:'0.05em', marginBottom:'0.2cqw'}}>Skills</div>
              <div style={{fontSize:'2cqw', color:'rgba(255,255,255,0.8)', lineHeight:'1.3'}}>
                Figma / Sketch<br/>Motion Design
              </div>
            </div>
            <div style={{fontSize:'1.8cqw', color:'rgba(140,251,212,0.4)'}}>sofialark.design</div>
          </div>

          {/* Main column Page 1 */}
          <div style={{width:'68%', padding:'2cqw', display:'flex', flexDirection:'column', justifyContent:'space-between'}}>
            <div>
              <div style={{marginBottom:'1cqw'}}>
                <div style={{fontSize:'5.5cqw', fontWeight:'800', color:'#1C2B33', lineHeight:'1'}}>SOFIA LARK</div>
                <div style={{fontSize:'3cqw', color:'#0F766E', fontWeight:'700', marginTop:'0.2cqw'}}>Creative Lead</div>
                <div style={{height:'1px', background:'#8CFBD4', marginTop:'0.3cqw', width:'40%'}}></div>
              </div>

              <div style={{fontSize:'2.1cqw', color:'#46504D', lineHeight:'1.3', marginBottom:'1.2cqw'}}>
                Director with 9+ years defining unified experiences. Boosted campaign clickthrough indexes by 38%.
              </div>

              <div style={{fontSize:'2.5cqw', fontWeight:'700', color:'#1C2B33', textTransform:'uppercase', letterSpacing:'0.1em', paddingBottom:'0.3cqw', marginBottom:'0.6cqw', borderBottom:'0.5px solid #E2E8E6'}}>PROFESSIONAL</div>
              
              <div>
                <div style={{display:'flex', justifyContent:'space-between', fontSize:'2.2cqw', fontWeight:'700', color:'#1C2B33'}}>
                  <span>Director — Wren Studio</span><span style={{color:'#46504D', fontWeight:'400', fontSize:'2cqw'}}>2021 – Pres</span>
                </div>
                <div style={{fontSize:'2.1cqw', color:'#46504D', lineHeight:'1.3', marginTop:'0.2cqw'}}>
                  • Reconstructed brand identity for 20+ lines.<br/>
                  • Managed 7 remote curators.
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  },
  {
    slug: "healthcare",
    name: "Clinical Nurse Director Extended",
    tag: "Medical",
    type: "2-page",
    atsPercent: 98,
    designDescription: "A clinical and healthcare director blueprint styled with calming slate blue headers and deep organizational charts, optimized for medical board standards.",
    preview: (
      <div className="relative w-full h-full bg-[#fcfdfd] overflow-hidden" style={{fontFamily:'system-ui, sans-serif'}}>
        <div style={{padding:'2cqw', fontSize:'2cqw'}}>Clinical Nurse Director Preview</div>
      </div>
    )
  },
  {
    slug: "data-analyst",
    name: "Analytics Leader Extended",
    tag: "Data Science",
    type: "2-page",
    atsPercent: 99,
    designDescription: "A deep data-density analytics showcase. Features rich metric alignments, SQL capability charts, and predictive analysis timelines.",
    preview: (
      <div className="relative w-full h-full bg-[#fcfdfd] overflow-hidden" style={{fontFamily:'system-ui, sans-serif'}}>
        <div style={{padding:'2cqw', fontSize:'2cqw'}}>Data Analyst Preview</div>
      </div>
    )
  }
];
