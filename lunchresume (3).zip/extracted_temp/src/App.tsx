/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Routes, Route, useNavigate, useLocation } from 'react-router-dom';
import { 
  Menu, X, ChevronRight, ShieldCheck
} from 'lucide-react';

import siteConfig from '../content/siteConfig.json';
import { SiteConfig } from '../types/content';

import { HomePage } from './pages/HomePage';
import { ResumeBuilderPage } from './pages/ResumeBuilderPage';
import { CoverLetterPage } from './pages/CoverLetterPage';
import { BlogPage } from './pages/BlogPage';
import { BlogPostPage } from './pages/BlogPostPage';
import { ResumeExamplesIndexPage } from './pages/ResumeExamplesIndexPage';
import { ResumeExamplePage } from './pages/ResumeExamplePage';
import { ResumeTemplatesIndexPage } from './pages/ResumeTemplatesIndexPage';
import { ResumeTemplatePage } from './pages/ResumeTemplatePage';
import { CoverLetterExamplesIndexPage } from './pages/CoverLetterExamplesIndexPage';
import { CoverLetterExamplePage } from './pages/CoverLetterExamplePage';
import { OwnerDashboardPage, OwnerRouteGuard } from './pages/OwnerDashboardPage';

const typedSiteConfig = siteConfig as SiteConfig;

const App: React.FC = () => {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavigation = (path: string, sectionId?: string) => (e?: React.MouseEvent) => {
    if (e) e.preventDefault();
    setMenuOpen(false);
    
    if (location.pathname !== path) {
      navigate(path);
      if (sectionId) {
        setTimeout(() => {
          const element = document.getElementById(sectionId);
          if (element) {
            const headerOffset = 80;
            const elementPosition = element.getBoundingClientRect().top;
            const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
            window.scrollTo({
              top: offsetPosition,
              behavior: 'smooth'
            });
          }
        }, 300);
      } else {
        window.scrollTo({ top: 0, behavior: 'instant' });
      }
    } else {
      if (sectionId) {
        const element = document.getElementById(sectionId);
        if (element) {
          const headerOffset = 85;
          const elementPosition = element.getBoundingClientRect().top;
          const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
          window.scrollTo({
            top: offsetPosition,
            behavior: 'smooth'
          });
        }
      } else {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    }
  };

  return (
    <div className="min-h-screen bg-white text-[#1A1F1E] font-sans selection:bg-[#0F766E]/20 selection:text-[#1A1F1E]">
      
      {/* Dynamic Navigation (Inspired by Resume.io) */}
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'bg-white shadow-sm py-3 border-b border-[#E2E8E6]' : 'bg-white/95 backdrop-blur-md py-4 border-b border-[#E2E8E6]/60'}`}>
        <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
          
          {/* Logo & Brand Container */}
          <div className="flex items-center gap-10">
            <div className="flex items-center gap-2 cursor-pointer" onClick={handleNavigation('/')}>
              {/* Modern Minimalist Bookmark/Doc Icon in #0F766E */}
              <div className="w-8 h-8 bg-[#0F766E] text-white rounded-lg flex items-center justify-center font-semibold text-[15px] shadow-sm animate-none">
                {typedSiteConfig.logoAcronym}
              </div>
              <span className="font-semibold text-lg tracking-tight text-[#1C2B33] flex items-center">
                {typedSiteConfig.name.substring(0, 5)}<span className="text-[#1C2B33] font-normal">{typedSiteConfig.nameSuffix}</span>
                <span className="w-1.5 h-1.5 rounded-full bg-[#0F766E] ml-1"></span>
              </span>
            </div>

            {/* Desktop Center Links */}
            <div className="hidden lg:flex items-center gap-6 text-[13.5px] font-medium text-[#46504D]">
              <div className="relative group">
                <a 
                  href="/resume-templates" 
                  onClick={handleNavigation('/resume-templates')} 
                  className={`hover:text-[#0F766E] transition-colors flex items-center gap-1 cursor-pointer py-1 ${location.pathname === '/resume-templates' ? 'text-[#1C2B33] font-semibold' : ''}`}
                >
                  Resume Templates
                </a>
                <div className={`absolute bottom-0 left-0 right-0 h-0.5 bg-[#0F766E] transition-transform duration-200 ${location.pathname === '/resume-templates' ? 'scale-x-100' : 'scale-x-0 group-hover:scale-x-100'}`}></div>
              </div>

              <div className="relative group">
                <a 
                  href="/resume-examples" 
                  onClick={handleNavigation('/resume-examples')} 
                  className={`hover:text-[#0F766E] transition-colors flex items-center gap-1 cursor-pointer py-1 ${location.pathname === '/resume-examples' ? 'text-[#1C2B33] font-semibold' : ''}`}
                >
                  Resume Examples
                </a>
                <div className={`absolute bottom-0 left-0 right-0 h-0.5 bg-[#0F766E] transition-transform duration-200 ${location.pathname === '/resume-examples' ? 'scale-x-100' : 'scale-x-0 group-hover:scale-x-100'}`}></div>
              </div>

              <div className="relative group">
                <a 
                  href="/cover-letter-examples" 
                  onClick={handleNavigation('/cover-letter-examples')} 
                  className={`hover:text-[#0F766E] transition-colors flex items-center gap-1 cursor-pointer py-1 ${location.pathname === '/cover-letter-examples' ? 'text-[#1C2B33] font-semibold' : ''}`}
                >
                  Cover Letter Examples
                </a>
                <div className={`absolute bottom-0 left-0 right-0 h-0.5 bg-[#0F766E] transition-transform duration-200 ${location.pathname === '/cover-letter-examples' ? 'scale-x-100' : 'scale-x-0 group-hover:scale-x-100'}`}></div>
              </div>

              <div className="relative group">
                <a 
                  href="/resume-builder" 
                  onClick={handleNavigation('/resume-builder')} 
                  className={`hover:text-[#0F766E] transition-colors flex items-center gap-1 cursor-pointer py-1 ${location.pathname === '/resume-builder' ? 'text-[#1C2B33] font-semibold' : ''}`}
                >
                  Resume Builder
                </a>
                <div className={`absolute bottom-0 left-0 right-0 h-0.5 bg-[#0F766E] transition-transform duration-200 ${location.pathname === '/resume-builder' ? 'scale-x-100' : 'scale-x-0 group-hover:scale-x-100'}`}></div>
              </div>

              <div className="relative group">
                <a 
                  href="/cover-letter-builder" 
                  onClick={handleNavigation('/cover-letter-builder')} 
                  className={`hover:text-[#0F766E] transition-colors flex items-center gap-1 cursor-pointer py-1 ${location.pathname === '/cover-letter-builder' ? 'text-[#1C2B33] font-semibold' : ''}`}
                >
                  Cover Letter Builder
                </a>
                <div className={`absolute bottom-0 left-0 right-0 h-0.5 bg-[#0F766E] transition-transform duration-200 ${location.pathname === '/cover-letter-builder' ? 'scale-x-100' : 'scale-x-0 group-hover:scale-x-100'}`}></div>
              </div>

              <div className="relative group">
                <a 
                  href="/blog" 
                  onClick={handleNavigation('/blog')} 
                  className={`hover:text-[#0F766E] transition-colors flex items-center gap-1 cursor-pointer py-1 ${location.pathname === '/blog' || location.pathname.startsWith('/blog/') ? 'text-[#1C2B33] font-semibold' : ''}`}
                >
                  Blog
                </a>
                <div className={`absolute bottom-0 left-0 right-0 h-0.5 bg-[#0F766E] transition-transform duration-200 ${location.pathname === '/blog' || location.pathname.startsWith('/blog/') ? 'scale-x-100' : 'scale-x-0 group-hover:scale-x-100'}`}></div>
              </div>
            </div>
          </div>
          
          {/* Desktop Right Buttons (No login, deep teal CTA) */}
          <div className="hidden lg:flex items-center gap-6">
            <button 
              onClick={handleNavigation('/resume-builder')}
              className="px-5 py-2.5 bg-[#0F766E] text-white font-medium text-[14px] rounded-lg hover:bg-[#0F766E]/90 hover:scale-[1.02] active:scale-95 transition-all shadow-sm cursor-pointer border border-[#0F766E]"
            >
              {typedSiteConfig.links.cta}
            </button>
          </div>

          {/* Mobile buttons: always visible primary CTA and hamburger */}
          <div className="flex items-center gap-3 lg:hidden">
            <button 
              onClick={handleNavigation('/resume-builder')}
              className="px-4 py-2 bg-[#0F766E] text-white font-medium text-[13px] rounded-lg hover:bg-[#0F766E]/90 active:scale-95 transition-all shadow-xs cursor-pointer border border-[#0F766E]"
            >
              Create Resume
            </button>
            <button className="text-[#1C2B33] p-2 hover:bg-[#F7F9F8] rounded-lg transition-colors cursor-pointer" onClick={() => setMenuOpen(!menuOpen)}>
              {menuOpen ? <X size={22} className="text-[#1C2B33]" /> : <Menu size={22} className="text-[#1C2B33]" />}
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile drawer */}
      {menuOpen && (
        <div className="fixed inset-0 z-40 bg-white flex flex-col justify-between p-8 pt-24 shadow-2xl">
          {/* Nav Links */}
          <div className="flex flex-col gap-4 text-base font-semibold">
            <a 
              href="/resume-templates" 
              onClick={handleNavigation('/resume-templates')} 
              className="text-[#1A1F1E] hover:text-[#0F766E] py-2.5 border-b border-[#E2E8E6] flex justify-between items-center transition-all"
            >
              <span>Resume Templates</span>
              <ChevronRight size={16} className="text-[#46504D]" />
            </a>
            <a 
              href="/resume-examples" 
              onClick={handleNavigation('/resume-examples')} 
              className="text-[#1A1F1E] hover:text-[#0F766E] py-2.5 border-b border-[#E2E8E6] flex justify-between items-center transition-all"
            >
              <span>Resume Examples</span>
              <ChevronRight size={16} className="text-[#46504D]" />
            </a>
            <a 
              href="/cover-letter-examples" 
              onClick={handleNavigation('/cover-letter-examples')} 
              className="text-[#1A1F1E] hover:text-[#0F766E] py-2.5 border-b border-[#E2E8E6] flex justify-between items-center transition-all"
            >
              <span>Cover Letter Examples</span>
              <ChevronRight size={16} className="text-[#46504D]" />
            </a>
            <a 
              href="/resume-builder" 
              onClick={handleNavigation('/resume-builder')} 
              className="text-[#1A1F1E] hover:text-[#0F766E] py-2.5 border-b border-[#E2E8E6] flex justify-between items-center transition-all"
            >
              <span>Resume Builder</span>
              <ChevronRight size={16} className="text-[#46504D]" />
            </a>
            <a 
              href="/cover-letter-builder" 
              onClick={handleNavigation('/cover-letter-builder')} 
              className="text-[#1A1F1E] hover:text-[#0F766E] py-2.5 border-b border-[#E2E8E6] flex justify-between items-center transition-all"
            >
              <span>Cover Letter Builder</span>
              <ChevronRight size={16} className="text-[#46504D]" />
            </a>
            <a 
              href="/blog" 
              onClick={handleNavigation('/blog')} 
              className="text-[#1A1F1E] hover:text-[#0F766E] py-2.5 border-b border-[#E2E8E6] flex justify-between items-center transition-all"
            >
              <span>Blog</span>
              <ChevronRight size={16} className="text-[#46504D]" />
            </a>
          </div>

          {/* Action Footer for Mobile */}
          <div className="flex flex-col gap-4 mt-8">
            <button 
              onClick={(e) => {
                setMenuOpen(false);
                handleNavigation('/resume-builder')(e);
              }}
              className="w-full text-center py-3.5 bg-[#0F766E] text-white font-bold rounded-xl shadow-md hover:bg-[#0F766E]/90 cursor-pointer text-[14px]"
            >
              {typedSiteConfig.links.cta}
            </button>
          </div>
        </div>
      )}

      {/* --- DECLARATIVE ROUTER VIEW AREA --- */}
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/resume-builder" element={<ResumeBuilderPage />} />
        <Route path="/cover-letter-builder" element={<CoverLetterPage />} />
        <Route path="/blog" element={<BlogPage />} />
        <Route path="/blog/:slug" element={<BlogPostPage />} />
        <Route path="/resume-examples" element={<ResumeExamplesIndexPage />} />
        <Route path="/resume-examples/:slug" element={<ResumeExamplePage />} />
        <Route path="/resume-templates" element={<ResumeTemplatesIndexPage />} />
        <Route path="/resume-templates/:slug" element={<ResumeTemplatePage />} />
        <Route path="/cover-letter-examples" element={<CoverLetterExamplesIndexPage />} />
        <Route path="/cover-letter-examples/:slug" element={<CoverLetterExamplePage />} />
        <Route path="/owner" element={
          <OwnerRouteGuard>
            <OwnerDashboardPage />
          </OwnerRouteGuard>
        } />
      </Routes>

      {/* FOOTER */}
      <footer className="bg-[#1C2B33] text-[#F2F7F5]/80 py-16 border-t border-[#E2E8E6]/20">
        <div className="container mx-auto px-6 max-w-7xl">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-10 mb-12">
            {/* Brand column */}
            <div className="lg:col-span-2 text-left">
              <div className="text-[#F2F7F5] font-sans font-bold text-xl mb-4 tracking-wide cursor-pointer flex items-center gap-1.5" onClick={handleNavigation('/')}>
                {typedSiteConfig.footer.title}<span className="text-[#8CFBD4]">{typedSiteConfig.footer.titleColored}</span>
              </div>
              <p className="text-[13.5px] text-[#F2F7F5]/70 max-w-sm leading-relaxed mb-6">
                {typedSiteConfig.footer.description}
              </p>
            </div>

            {/* Column 1: Build */}
            <div className="text-left">
              <h5 className="text-[#F2F7F5] font-sans font-semibold text-[14px] uppercase tracking-wider mb-4">Build</h5>
              <ul className="space-y-2.5 text-[13.5px]">
                <li><a href="/resume-builder" onClick={handleNavigation('/resume-builder')} className="hover:text-[#8CFBD4] transition-colors cursor-pointer">Resume Builder</a></li>
                <li><a href="/cover-letter-builder" onClick={handleNavigation('/cover-letter-builder')} className="hover:text-[#8CFBD4] transition-colors cursor-pointer">Cover Letter Builder</a></li>
              </ul>
            </div>

            {/* Column 2: Explore */}
            <div className="text-left">
              <h5 className="text-[#F2F7F5] font-sans font-semibold text-[14px] uppercase tracking-wider mb-4">Explore</h5>
              <ul className="space-y-2.5 text-[13.5px]">
                <li><a href="/resume-templates" onClick={handleNavigation('/resume-templates')} className="hover:text-[#8CFBD4] transition-colors cursor-pointer">Resume Templates</a></li>
                <li><a href="/resume-examples" onClick={handleNavigation('/resume-examples')} className="hover:text-[#8CFBD4] transition-colors cursor-pointer">Resume Examples</a></li>
                <li><a href="/cover-letter-examples" onClick={handleNavigation('/cover-letter-examples')} className="hover:text-[#8CFBD4] transition-colors cursor-pointer">Cover Letter Examples</a></li>
              </ul>
            </div>

            {/* Column 3: Company & Legal */}
            <div className="text-left font-sans">
              <h5 className="text-[#F2F7F5] font-sans font-semibold text-[14px] uppercase tracking-wider mb-4">Company</h5>
              <ul className="space-y-2.5 text-[13.5px] mb-6">
                <li><a href="/blog" onClick={handleNavigation('/blog')} className="hover:text-[#8CFBD4] transition-colors cursor-pointer">Blog</a></li>
                <li><a href="#contact" onClick={(e) => { e.preventDefault(); alert("Contact: support@lunchresume.com"); }} className="hover:text-[#8CFBD4] transition-colors cursor-pointer">Contact</a></li>
              </ul>
              <h5 className="text-[#F2F7F5] font-sans font-semibold text-[14px] uppercase tracking-wider mb-4">Legal</h5>
              <ul className="space-y-2.5 text-[13.5px]">
                <li><a href="#privacy" onClick={(e) => e.preventDefault()} className="hover:text-[#8CFBD4] transition-colors cursor-pointer">Privacy Policy</a></li>
                <li><a href="#terms" onClick={(e) => e.preventDefault()} className="hover:text-[#8CFBD4] transition-colors cursor-pointer">Terms of Use</a></li>
              </ul>
            </div>
          </div>
          
          {/* Verification Seals */}
          <div className="mt-8 pt-8 border-t border-[#E2E8E6]/20 flex flex-col sm:flex-row justify-between items-center gap-4 text-[13px] text-[#F2F7F5]/60 animate-none">
            <div className="flex items-center gap-1.5 font-sans">
              <ShieldCheck size={14} className="text-[#8CFBD4]" />
              <span>{typedSiteConfig.footer.sandboxedLabel}</span>
            </div>
            <div className="text-center sm:text-right font-sans">
              <span>{typedSiteConfig.footer.copyright}</span>
            </div>
          </div>
        </div>
      </footer>

    </div>
  );
};

export default App;
