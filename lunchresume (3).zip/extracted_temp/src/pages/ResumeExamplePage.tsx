/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, ChevronRight, FileText, Sparkles, Building, ListTodo, Award } from 'lucide-react';
import RESUME_EXAMPLES from '../../content/resumeExamples.json';
import { ResumeExample } from '../../types/content';
import { SEO } from '../components/SEO';
import { ArticleSchema, BreadcrumbSchema } from '../components/Schema';

const typedResumeExamples = RESUME_EXAMPLES as ResumeExample[];

export const ResumeExamplePage: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();

  const example = typedResumeExamples.find(ex => ex.slug === slug);

  const handleBackToArchive = () => {
    navigate('/resume-examples');
    window.scrollTo({ top: 0, behavior: 'instant' });
  };

  const currentSlug = slug || '';

  // Get other examples for the "Related Resume Examples" internal linking block
  const relatedExamples = typedResumeExamples.filter(ex => ex.slug !== currentSlug);

  if (!example) {
    return (
      <div className="pt-28 pb-24 max-w-7xl mx-auto px-6 text-center">
        <SEO 
          title="Resume Example Not Found | LunchResume" 
          description="The requested resume example could not be found." 
          canonical="https://lunchresume.com/resume-examples" 
        />
        <BreadcrumbSchema 
          items={[
            { name: 'Home', item: 'https://lunchresume.com/' },
            { name: 'Resume Examples', item: 'https://lunchresume.com/resume-examples' },
            { name: 'Not Found', item: 'https://lunchresume.com/resume-examples' }
          ]}
        />
        <h2 className="font-serif text-2xl text-stone-900 mb-4 font-normal">Resume Example not found</h2>
        <p className="text-stone-600 mb-6 max-w-md mx-auto">
          We could not locate the requested industry profile template. Browse our archive to see all available templates.
        </p>
        <button 
          onClick={handleBackToArchive}
          className="inline-flex items-center gap-2 text-xs font-mono font-bold text-[#2a8767] hover:text-[#1d6148] transition-colors"
        >
          <ArrowLeft size={14} /> Back to Resume Archive
        </button>
      </div>
    );
  }

  const canonicalUrl = `https://lunchresume.com/resume-examples/${example.slug}`;

  return (
    <div className="pt-28 pb-24 max-w-7xl mx-auto px-6">
      <SEO 
        title={example.seoTitle} 
        description={example.seoDescription} 
        canonical={canonicalUrl} 
      />
      <ArticleSchema 
        title={example.seoTitle}
        excerpt={example.seoDescription}
        datePublished="2026-06-21"
        canonicalUrl={canonicalUrl}
      />
      <BreadcrumbSchema 
        items={[
          { name: 'Home', item: 'https://lunchresume.com/' },
          { name: 'Resume Examples', item: 'https://lunchresume.com/resume-examples' },
          { name: example.jobTitle, item: canonicalUrl }
        ]}
      />

      <div className="max-w-4xl mx-auto">
        {/* Back Link */}
        <button 
          onClick={handleBackToArchive}
          className="inline-flex items-center gap-2 text-xs font-mono font-bold text-[#2a8767] hover:text-[#1d6148] transition-colors mb-6 cursor-pointer"
        >
          <ArrowLeft size={14} /> Back to Archive
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Template Content */}
          <div className="lg:col-span-2 space-y-8 text-left">
            <div className="bg-white border border-stone-200 rounded-2xl p-6 sm:p-10 shadow-xs">
              {/* Profile Header */}
              <div className="border-b border-stone-100 pb-6 mb-6">
                <div className="inline-flex items-center gap-1.5 mb-2 px-2.5 py-0.5 bg-[#8cfbd4]/15 text-stone-800 text-[9px] tracking-widest uppercase font-extrabold rounded-full border border-[#8cfbd4]/30">
                  {example.industry}
                </div>
                <h1 className="font-serif text-3xl sm:text-4xl text-stone-900 font-normal">
                  {example.jobTitle} Template Outline
                </h1>
                <p className="text-stone-500 text-xs font-mono mt-1">
                  CALIBRATION METRIC: 100% SECURE & ATS-PARSEABLE
                </p>
              </div>

              {/* Dynamic Sections */}
              <div className="space-y-6">
                {/* Executive Summary */}
                <div>
                  <h3 className="font-serif text-lg font-bold text-stone-900 mb-2 flex items-center gap-2">
                    <Sparkles size={16} className="text-[#3ea884]" />
                    Professional Summary
                  </h3>
                  <p className="text-stone-650 text-sm leading-relaxed bg-stone-50 p-4 rounded-xl border border-stone-200/50">
                    {example.summary}
                  </p>
                </div>

                {/* Sample Core Experience */}
                <div>
                  <h3 className="font-serif text-lg font-bold text-stone-900 mb-2 flex items-center gap-2">
                    <Building size={16} className="text-stone-500" />
                    Target Experience Statements
                  </h3>
                  <div className="space-y-3">
                    {example.sampleExperience.map((exp, index) => (
                      <div key={index} className="flex gap-3 text-sm">
                        <span className="text-[#3ea884] font-bold font-mono">0{index + 1}.</span>
                        <p className="text-stone-600 leading-relaxed">{exp}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Core Skills Matrix */}
                <div>
                  <h3 className="font-serif text-lg font-bold text-stone-900 mb-2 flex items-center gap-2">
                    <ListTodo size={16} className="text-stone-500" />
                    Recommended Core Competencies
                  </h3>
                  <p className="text-stone-500 text-xs mb-3">
                    Bypass core algorithmic filters by listing these precise system keywords on your resume draft:
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {example.sampleSkills.map((skill, index) => (
                      <span 
                        key={index}
                        className="text-stone-750 bg-stone-100 border border-stone-200 px-3 py-1 rounded-lg text-xs font-mono"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Key Achievements */}
                <div>
                  <h3 className="font-serif text-lg font-bold text-stone-900 mb-2 flex items-center gap-2">
                    <Award size={16} className="text-stone-500" />
                    Measurable Accomplishments
                  </h3>
                  <div className="space-y-2">
                    {example.keyAchievements.map((achievement, index) => (
                      <div key={index} className="flex items-start gap-2.5 text-sm">
                        <span className="text-[#3ea884] mt-1">•</span>
                        <p className="text-stone-600 leading-relaxed">{achievement}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Quick builder CTA */}
            <div className="bg-[#edf8fc] border border-[#d1effa] rounded-2xl p-6 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div>
                <h4 className="font-serif text-lg text-stone-900">Apply this resume style today</h4>
                <p className="text-stone-500 text-xs mt-1">
                  Instantly import structural standards into our browser-secured active sandbox.
                </p>
              </div>
              <button
                onClick={() => {
                  navigate('/resume-builder');
                  window.scrollTo({ top: 0, behavior: 'instant' });
                }}
                className="bg-[#2a8767] hover:bg-[#1d6148] text-white font-mono text-xs font-bold px-4 py-2.5 rounded-xl transition-all cursor-pointer whitespace-nowrap"
              >
                Go to Resume Builder
              </button>
            </div>
          </div>

          {/* Right Sidebar: Related Resume Examples (Requirement 8) */}
          <div className="space-y-6 text-left">
            <div className="bg-stone-50 border border-stone-200/80 rounded-2xl p-6">
              <h3 className="font-serif text-md font-bold text-stone-900 mb-4 pb-2 border-b border-stone-200">
                Related Resume Examples
              </h3>
              <div className="space-y-4">
                {relatedExamples.map((ex) => (
                  <div 
                    key={ex.slug}
                    onClick={() => {
                      navigate(`/resume-examples/${ex.slug}`);
                      window.scrollTo({ top: 0, behavior: 'instant' });
                    }}
                    className="group cursor-pointer block p-3 bg-white border border-stone-200 hover:border-[#3ea884] rounded-xl transition-all"
                  >
                    <div className="text-[9px] font-mono font-bold text-stone-400 group-hover:text-[#3ea884] uppercase mb-1">
                      {ex.industry}
                    </div>
                    <h4 className="text-sm font-semibold text-stone-800 group-hover:text-stone-950 flex items-center justify-between">
                      <span className="flex items-center gap-1.5">
                        <FileText size={13} className="text-stone-400 group-hover:text-[#3ea884]" />
                        {ex.jobTitle}
                      </span>
                      <ChevronRight size={13} className="text-stone-300 group-hover:text-stone-500" />
                    </h4>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white border border-stone-200 rounded-2xl p-6 text-xs text-stone-500 space-y-3">
              <h4 className="font-mono font-bold text-stone-800 uppercase tracking-wider">SEO Architecture</h4>
              <p>
                Each template outline is mapped to standardized schema structures, custom crawl paths, and dynamic titles verifying full page index eligibility.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
