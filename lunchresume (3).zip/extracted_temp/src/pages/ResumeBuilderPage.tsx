/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useLocation } from 'react-router-dom';
import { ResumeBuilderSandbox } from '../components/Diagrams';
import { SEO } from '../components/SEO';
import seoJson from '../../content/seo.json';

export const ResumeBuilderPage: React.FC = () => {
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const format = (searchParams.get('format') as '1-page' | '2-page') || location.state?.format || '1-page';
  const template = (searchParams.get('template') as 'classic' | 'modern' | 'minimalist' | 'creative') || undefined;

  return (
    <div className="pt-28 pb-20 max-w-7xl mx-auto px-4 sm:px-6">
      <SEO 
        title={seoJson.resumeBuilder.title} 
        description={seoJson.resumeBuilder.description} 
        canonical={seoJson.resumeBuilder.canonical} 
      />
      <div className="max-w-3xl mx-auto text-center mb-10">
        <div className="inline-flex items-center gap-1.5 mb-3 px-3 py-1 bg-[#8cfbd4]/10 text-stone-800 text-[10px] tracking-widest uppercase font-extrabold rounded-full border border-[#8cfbd4]/20">
          🛠️ RESUME WORKSPACE
        </div>
        <h1 className="font-serif text-3xl md:text-5xl text-stone-900 mb-4 font-normal">Playground Editor Sandbox</h1>
        <p className="text-stone-600 text-sm md:text-base leading-relaxed">
          Click on the preset industry profiles to instant-fill the form, then customize colors, spacing, and content. Click <strong>PDF Print</strong> to calibrate your printable profile file.
        </p>
      </div>
      
      {/* Main workspace */}
      <ResumeBuilderSandbox initialFormat={format} initialTemplate={template} />
    </div>
  );
};
