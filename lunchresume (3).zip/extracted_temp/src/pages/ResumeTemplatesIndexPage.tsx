/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronRight, FileText, Layout, Layers, Lightbulb, Grid } from 'lucide-react';
import TEMPLATE_PAGES from '../../content/templatePages.json';
import { ResumeTemplatePage } from '../../types/content';
import { SEO } from '../components/SEO';
import { BreadcrumbSchema } from '../components/Schema';

const typedTemplates = TEMPLATE_PAGES as ResumeTemplatePage[];

export const ResumeTemplatesIndexPage: React.FC = () => {
  const navigate = useNavigate();

  // Helper icons based on template slug
  const getIcon = (slug: string) => {
    switch (slug) {
      case 'classic': return <FileText className="text-amber-600" size={20} />;
      case 'modern': return <Layout className="text-[#3ea884]" size={20} />;
      case 'minimalist': return <Layers className="text-blue-500" size={20} />;
      case 'creative': return <Lightbulb className="text-purple-500" size={20} />;
      default: return <Grid className="text-stone-400" size={20} />;
    }
  };

  return (
    <div className="pt-28 pb-24 max-w-7xl mx-auto px-6">
      <SEO 
        title="ATS-Calibrated Resume Templates Library | LunchResume" 
        description="Browse and choose from our premium, 100% free resume templates. Select among Classic, Modern, Minimalist, or Creative lay-outs optimized to pass recruiter screens." 
        canonical="https://lunchresume.com/resume-templates" 
      />
      <BreadcrumbSchema 
        items={[
          { name: 'Home', item: 'https://lunchresume.com/' },
          { name: 'Resume Templates', item: 'https://lunchresume.com/resume-templates' }
        ]}
      />

      <div className="max-w-3xl mx-auto text-center mb-16">
        <div className="inline-flex items-center gap-1.5 mb-3 px-3 py-1 bg-[#8cfbd4]/10 text-stone-800 text-[10px] tracking-widest uppercase font-extrabold rounded-full border border-[#8cfbd4]/20">
          🎨 DESIGN DESIGNS
        </div>
        <h1 className="font-serif text-3xl md:text-5xl text-stone-900 mb-4 font-normal">Recruiter-Approved Resume Templates</h1>
        <p className="text-stone-600 text-sm md:text-base leading-relaxed">
          Accelerate your job search with layouts scientifically tested for optical readability and ATS parser compatibility. Click to view deep architectural analysis of each blueprint.
        </p>
      </div>

      {/* Grid listing */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
        {typedTemplates.map((template) => (
          <div 
            key={template.slug} 
            className="bg-white rounded-2xl border border-stone-200/80 p-8 shadow-xs flex flex-col justify-between hover:shadow-md hover:border-stone-300 transition-all text-left"
          >
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2.5">
                  <div className="p-2.5 bg-stone-50 rounded-xl border border-stone-150">
                    {getIcon(template.slug)}
                  </div>
                  <div>
                    <h3 className="font-serif text-xl font-bold text-stone-950">
                      {template.templateName}
                    </h3>
                    <span className="text-[10px] font-mono font-semibold tracking-wider text-stone-400 uppercase">
                      SLUG: {template.slug}
                    </span>
                  </div>
                </div>
                <span className="text-[10px] font-mono text-[#2a8767] bg-[#8cfbd4]/10 px-2.5 py-1 rounded-md font-bold uppercase">
                  100% Free
                </span>
              </div>

              <div className="mb-4">
                <strong className="text-xs font-mono font-bold text-stone-750 block mb-1">BEST FOR:</strong>
                <p className="text-stone-700 text-sm">{template.bestFor}</p>
              </div>

              <p className="text-stone-500 text-xs leading-relaxed mb-6">
                {template.description}
              </p>

              {/* Strengths Snippet */}
              <div className="border-t border-stone-100 pt-4 mb-6">
                <strong className="text-xs font-mono font-bold text-stone-750 block mb-2">CORE STRENGTH:</strong>
                <p className="text-stone-650 text-xs italic">
                  "{template.strengths[0]}"
                </p>
              </div>
            </div>

            <div className="flex items-center justify-between mt-4 pt-4 border-t border-stone-50">
              <button 
                onClick={() => {
                  navigate(`/resume-templates/${template.slug}`);
                  window.scrollTo({ top: 0, behavior: 'instant' });
                }}
                className="inline-flex items-center gap-1.5 text-xs font-bold text-[#2a8767] hover:text-[#1d6148] transition-colors font-mono uppercase tracking-wider cursor-pointer"
              >
                Analyze structural blueprint <ChevronRight size={14} />
              </button>

              <button
                onClick={() => {
                  navigate(`/resume-builder?template=${template.slug}`);
                  window.scrollTo({ top: 0, behavior: 'instant' });
                }}
                className="bg-stone-900 hover:bg-stone-850 text-white font-mono text-[10px] font-bold px-3 py-1.5 rounded-lg transition-all cursor-pointer uppercase"
              >
                Use Layout
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
