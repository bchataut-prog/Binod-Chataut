/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronRight, FileText, ArrowRight } from 'lucide-react';
import RESUME_EXAMPLES from '../../content/resumeExamples.json';
import { ResumeExample } from '../../types/content';
import { SEO } from '../components/SEO';
import { BreadcrumbSchema } from '../components/Schema';

const typedResumeExamples = RESUME_EXAMPLES as ResumeExample[];

export const ResumeExamplesIndexPage: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="pt-28 pb-24 max-w-7xl mx-auto px-6">
      <SEO 
        title="ATS-Calibrated Resume Examples Library | LunchResume" 
        description="Explore our archive of professionally written resume examples tailored for competitive industries like tech, healthcare, and finance. Completely free of paywalls." 
        canonical="https://lunchresume.com/resume-examples" 
      />
      <BreadcrumbSchema 
        items={[
          { name: 'Home', item: 'https://lunchresume.com/' },
          { name: 'Resume Examples', item: 'https://lunchresume.com/resume-examples' }
        ]}
      />

      <div className="max-w-3xl mx-auto text-center mb-16">
        <div className="inline-flex items-center gap-1.5 mb-3 px-3 py-1 bg-[#8cfbd4]/10 text-stone-800 text-[10px] tracking-widest uppercase font-extrabold rounded-full border border-[#8cfbd4]/20">
          💼 RESUME ARCHIVE
        </div>
        <h1 className="font-serif text-3xl md:text-5xl text-stone-900 mb-4 font-normal">Recruiter-Calibrated Resume Examples</h1>
        <p className="text-stone-600 text-sm md:text-base leading-relaxed">
          Unlock high-converting, ATS-parseable resumes. Analyze structure, spacing priorities, and numbers-driven statements crafted specifically for your target industry.
        </p>
      </div>

      {/* Grid listing */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
        {typedResumeExamples.map((example) => (
          <div 
            key={example.slug} 
            className="bg-white rounded-2xl border border-stone-200/80 p-6 shadow-xs flex flex-col justify-between hover:shadow-md hover:border-stone-300 transition-all text-left"
          >
            <div>
              <div className="flex items-center gap-2 text-[10px] font-mono font-bold text-[#3ea884] uppercase mb-3.5">
                <span>{example.industry}</span>
                <span>•</span>
                <span>Fully Calibrated</span>
              </div>
              <h3 
                className="font-serif text-xl font-bold text-stone-900 mb-3 hover:text-stone-750 cursor-pointer flex items-center gap-2" 
                onClick={() => {
                  navigate(`/resume-examples/${example.slug}`);
                  window.scrollTo({ top: 0, behavior: 'instant' });
                }}
              >
                <FileText size={18} className="text-stone-400" />
                {example.jobTitle}
              </h3>
              <p className="text-stone-500 text-xs leading-relaxed mb-6 line-clamp-3">
                {example.summary}
              </p>
            </div>
            <button 
              onClick={() => {
                navigate(`/resume-examples/${example.slug}`);
                window.scrollTo({ top: 0, behavior: 'instant' });
              }}
              className="inline-flex items-center gap-1.5 text-xs font-bold text-[#2a8767] hover:text-[#1d6148] transition-colors mt-auto font-mono uppercase tracking-wider text-left cursor-pointer"
            >
              Analyze template <ChevronRight size={14} />
            </button>
          </div>
        ))}
      </div>

      {/* Call to action section to flow back into system */}
      <div className="bg-[#edf8fc] border border-[#d1effa] rounded-2xl p-8 text-center max-w-4xl mx-auto">
        <h3 className="font-serif text-2xl text-stone-900 mb-2 font-normal">Need to construct your own custom resume?</h3>
        <p className="text-stone-600 text-sm mb-6 max-w-xl mx-auto">
          Our browser-sandboxed interactive sandbox helps you construct fully ATS-parseable templates instantly. Zero signup or email required.
        </p>
        <button
          onClick={() => {
            navigate('/resume-builder');
            window.scrollTo({ top: 0, behavior: 'instant' });
          }}
          className="inline-flex items-center gap-2 bg-[#2a8767] hover:bg-[#1d6148] text-white font-mono text-xs font-bold px-5 py-3 rounded-xl transition-all shadow-md active:scale-95 cursor-pointer"
        >
          Open Resume Builder <ArrowRight size={14} />
        </button>
      </div>
    </div>
  );
};
