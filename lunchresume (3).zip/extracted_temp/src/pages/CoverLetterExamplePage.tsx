/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, ChevronRight, Mail, Sparkles, Building, ListTodo, FileText } from 'lucide-react';
import COVER_LETTER_EXAMPLES from '../../content/coverLetterExamples.json';
import { CoverLetterExample } from '../../types/content';
import { SEO } from '../components/SEO';
import { ArticleSchema, BreadcrumbSchema } from '../components/Schema';

const typedLetterExamples = COVER_LETTER_EXAMPLES as CoverLetterExample[];

export const CoverLetterExamplePage: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();

  const example = typedLetterExamples.find(ex => ex.slug === slug);

  const handleBackToArchive = () => {
    navigate('/cover-letter-examples');
    window.scrollTo({ top: 0, behavior: 'instant' });
  };

  const currentSlug = slug || '';

  // Requirement 8: Related Cover Letter Examples
  const relatedExamples = typedLetterExamples.filter(ex => ex.slug !== currentSlug);

  if (!example) {
    return (
      <div className="pt-28 pb-24 max-w-7xl mx-auto px-6 text-center">
        <SEO 
          title="Cover Letter Example Not Found | LunchResume" 
          description="The requested cover letter example could not be found." 
          canonical="https://lunchresume.com/cover-letter-examples" 
        />
        <BreadcrumbSchema 
          items={[
            { name: 'Home', item: 'https://lunchresume.com/' },
            { name: 'Cover Letter Examples', item: 'https://lunchresume.com/cover-letter-examples' },
            { name: 'Not Found', item: 'https://lunchresume.com/cover-letter-examples' }
          ]}
        />
        <h2 className="font-serif text-2xl text-stone-900 mb-4 font-normal">Cover Letter not found</h2>
        <p className="text-stone-600 mb-6 max-w-md mx-auto text-sm">
          We could not locate the requested industry profile cover letter. Browse our archive to see all templates.
        </p>
        <button 
          onClick={handleBackToArchive}
          className="inline-flex items-center gap-2 text-xs font-mono font-bold text-[#2a8767] hover:text-[#1d6148] transition-colors"
        >
          <ArrowLeft size={14} /> Back to Cover Letter Archive
        </button>
      </div>
    );
  }

  const canonicalUrl = `https://lunchresume.com/cover-letter-examples/${example.slug}`;

  return (
    <div className="pt-28 pb-24 max-w-7xl mx-auto px-6">
      <SEO 
        title={example.seoTitle} 
        description={example.seoDescription} 
        canonical={canonicalUrl} 
      />
      <ArticleSchema 
        title={example.seoTitle}
        excerpt={example.seoDescription}
        datePublished="2026-06-21"
        canonicalUrl={canonicalUrl}
      />
      <BreadcrumbSchema 
        items={[
          { name: 'Home', item: 'https://lunchresume.com/' },
          { name: 'Cover Letter Examples', item: 'https://lunchresume.com/cover-letter-examples' },
          { name: example.jobTitle, item: canonicalUrl }
        ]}
      />

      <div className="max-w-4xl mx-auto">
        {/* Back Link */}
        <button 
          onClick={handleBackToArchive}
          className="inline-flex items-center gap-2 text-xs font-mono font-bold text-[#2a8767] hover:text-[#1d6148] transition-colors mb-6 cursor-pointer"
        >
          <ArrowLeft size={14} /> Back to Archive
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Draft Outline */}
          <div className="lg:col-span-2 space-y-8 text-left">
            <div className="bg-white border border-stone-200 rounded-2xl p-6 sm:p-10 shadow-xs">
              {/* Profile Header */}
              <div className="border-b border-stone-100 pb-6 mb-6">
                <div className="inline-flex items-center gap-1.5 mb-2 px-2.5 py-0.5 bg-[#8cfbd4]/15 text-stone-800 text-[9px] tracking-widest uppercase font-extrabold rounded-full border border-[#8cfbd4]/30">
                  {example.industry}
                </div>
                <h1 className="font-serif text-3xl sm:text-4xl text-stone-900 font-normal">
                  {example.jobTitle} Cover Letter
                </h1>
                <p className="text-stone-500 text-xs font-mono mt-1">
                  CALIBRATED ATS PHRASINGS & OUTLINES
                </p>
              </div>

              {/* Dynamic Letter Sections */}
              <div className="space-y-6">
                {/* Introduction Paragraph */}
                <div>
                  <h3 className="font-serif text-md font-bold text-stone-900 mb-2 flex items-center gap-2">
                    <Sparkles size={14} className="text-[#3ea884]" />
                    The Hook (Introductory Paragraph)
                  </h3>
                  <p className="text-stone-650 text-sm leading-relaxed bg-stone-50 p-4 rounded-xl border border-stone-200/50">
                    {example.introduction}
                  </p>
                </div>

                {/* Body Paragraphs */}
                <div>
                  <h3 className="font-serif text-md font-bold text-stone-900 mb-2 flex items-center gap-2">
                    <Building size={14} className="text-stone-500" />
                    Value Propositions (Body Paragraphs)
                  </h3>
                  <div className="space-y-4">
                    {example.bodyParagraphs.map((para, index) => (
                      <div key={index} className="flex gap-3 text-sm">
                        <span className="text-[#3ea884] font-bold font-mono">0{index + 1}.</span>
                        <p className="text-stone-650 leading-relaxed">{para}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Key Strengths Matrix */}
                <div>
                  <h3 className="font-serif text-md font-bold text-stone-900 mb-2 flex items-center gap-2">
                    <ListTodo size={14} className="text-stone-500" />
                    Target Accomplishments list
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {example.keyStrengths.map((strength, index) => (
                      <span 
                        key={index}
                        className="text-stone-750 bg-stone-100 border border-stone-200 px-3 py-1 rounded-lg text-xs font-mono"
                      >
                        {strength}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Closing Paragraph */}
                <div>
                  <h3 className="font-serif text-md font-bold text-stone-900 mb-2">
                    The Close (Call to Action)
                  </h3>
                  <p className="text-stone-650 text-sm leading-relaxed p-4 bg-[#edf8fc]/50 border border-[#d1effa]/30 rounded-xl">
                    {example.closingParagraph}
                  </p>
                </div>
              </div>
            </div>

            {/* CTA Option: REQUIREMENT 10 - Create Your Cover Letter opens the Cover Letter Builder */}
            <div className="bg-[#edf8fc] border border-[#d1effa] rounded-2xl p-6 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div>
                <h4 className="font-serif text-lg text-stone-900">Deploy this cover letter style today</h4>
                <p className="text-stone-500 text-xs mt-1">
                  Adjust, customize and exports this layout instantly inside our secured builder workspace.
                </p>
              </div>
              <button
                onClick={() => {
                  navigate('/cover-letter-builder');
                  window.scrollTo({ top: 0, behavior: 'instant' });
                }}
                className="bg-[#2a8767] hover:bg-[#1d6148] text-white font-mono text-xs font-bold px-4 py-2.5 rounded-xl transition-all cursor-pointer whitespace-nowrap"
              >
                Create Your Cover Letter
              </button>
            </div>
          </div>

          {/* Right Sidebar */}
          <div className="space-y-6 text-left">
            {/* Requirement 9: Cross-linking (Resume Example ↔ Cover Letter Example) */}
            <div className="bg-stone-50 border border-stone-200/80 rounded-2xl p-6">
              <h3 className="font-serif text-md font-bold text-stone-900 mb-3 pb-2 border-b border-stone-200">
                Matching Resume Layouts
              </h3>
              <p className="text-stone-500 text-xs mb-4">
                Verify absolute alignment by paring this letter draft with its custom chronological resume standard:
              </p>
              <div 
                onClick={() => {
                  navigate(`/resume-examples/${example.slug}`);
                  window.scrollTo({ top: 0, behavior: 'instant' });
                }}
                className="group cursor-pointer block p-3.5 bg-white border border-stone-200 hover:border-[#3ea884] rounded-xl transition-all"
              >
                <div className="text-[9px] font-mono font-bold text-[#3ea884] uppercase mb-1">
                  Active Pairing
                </div>
                <h4 className="text-sm font-semibold text-stone-800 group-hover:text-stone-950 flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <FileText size={13} className="text-[#3ea884]" />
                    {example.jobTitle} Resume
                  </span>
                  <ChevronRight size={13} className="text-stone-300 group-hover:text-stone-500" />
                </h4>
              </div>
            </div>

            {/* Requirement 8: Related Cover Letter Examples */}
            <div className="bg-stone-50 border border-stone-200/80 rounded-2xl p-6">
              <h3 className="font-serif text-md font-bold text-stone-900 mb-4 pb-2 border-b border-stone-200">
                Related Cover Letters
              </h3>
              <div className="space-y-4">
                {relatedExamples.map((ex) => (
                  <div 
                    key={ex.slug}
                    onClick={() => {
                      navigate(`/cover-letter-examples/${ex.slug}`);
                      window.scrollTo({ top: 0, behavior: 'instant' });
                    }}
                    className="group cursor-pointer block p-3.5 bg-white border border-stone-200 hover:border-[#3ea884] rounded-xl transition-all"
                  >
                    <div className="text-[9px] font-mono font-bold text-stone-400 group-hover:text-[#3ea884] uppercase mb-1">
                      {ex.industry}
                    </div>
                    <h4 className="text-sm font-semibold text-stone-800 group-hover:text-stone-950 flex items-center justify-between">
                      <span className="flex items-center gap-1.5">
                        <Mail size={13} className="text-stone-400 group-hover:text-[#3ea884]" />
                        {ex.jobTitle}
                      </span>
                      <ChevronRight size={13} className="text-stone-300 group-hover:text-stone-500" />
                    </h4>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
