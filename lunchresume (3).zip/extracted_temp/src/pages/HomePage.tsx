/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useNavigate } from 'react-router-dom';
import { HeroScene } from '../components/QuantumScene';
import { SEO } from '../components/SEO';
import { SoftwareApplicationSchema, FAQSchema } from '../components/Schema';
import seoJson from '../../content/seo.json';
import { 
  ArrowDown, ShieldCheck 
} from 'lucide-react';

import homepageContent from '../../content/homepage.json';
import { HomepageContent } from '../../types/content';

const typedHomepageContent = homepageContent as HomepageContent;

export const HomePage: React.FC = () => {
  const navigate = useNavigate();

  const handleNavigateToBuilder = (format: '1-page' | '2-page') => {
    navigate(`/resume-builder?format=${format}`, { state: { format } });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollToSection = (id: string) => (e: React.MouseEvent) => {
    e.preventDefault();
    const element = document.getElementById(id);
    if (element) {
      const headerOffset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  return (
    <>
      <SEO 
        title={seoJson.home.title} 
        description={seoJson.home.description} 
        canonical={seoJson.home.canonical} 
      />
      <SoftwareApplicationSchema 
        name="LunchResume"
        applicationCategory="BusinessApplication"
        operatingSystem="Web"
        price={0}
        priceCurrency="USD"
      />
      <FAQSchema items={typedHomepageContent.faqs.items} />
      
      {/* 1. Hero Header */}
      <header className="relative min-h-[90vh] flex items-center justify-center overflow-hidden pt-24 pb-14 md:py-24 bg-[#F7F9F8] border-b border-[#E2E8E6]">
        <HeroScene />
        
        {/* Soft Radial Ambient Layer to maintain contrast */}
        <div className="absolute inset-0 z-0 pointer-events-none bg-[radial-gradient(circle_at_center,rgba(247,249,248,0.45)_0%,rgba(247,249,248,0.85)_100%)]" />

        <div className="relative z-10 container mx-auto px-6 py-10 text-center max-w-4xl bg-white rounded-2xl border border-[#E2E8E6] shadow-md md:p-14 my-4">
          {/* Badge */}
          <div className="inline-flex items-center gap-1.5 mb-6 px-4 py-1.5 border border-[#E2E8E6] text-[#0F766E] text-[13px] uppercase tracking-wider font-bold rounded-full bg-[#0F766E]/5">
            {typedHomepageContent.hero.badge}
          </div>
          
          {/* Main heading */}
          <h1 className="font-serif text-4xl md:text-5xl lg:text-[64px] font-bold leading-tight mb-6 text-[#1A1F1E] tracking-tight">
            {typedHomepageContent.hero.title.split('\n')[0]} <br />
            <span className="italic font-normal text-[#46504D]">{typedHomepageContent.hero.title.split('\n')[1]}</span>
          </h1>
          
          {/* Subheading */}
          <p className="max-w-2xl mx-auto text-[16px] text-[#46504D] font-normal leading-relaxed mb-8">
            {typedHomepageContent.hero.subtitle}
          </p>
          
          {/* Primary actions */}
          <div className="flex flex-col sm:flex-row justify-center gap-4 mb-4">
            <button 
              onClick={() => handleNavigateToBuilder('1-page')}
              className="px-7 py-3.5 bg-[#0F766E] hover:bg-[#0F766E]/90 text-white border border-[#0F766E] rounded-xl font-bold uppercase tracking-wider text-[13.5px] hover:scale-[1.02] active:scale-95 transition-all shadow-md cursor-pointer"
            >
              {typedHomepageContent.hero.primaryActionLabel}
            </button>
            <a 
              href="#template-strip" 
              onClick={scrollToSection('template-strip')}
              className="px-7 py-3.5 bg-white text-[#0F766E] border border-[#E2E8E6] rounded-xl font-medium uppercase tracking-wider text-[13.5px] hover:bg-[#F7F9F8] hover:border-[#0F766E] hover:scale-[1.02] active:scale-95 transition-all shadow-sm cursor-pointer text-center"
            >
              {typedHomepageContent.hero.secondaryActionLabel}
            </a>
          </div>

          {/* Core Trust Message Right Under Buttons */}
          <p className="text-[13.5px] text-[#46504D] mb-10 flex items-center justify-center gap-1.5 font-normal">
            <ShieldCheck size={16} className="text-[#16A34A]" /> Your data stays in your browser. Nothing is uploaded.
          </p>
          
          {/* Small scroll vector indicator */}
          <div className="flex justify-center">
             <a href="#how-it-works" onClick={scrollToSection('how-it-works')} className="group flex flex-col items-center gap-2 text-[13px] font-sans font-bold tracking-wider text-[#0F766E] hover:text-[#0F766E]/95 transition-colors cursor-pointer">
                <span>{typedHomepageContent.hero.scrollIndicator}</span>
                <span className="p-2 border border-[#E2E8E6] rounded-full group-hover:border-[#0F766E] transition-colors bg-[#F7F9F8] shadow-sm">
                    <ArrowDown size={14} className="text-[#0F766E]" />
                </span>
             </a>
          </div>
        </div>
      </header>

      {/* 2. Trust Bar */}
      <section className="bg-white border-y border-[#E2E8E6] py-4">
        <div className="max-w-7xl mx-auto px-6 flex flex-wrap justify-center items-center gap-x-8 gap-y-2 text-[13px] font-medium text-[#46504D] text-center">
          <span className="flex items-center gap-1.5 uppercase tracking-wider text-[13px] font-bold text-[#0F766E] bg-[#0F766E]/5 px-2.5 py-0.5 rounded border border-[#E2E8E6]/60">Trust Policy</span>
          <span className="text-[#1A1F1E] font-medium">100% Free</span>
          <span className="text-[#E2E8E6] hidden sm:inline">•</span>
          <span className="text-[#1A1F1E] font-medium">No Sign-Up Required</span>
          <span className="text-[#E2E8E6] hidden sm:inline">•</span>
          <span className="text-[#1A1F1E] font-medium">Works in Browser</span>
          <span className="text-[#E2E8E6] hidden sm:inline">•</span>
          <span className="text-[#1A1F1E] font-medium">No Data Stored</span>
        </div>
      </section>

      <main>
        {/* 3. HOW IT WORKS SECTION */}
        <section id="how-it-works" className="py-14 md:py-24 bg-white relative border-b border-[#E2E8E6]">
          <div className="max-w-7xl mx-auto px-6">
            
            {/* Header */}
            <div className="text-center max-w-3xl mx-auto mb-14">
              <div className="inline-flex items-center gap-1.5 mb-3 px-4 py-1.5 border border-[#E2E8E6] text-[#0F766E] text-[13px] tracking-wider uppercase font-bold rounded-full bg-[#F7F9F8]">
                {typedHomepageContent.utility.badge}
              </div>
              <h2 className="font-serif text-[30px] font-bold text-[#1C2B33] tracking-tight leading-tight mb-3">
                {typedHomepageContent.utility.title}
              </h2>
              <p className="text-[#0F766E] font-sans text-[13px] uppercase tracking-wider font-bold">
                {typedHomepageContent.utility.subtitle}
              </p>
            </div>

            {/* 4 Pillars Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
              {typedHomepageContent.utility.pillars.map((pillar) => {
                const bgClass = "bg-[#F7F9F8] border-[#E2E8E6] hover:border-[#0F766E]";
                const isSerifDemo = pillar.typePreset === "EB Garamond" || pillar.typePreset === "Playfair Serif Preset";
                const titleFontClass = "font-sans text-[22px] font-bold text-[#1C2B33] mb-2";
                const presetLabel = isSerifDemo ? "Playfair Serif" : "Inter Sans";
                const presetValClass = "text-[#0F766E] font-sans font-bold";

                return (
                  <div key={pillar.id} className={`p-6 ${bgClass} rounded-2xl border shadow-sm hover:shadow-md transition-all duration-300 group text-left flex flex-col justify-between min-h-[225px]`}>
                    <div>
                      <div className="w-12 h-12 bg-[#1C2B33] text-[#8CFBD4] rounded-xl flex items-center justify-center mb-5 group-hover:scale-105 transition-transform duration-300 shadow-sm">
                        {/* Inline fallback SVG icons matching Lucide styling */}
                        {pillar.icon === 'Lock' && (
                          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                        )}
                        {pillar.icon === 'FileText' && (
                          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M10 9H8"/><path d="M16 13H8"/><path d="M16 17H8"/></svg>
                        )}
                        {pillar.icon === 'ShieldCheck' && (
                          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 13c0 5-3.5 7.5-7.66 9.7a1 1 0 0 1-.68 0C7.5 20.5 4 18 4 13V6a1 1 0 0 1 .76-.97l8.24-2a1 1 0 0 1 .5 0l8.24 2A1 1 0 0 1 20 6Z"/><path d="m9 12 2 2 4-4"/></svg>
                        )}
                        {pillar.icon === 'Sparkles' && (
                          <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275Z"/><path d="m5 3 1 2.5L8.5 6 6 7 5 9.5 4 7 1.5 6 4 5.5Z"/><path d="M19 17l1 2.5 2.5.5-2.5 1-1 2.5-1-2.5-2.5-1 2.5-1Z"/></svg>
                        )}
                      </div>
                      <h3 className={titleFontClass}>
                        {pillar.title}
                      </h3>
                      <p className="text-[14px] leading-relaxed font-normal text-[#46504D]">
                        {pillar.description}
                      </p>
                    </div>
                    <div className="mt-4 pt-2 border-t border-[#E2E8E6] flex items-center justify-between text-[13px] font-sans text-[#46504D]">
                      <span className="font-medium">{pillar.badge}</span>
                      <span className={presetValClass}>{presetLabel}</span>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* 1-pager & 2-pager Dedicated Interactive Selector split */}
            <div className="mb-16">
              <div className="text-center max-w-2xl mx-auto mb-10">
                <span className="inline-block px-3 py-1 bg-[#0F766E]/10 border border-[#0F766E]/20 text-[#0F766E] text-[13px] font-bold uppercase rounded-full mb-2">
                  {typedHomepageContent.targetFormats.badge}
                </span>
                <h2 className="font-serif text-[30px] font-bold text-[#1C2B33] mb-3">
                  {typedHomepageContent.targetFormats.title}
                </h2>
                <p className="text-[#46504D] text-[14px] font-normal leading-relaxed">
                  {typedHomepageContent.targetFormats.subtitle}
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {/* Card 1: 1-pager */}
                <div className="bg-[#F7F9F8] p-6 rounded-2xl border border-[#E2E8E6] hover:border-[#0F766E] hover:shadow-md transition-all duration-300 text-left flex flex-col justify-between relative group">
                  <div className="absolute top-4 right-6 text-5xl font-sans font-bold text-[#1C2B33]/5 group-hover:text-[#0F766E]/10 transition-colors pointer-events-none select-none">
                    1P
                  </div>
                  <div>
                    <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-white text-[#0F766E] text-[13px] font-bold uppercase rounded mb-3 border border-[#E2E8E6]">
                      {typedHomepageContent.targetFormats.layouts[0].tier}
                    </div>
                    <h3 className="font-sans text-[22px] font-bold text-[#1C2B33] mb-2">
                      {typedHomepageContent.targetFormats.layouts[0].title}
                    </h3>
                    <p className="text-[#46504D] text-[14px] leading-relaxed font-normal mb-6">
                      {typedHomepageContent.targetFormats.layouts[0].description}
                    </p>
                  </div>
                  <button
                    onClick={() => handleNavigateToBuilder('1-page')}
                    className="w-full py-3 bg-[#0F766E] hover:bg-[#0F766E]/90 text-white font-bold text-[13.5px] uppercase tracking-wider rounded-xl transition-all border border-[#0F766E] cursor-pointer shadow-sm animate-none"
                  >
                    {typedHomepageContent.targetFormats.layouts[0].buttonText}
                  </button>
                </div>

                {/* Card 2: 2-pager (using secondary outline style) */}
                <div className="bg-white p-6 rounded-2xl border border-[#E2E8E6] hover:border-[#0F766E] hover:shadow-md transition-all duration-300 text-left flex flex-col justify-between relative group">
                  <div className="absolute top-4 right-6 text-5xl font-sans font-bold text-[#1C2B33]/5 group-hover:text-[#0F766E]/10 transition-colors pointer-events-none select-none">
                    2P
                  </div>
                  <div>
                    <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-[#F7F9F8] text-[#1C2B33] text-[13px] font-bold uppercase rounded mb-3 border border-[#E2E8E6]">
                      {typedHomepageContent.targetFormats.layouts[1].tier}
                    </div>
                    <h3 className="font-sans text-[22px] font-bold text-[#1C2B33] mb-2">
                      {typedHomepageContent.targetFormats.layouts[1].title}
                    </h3>
                    <p className="text-[#46504D] text-[14px] leading-relaxed font-normal mb-6">
                      {typedHomepageContent.targetFormats.layouts[1].description}
                    </p>
                  </div>
                  <button
                    onClick={() => handleNavigateToBuilder('2-page')}
                    className="w-full py-3 bg-white hover:bg-[#F7F9F8] text-[#0F766E] font-medium text-[13.5px] uppercase tracking-wider rounded-xl transition-all border border-[#0F766E] cursor-pointer shadow-sm"
                  >
                    {typedHomepageContent.targetFormats.layouts[1].buttonText}
                  </button>
                </div>
              </div>
            </div>

            {/* 3 Steps Roadmap */}
            <div className="border-t border-[#E2E8E6] pt-14 md:pt-20">
              <div className="text-center max-w-3xl mx-auto mb-12">
                <span className="inline-block px-4 py-1.5 bg-[#F7F9F8] border border-[#E2E8E6] text-[#0F766E] text-[13px] uppercase tracking-wider font-bold rounded-full mb-3 shadow-sm">
                  {typedHomepageContent.roadmap.badge}
                </span>
                <h2 className="font-serif text-[30px] font-bold text-[#1C2B33] leading-tight mb-2">
                  {typedHomepageContent.roadmap.title}
                </h2>
                <p className="text-[#0F766E] font-sans text-[13px] uppercase tracking-wider font-bold">
                  {typedHomepageContent.roadmap.subtitle}
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {typedHomepageContent.roadmap.steps.map((step, idx) => (
                  <div key={idx} className="text-left relative p-6 bg-white rounded-2xl border border-[#E2E8E6] hover:border-[#0F766E] hover:shadow-md transition-all duration-300 group">
                    <div className="absolute top-4 right-6 text-4xl font-sans font-bold text-[#1C2B33]/5 group-hover:text-[#0F766E]/10 pointer-events-none transition-colors duration-300">
                      {step.stepNumber}
                    </div>
                    <div className="w-9 h-9 bg-[#1C2B33] text-[#8CFBD4] rounded-full flex items-center justify-center font-bold text-[14px] mb-6 shadow-sm">
                      {step.boldNumber}
                    </div>
                    <h3 className="font-sans text-[22px] font-bold text-[#1C2B33] mb-2.5">
                      {step.title}
                    </h3>
                    <p className="text-[#46504D] text-[14px] leading-relaxed font-normal">
                      {step.description}
                    </p>
                  </div>
                ))}
              </div>
            </div>

          </div>
        </section>

        {/* 4. BROWSE BY CATEGORY SECTION */}
        <section id="browse-categories" className="py-16 md:py-24 bg-[#F7F9F8] border-b border-[#E2E8E6]">
          <div className="max-w-7xl mx-auto px-6 text-center">
            
            <div className="max-w-3xl mx-auto mb-12">
              <span className="inline-block px-3 py-1 bg-[#0F766E]/10 border border-[#0F766E]/20 text-[#0F766E] text-[13px] tracking-wider font-bold uppercase rounded-full mb-3 font-sans">
                Find your starting point
              </span>
              <h2 className="font-serif text-[30px] font-bold text-[#1C2B33] tracking-tight mb-3">
                Browse templates and examples for your role
              </h2>
              <p className="text-[#46504D] text-[16px] font-normal max-w-xl mx-auto">
                Explore custom-built formats and templates designed specifically to bypass ATS constraints and optimize structure.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {/* Card 1: Resume Templates */}
              <div 
                onClick={() => { navigate('/resume-templates'); window.scrollTo({ top: 0, behavior: 'instant'}); }}
                className="bg-white p-8 rounded-2xl border border-[#E2E8E6] hover:border-[#0F766E] hover:shadow-lg transition-all duration-300 text-left cursor-pointer flex flex-col justify-between hover:-translate-y-1"
              >
                <div>
                  <div className="w-10 h-10 bg-[#0F766E]/10 text-[#0F766E] rounded-xl flex items-center justify-center mb-6 font-bold text-[15px]">
                    01
                  </div>
                  <h3 className="font-sans text-[22px] font-bold text-[#1C2B33] mb-2.5">
                    Resume Templates
                  </h3>
                  <p className="text-[#46504D] text-[14px] leading-relaxed font-normal">
                    Explore ATS-calibrated professional structures designed to win more interview callbacks.
                  </p>
                </div>
                <div className="mt-8 text-[13.5px] font-sans font-bold text-[#0F766E] flex items-center gap-1.5 hover:translate-x-1 transition-all">
                  Browse Templates <span>&rarr;</span>
                </div>
              </div>

              {/* Card 2: Resume Examples */}
              <div 
                onClick={() => { navigate('/resume-examples'); window.scrollTo({ top: 0, behavior: 'instant'}); }}
                className="bg-white p-8 rounded-2xl border border-[#E2E8E6] hover:border-[#0F766E] hover:shadow-lg transition-all duration-300 text-left cursor-pointer flex flex-col justify-between hover:-translate-y-1"
              >
                <div>
                  <div className="w-10 h-10 bg-[#0F766E]/10 text-[#0F766E] rounded-xl flex items-center justify-center mb-6 font-bold text-[15px]">
                    02
                  </div>
                  <h3 className="font-sans text-[22px] font-bold text-[#1C2B33] mb-2.5">
                    Resume Examples
                  </h3>
                  <p className="text-[#46504D] text-[14px] leading-relaxed font-normal">
                    See role-specific content parameters and resume metric outlines curated for industry excellence.
                  </p>
                </div>
                <div className="mt-8 text-[13.5px] font-sans font-bold text-[#0F766E] flex items-center gap-1.5 hover:translate-x-1 transition-all">
                  Browse Examples <span>&rarr;</span>
                </div>
              </div>

              {/* Card 3: Cover Letter Examples */}
              <div 
                onClick={() => { navigate('/cover-letter-examples'); window.scrollTo({ top: 0, behavior: 'instant'}); }}
                className="bg-white p-8 rounded-2xl border border-[#E2E8E6] hover:border-[#0F766E] hover:shadow-lg transition-all duration-300 text-left cursor-pointer flex flex-col justify-between hover:-translate-y-1"
              >
                <div>
                  <div className="w-10 h-10 bg-[#0F766E]/10 text-[#0F766E] rounded-xl flex items-center justify-center mb-6 font-bold text-[15px]">
                    03
                  </div>
                  <h3 className="font-sans text-[22px] font-bold text-[#1C2B33] mb-2.5">
                    Cover Letter Examples
                  </h3>
                  <p className="text-[#46504D] text-[14px] leading-relaxed font-normal">
                    Find paired narrative examples designed to expand elegantly on high-impact tenure achievements.
                  </p>
                </div>
                <div className="mt-8 text-[13.5px] font-sans font-bold text-[#0F766E] flex items-center gap-1.5 hover:translate-x-1 transition-all">
                  Browse Cover Letters <span>&rarr;</span>
                </div>
              </div>
            </div>

          </div>
        </section>

        {/* 5. WHY CHOOSE US (THE NOISE BARRIER) */}
        <section id="about" className="py-16 md:py-24 bg-[#F7F9F8] border-b border-[#E2E8E6]">
          <div className="container mx-auto px-6 max-w-7xl grid grid-cols-1 md:grid-cols-12 gap-12 items-center">
            
            <div className="md:col-span-12 lg:col-span-5 text-left">
              <div className="inline-block mb-3 text-[13px] font-bold tracking-wider text-[#0F766E] uppercase">{typedHomepageContent.noiseBarrier.badge}</div>
              <h2 className="font-serif text-[30px] font-bold mb-6 leading-tight text-[#1C2B33]">{typedHomepageContent.noiseBarrier.title}</h2>
              <div className="w-16 h-1 bg-[#0F766E] mb-6"></div>
              
              <div className="p-6 bg-white rounded-xl border border-[#E2E8E6] text-[13px] text-[#46504D] space-y-2 shadow-sm">
                <div className="text-[13px] font-bold text-[#0F766E] uppercase tracking-wider">{typedHomepageContent.noiseBarrier.studyIndexLabel}</div>
                <div className="text-[#1C2B33] font-bold text-[18px]">{typedHomepageContent.noiseBarrier.studyIndexTitle}</div>
                <p className="leading-relaxed font-normal">{typedHomepageContent.noiseBarrier.studyIndexDescription}</p>
              </div>
            </div>

            <div className="md:col-span-12 lg:col-span-7 text-[16px] text-[#46504D] leading-relaxed space-y-6 text-left">
              <p className="text-[18px] text-[#1A1F1E] font-normal">
                <span className="text-5xl float-left mr-3 mt-[-8px] font-sans text-[#0F766E] font-bold">
                  {typedHomepageContent.noiseBarrier.descriptionParagraphs[0].charAt(0)}
                </span>
                <span dangerouslySetInnerHTML={{ __html: typedHomepageContent.noiseBarrier.descriptionParagraphs[0].substring(1).replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>') }} />
              </p>
              <p className="font-normal" dangerouslySetInnerHTML={{ __html: typedHomepageContent.noiseBarrier.descriptionParagraphs[1].replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>') }} />
              <p className="font-normal" dangerouslySetInnerHTML={{ __html: typedHomepageContent.noiseBarrier.descriptionParagraphs[2].replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>') }} />
            </div>

          </div>
        </section>

        {/* 6. TEMPLATE PREVIEW STRIP */}
        <section id="template-strip" className="py-16 md:py-24 bg-white border-b border-[#E2E8E6]">
          <div className="max-w-7xl mx-auto px-6">
            
            <div className="text-center max-w-3xl mx-auto mb-12">
              <span className="inline-block px-3 py-1 bg-[#0F766E]/10 border border-[#0F766E]/20 text-[#0F766E] text-[13px] tracking-wider font-bold uppercase rounded-full mb-3">
                High-Fidelity Layouts
              </span>
              <h2 className="font-serif text-[30px] font-bold text-[#1C2B33] tracking-tight mb-3">
                Pick a look that fits you
              </h2>
              <p className="text-[#46504D] text-[16px] max-w-xl mx-auto leading-relaxed">
                Click any layout to select it or browse our dedicated catalog
              </p>
            </div>

            {/* Grid on desktop, horizontal scroll on mobile */}
            <div className="flex md:grid md:grid-cols-4 gap-6 overflow-x-auto md:overflow-x-visible pb-6 md:pb-0 scrollbar-none snap-x snap-mandatory">
              {[
                {
                  id: "modern",
                  name: "Modern Professional",
                  tag: "Popular",
                  preview: (
                    <div className="p-3 bg-white border border-stone-200 h-full flex flex-col justify-between text-[4px] tracking-tight leading-normal shadow-xs font-sans">
                      <div>
                        {/* Header */}
                        <div className="border-b border-[#0F766E] pb-1 mb-1 text-left">
                          <div className="text-[7.5px] font-bold text-[#1C2B33] font-sans">Sophia Sterling</div>
                          <div className="text-[#0F766E] text-[4.8px] font-bold uppercase tracking-wider mt-0.5 font-sans">Senior Product Director</div>
                          <div className="text-[3.6px] text-stone-400 mt-0.5">San Francisco, CA • s.sterling@email.com • (555) 019-2831</div>
                        </div>

                        {/* Summary */}
                        <div className="text-left mb-1">
                          <p className="text-[3.8px] leading-relaxed text-stone-600 font-sans">
                            Innovative product leader with 8+ years experience guiding cross-functional engineering and design groups to build high-scale SaaS products. Focus on $12M+ ARR growth.
                          </p>
                        </div>

                        {/* Experience */}
                        <div className="text-left space-y-1">
                          <div className="font-bold text-stone-850 text-[4px] uppercase tracking-wider border-b border-stone-100 pb-0.2">Professional Experience</div>

                          <div>
                            <div className="flex justify-between font-bold text-stone-900 text-[3.8px] font-sans">
                              <span>Lead Product Manager | Google</span>
                              <span className="text-stone-400">2022 – Pres</span>
                            </div>
                            <p className="text-[3.2px] text-stone-500 leading-tight">
                              • Led the core cloud API scale expansion, trimming latency by 45%.<br />
                              • Managed a 12-developer sprint group delivering key features.
                            </p>
                          </div>

                          <div>
                            <div className="flex justify-between font-bold text-stone-900 text-[3.8px] font-sans">
                              <span>Senior PM | Stripe</span>
                              <span className="text-stone-400">2019 – 2022</span>
                            </div>
                            <p className="text-[3.2px] text-stone-500 leading-tight">
                              • Spearheaded international checkout path, raising completion by 22%.
                            </p>
                          </div>
                        </div>

                        {/* Skills */}
                        <div className="text-left mt-1">
                          <div className="font-bold text-stone-850 text-[4px] uppercase tracking-wider mb-0.5">Skills</div>
                          <div className="flex flex-wrap gap-0.5">
                            <span className="bg-[#0F766E]/5 text-[#0F766E] px-0.8 py-0.2 rounded-full text-[3.2px] font-bold border border-[#0F766E]/10 font-sans">Product Strategy</span>
                            <span className="bg-[#0F766E]/5 text-[#0F766E] px-0.8 py-0.2 rounded-full text-[3.2px] font-bold border border-[#0F766E]/10 font-sans">Agile</span>
                            <span className="bg-[#0F766E]/5 text-[#0F766E] px-0.8 py-0.2 rounded-full text-[3.2px] font-bold border border-[#0F766E]/10 font-sans">SQL</span>
                          </div>
                        </div>
                      </div>

                      {/* Footer */}
                      <div className="flex justify-between items-center text-[4px] border-t border-stone-100 pt-1 mt-1 font-sans">
                        <span className="text-stone-400">Inter Sans</span>
                        <span className="text-[#0F766E] font-bold uppercase text-[3.5px]">Selected</span>
                      </div>
                    </div>
                  )
                },
                {
                  id: "minimal",
                  name: "Minimal ATS",
                  tag: "Recommended",
                  preview: (
                    <div className="p-3 bg-white border border-stone-200 h-full flex flex-col justify-between text-[4px] tracking-tight leading-normal shadow-xs font-sans">
                      <div>
                        {/* Header */}
                        <div className="text-center mb-1">
                          <div className="text-[7.5px] font-bold text-stone-900 font-sans">James Sterling</div>
                          <div className="text-stone-550 text-[4.8px] font-bold mt-0.5 font-sans">Software Engineering Architect</div>
                          <div className="text-[3.6px] text-stone-400 mt-0.5">Seattle, WA • james.s@email.com • github.com/jsterling</div>
                        </div>
                        <div className="h-[0.5px] bg-stone-200 w-full mb-1"></div>

                        {/* Summary */}
                        <div className="text-left mb-1">
                          <p className="text-[3.8px] leading-relaxed text-stone-600 font-sans">
                            Systems architect with 10+ years specializing in distributed, high-concurrency backend structures, cloud scaling, and database schema refinement.
                          </p>
                        </div>

                        {/* Experience */}
                        <div className="text-left space-y-1">
                          <div className="font-bold text-stone-850 text-[4px] border-b border-stone-200 pb-0.2">Professional Experience</div>

                          <div>
                            <div className="flex justify-between font-bold text-stone-900 text-[3.8px] font-sans">
                              <span>Principal Architect — Netflix</span>
                              <span className="text-stone-400">2021 – Pres</span>
                            </div>
                            <p className="text-[3.2px] text-stone-500 leading-tight">
                              • Re-designed container load systems to process 4M+ parallel streams.<br />
                              • Optimized queries, trim. database read intervals by 15ms.
                            </p>
                          </div>

                          <div>
                            <div className="flex justify-between font-bold text-stone-900 text-[3.8px] font-sans">
                              <span>Senior Backend Engineer — Amazon</span>
                              <span className="text-stone-400">2018 – 2021</span>
                            </div>
                            <p className="text-[3.2px] text-stone-500 leading-tight">
                              • Led migrations, saving $24k in monthly cloud storage fees.
                            </p>
                          </div>
                        </div>

                        {/* Skills */}
                        <div className="text-left mt-1">
                          <div className="font-bold text-stone-850 text-[4px] border-b border-stone-200 pb-0.2 mb-0.5">Technical Skills</div>
                          <div className="text-[3.4px] text-stone-600 font-sans font-medium">
                            <strong className="text-stone-800">Languages:</strong> Go, Rust, SQL • <strong className="text-stone-800">DevOps:</strong> Docker, AWS, K8s, Terraform
                          </div>
                        </div>
                      </div>

                      {/* Footer */}
                      <div className="flex justify-between items-center text-[4px] border-t border-stone-100 pt-1 mt-1 font-sans">
                        <span className="text-stone-400">System UI</span>
                        <span className="text-[#0F766E] font-medium uppercase text-[3.5px]">Pre-Tested</span>
                      </div>
                    </div>
                  )
                },
                {
                  id: "executive",
                  name: "Executive Sleek",
                  tag: "Elite",
                  preview: (
                    <div className="p-3 bg-white border border-stone-200 h-full flex flex-col justify-between text-[4px] tracking-tight leading-normal shadow-xs font-sans">
                      <div>
                        {/* Header */}
                        <div className="mb-1.5 text-left border-l-2 border-stone-800 pl-1.5">
                          <div className="font-serif font-bold text-[8px] text-[#1C2B33] tracking-tight">Victoria Thorne</div>
                          <div className="text-stone-400 text-[4.8px] font-sans font-bold tracking-wider uppercase mt-0.5">Chief Executive Officer</div>
                          <div className="text-[3.6px] text-stone-400 mt-0.5">v.thorne@aetherventures.co • NYC, NY</div>
                        </div>

                        {/* Summary */}
                        <div className="text-left mb-1">
                          <p className="text-[3.8px] leading-relaxed text-stone-600 font-sans">
                            Executive officer with 15+ years scaling operations. Guided capital rounds of $45M+ and raised total corporate yield metrics by 18%.
                          </p>
                        </div>

                        <div className="grid grid-cols-3 gap-1.5">
                          {/* Sidebar column */}
                          <div className="col-span-1 border-r border-stone-100 pr-0.5 text-left space-y-0.8">
                            <div className="font-bold text-stone-800 text-[3.8px] uppercase tracking-wider font-sans">Expertise</div>
                            <div className="text-[3px] text-stone-550 leading-tight space-y-0.2 font-sans font-medium">
                              <div>• M&A Strategy</div>
                              <div>• Board Scaling</div>
                              <div>• IPO Paths</div>
                            </div>
                          </div>

                          {/* Content column */}
                          <div className="col-span-2 space-y-0.8 text-left">
                            <div className="font-bold text-stone-800 text-[3.8px] uppercase tracking-wider font-sans">Highlights</div>

                            <div>
                              <div className="flex justify-between font-bold text-stone-900 text-[3.5px] font-sans">
                                <span>CEO | Ventures</span>
                                <span className="text-stone-400">2020 – Pres</span>
                              </div>
                              <p className="text-[3.2px] text-stone-500 leading-tight">
                                • Scaled net revenues to $34M ARR series scale basis.
                              </p>
                            </div>

                            <div>
                              <div className="flex justify-between font-bold text-stone-900 text-[3.5px] font-sans">
                                <span>COO | Cortex Tech</span>
                                <span className="text-stone-400">2015 – 2020</span>
                              </div>
                              <p className="text-[3.2px] text-stone-500 leading-tight">
                                • Raised corporate margin metrics by 18%.
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Footer */}
                      <div className="flex justify-between items-center text-[4px] border-t border-stone-100 pt-1 mt-1 font-sans">
                        <span className="text-stone-400">Playfair Display</span>
                        <span className="text-[#0F766E] font-bold uppercase text-[3.5px]">Executive</span>
                      </div>
                    </div>
                  )
                },
                {
                  id: "creative",
                  name: "Creative Impact",
                  tag: "Bold",
                  preview: (
                    <div className="p-0 bg-white border border-stone-200 h-full flex flex-col justify-between text-[4px] tracking-tight leading-normal shadow-xs font-sans overflow-hidden">
                      <div className="grid grid-cols-4 h-full flex-grow">
                        {/* Sidebar Column */}
                        <div className="col-span-1 bg-[#1C2B33] text-white p-1.5 text-left flex flex-col justify-between h-full min-h-[140px]">
                          <div>
                            <div className="text-[8.5px] font-black tracking-tighter text-[#8CFBD4] font-sans leading-none pb-1">MV</div>
                            <div className="h-[0.5px] bg-[#8CFBD4]/20 w-full my-1"></div>
                            <div className="space-y-1">
                              <div className="text-[3.6px] font-bold text-[#8CFBD4] uppercase tracking-wider">Skills</div>
                              <div className="text-[3px] text-slate-300 leading-tight space-y-0.2 font-sans font-medium">
                                <div>Figma</div>
                                <div>Motion UX</div>
                                <div>Branding</div>
                                <div>React</div>
                              </div>
                            </div>
                          </div>
                          <div className="text-[2.8px] text-[#8CFBD4] uppercase tracking-wide">Studio</div>
                        </div>

                        {/* Main Column */}
                        <div className="col-span-3 p-2.5 flex flex-col justify-between text-left">
                          <div>
                            <div className="border-b border-stone-100 pb-0.5 mb-1">
                              <div className="font-sans font-bold text-[7.5px] text-[#1C2B33]">Mason Vance</div>
                              <div className="text-[#0F766E] text-[4.8px] font-bold mt-0.5 font-sans">Creative Lead & Designer</div>
                            </div>

                            <p className="text-[3.8px] leading-relaxed text-stone-600 font-sans mb-1">
                              UI specialist defining interactive product styles. Raised client score by 40% through refined visual campaigns.
                            </p>

                            <div className="space-y-0.8">
                              <div className="font-bold text-[#1C2B33] text-[3.8px] uppercase tracking-wider font-sans">Experience</div>

                              <div>
                                <div className="flex justify-between font-bold text-stone-900 text-[3.5px] font-sans">
                                  <span>Creative Lead — Vixen</span>
                                  <span className="text-stone-400">2021 – Pres</span>
                                </div>
                                <p className="text-[3.2px] text-stone-500 leading-tight">
                                  • Direct branding updates for 15+ retail lines.<br />
                                  • Cut asset cycles by 25% via system designs.
                                </p>
                              </div>
                            </div>
                          </div>

                          {/* Preview Footer */}
                          <div className="flex justify-between items-center text-[4px] border-t border-stone-100 pt-1 mt-1 font-sans">
                            <span className="text-stone-400">Inter Sans</span>
                            <span className="text-[#8CFBD4] bg-[#1C2B33] px-1 py-0.2 rounded-xs font-bold uppercase scale-90 shrink-0 text-[3.5px]">Creative</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  )
                }
              ].map((tmpl) => (
                <div 
                  key={tmpl.id}
                  onClick={() => { navigate('/resume-templates'); window.scrollTo({ top: 0, behavior: 'instant'}); }}
                  className="snap-center shrink-0 w-[240px] md:w-full bg-[#F7F9F8] border border-[#E2E8E6] hover:border-[#0F766E] hover:shadow-lg transition-all duration-300 rounded-2xl p-4 flex flex-col gap-3 group cursor-pointer"
                >
                  <div className="aspect-[4/5] bg-stone-50 border border-stone-100 rounded-xl overflow-hidden p-2 group-hover:scale-[1.02] transition-all duration-300">
                    {tmpl.preview}
                  </div>
                  <div className="flex justify-between items-center mt-1 text-left">
                    <span className="font-sans font-bold text-[14px] text-[#1C2B33]">{tmpl.name}</span>
                    <span className="text-[13px] font-sans text-[#0F766E] bg-[#0F766E]/5 px-2 py-0.5 rounded-full font-bold">{tmpl.tag}</span>
                  </div>
                </div>
              ))}
            </div>

          </div>
        </section>

        {/* 7. FAQS SECTION */}
        <section id="faqs" className="py-16 md:py-20 bg-[#F7F9F8] border-b border-[#E2E8E6]">
          <div className="container mx-auto px-6 max-w-4xl">
            <h2 className="font-serif text-[30px] font-bold text-center mb-12 text-[#1C2B33]">{typedHomepageContent.faqs.title}</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-left">
              {typedHomepageContent.faqs.items.map((faq, idx) => (
                <div key={idx} className="align-baseline">
                  <h3 className="font-sans font-bold text-[#1C2B33] text-[16px] mb-2 flex items-start gap-2">
                    <HelpCircle size={15} className="text-[#0F766E] shrink-0 mt-1" /> {faq.question}
                  </h3>
                  <p className="text-[#46504D] text-[14px] leading-relaxed font-normal" dangerouslySetInnerHTML={{ __html: faq.answer.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>') }} />
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* 8. FINAL CTA SECTION (Conversion Closing Band - NEW) */}
        <section id="final-cta-band" className="py-20 md:py-28 bg-[#0F1B1E] text-white text-center relative overflow-hidden border-t border-[#E2E8E6]/20">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[350px] h-[350px] rounded-full bg-[#0F766E]/15 blur-[100px] pointer-events-none"></div>
          <div className="relative z-10 max-w-4xl mx-auto px-6">
            <h2 className="font-serif text-3xl md:text-[46px] font-bold leading-tight mb-4 tracking-tight text-[#F2F7F5]">
              Your resume is 15 minutes away.
            </h2>
            <p className="text-[#8CFBD4] font-sans text-base md:text-lg mb-8 font-bold">
              Free forever. No account needed.
            </p>
            <button 
              onClick={() => handleNavigateToBuilder('1-page')}
              className="px-8 py-4 bg-[#0F766E] hover:bg-[#0F766E]/90 text-white border border-[#0F766E] font-bold text-[14.5px] uppercase tracking-wider rounded-xl hover:scale-[1.04] active:scale-95 transition-all shadow-xl shadow-[#0F766E]/10 cursor-pointer text-center"
            >
              Create My Resume
            </button>
          </div>
        </section>
      </main>
    </>
  );
};

// HelpCircle inline fallback
const HelpCircle = ({ size, className }: { size?: number, className?: string }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    width={size || 24} 
    height={size || 24} 
    viewBox="0 0 24 24" 
    fill="none" 
    stroke="currentColor" 
    strokeWidth="2" 
    strokeLinecap="round" 
    strokeLinejoin="round" 
    className={className}
  >
    <circle cx="12" cy="12" r="10" />
    <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" />
    <line x1="12" y1="17" x2="12.01" y2="17" />
  </svg>
);
