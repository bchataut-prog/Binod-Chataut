/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { CoverLetterSandbox } from '../components/CoverLetterSandbox';
import { SEO } from '../components/SEO';
import seoJson from '../../content/seo.json';

export const CoverLetterPage: React.FC = () => {
  return (
    <div className="pt-28 pb-20 max-w-7xl mx-auto px-4 sm:px-6">
      <SEO 
        title={seoJson.coverLetterBuilder.title} 
        description={seoJson.coverLetterBuilder.description} 
        canonical={seoJson.coverLetterBuilder.canonical} 
      />
      <div className="max-w-3xl mx-auto text-center mb-10">
        <div className="inline-flex items-center gap-1.5 mb-3 px-3 py-1 bg-[#8cfbd4]/10 text-stone-800 text-[10px] tracking-widest uppercase font-extrabold rounded-full border border-[#8cfbd4]/20">
          ✉️ COVER LETTER GENERATOR
        </div>
        <h1 className="font-serif text-3xl md:text-5xl text-stone-900 mb-4 font-normal">Cover Letter Workspace</h1>
        <p className="text-stone-600 text-sm md:text-base leading-relaxed">
          Draft outcomes-focused cover letters aligned perfectly to your resume branding. Select an industry profile, write custom outcomes, and print your matching PDF file.
        </p>
      </div>
      
      {/* Cover letter builder */}
      <CoverLetterSandbox />
    </div>
  );
};
