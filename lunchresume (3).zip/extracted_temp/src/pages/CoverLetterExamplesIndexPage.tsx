/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronRight, Mail, ArrowRight } from 'lucide-react';
import COVER_LETTER_EXAMPLES from '../../content/coverLetterExamples.json';
import { CoverLetterExample } from '../../types/content';
import { SEO } from '../components/SEO';
import { BreadcrumbSchema } from '../components/Schema';

const typedExamples = COVER_LETTER_EXAMPLES as CoverLetterExample[];

export const CoverLetterExamplesIndexPage: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="pt-28 pb-24 max-w-7xl mx-auto px-6">
      <SEO 
        title="High-Converting Cover Letter Examples Library | LunchResume" 
        description="Explore our curated collection of free cover letter examples calibrated for competitive roles in tech, healthcare, and finance. Instant access with no registration required." 
        canonical="https://lunchresume.com/cover-letter-examples" 
      />
      <BreadcrumbSchema 
        items={[
          { name: 'Home', item: 'https://lunchresume.com/' },
          { name: 'Cover Letter Examples', item: 'https://lunchresume.com/cover-letter-examples' }
        ]}
      />

      <div className="max-w-3xl mx-auto text-center mb-16">
        <div className="inline-flex items-center gap-1.5 mb-3 px-3 py-1 bg-[#8cfbd4]/10 text-stone-800 text-[10px] tracking-widest uppercase font-extrabold rounded-full border border-[#8cfbd4]/20">
          📨 PERSUASIVE INTROS
        </div>
        <h1 className="font-serif text-3xl md:text-5xl text-stone-900 mb-4 font-normal">Recruiter-Calibrated Cover Letters</h1>
        <p className="text-stone-600 text-sm md:text-base leading-relaxed">
          Unlock high-impact, persuasive statements designed to capture immediate attention. Analyze structure, impact metrics, and hook-centric phrasing configured for your career path.
        </p>
      </div>

      {/* Grid listing */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
        {typedExamples.map((example) => (
          <div 
            key={example.slug} 
            className="bg-white rounded-2xl border border-stone-200/80 p-6 shadow-xs flex flex-col justify-between hover:shadow-md hover:border-stone-300 transition-all text-left"
          >
            <div>
              <div className="flex items-center gap-2 text-[10px] font-mono font-bold text-[#3ea884] uppercase mb-3.5">
                <span>{example.industry}</span>
                <span>•</span>
                <span>Fully Calibrated</span>
              </div>
              <h3 
                className="font-serif text-xl font-bold text-stone-900 mb-3 hover:text-stone-750 cursor-pointer flex items-center gap-2" 
                onClick={() => {
                  navigate(`/cover-letter-examples/${example.slug}`);
                  window.scrollTo({ top: 0, behavior: 'instant' });
                }}
              >
                <Mail size={18} className="text-stone-400" />
                {example.jobTitle}
              </h3>
              <p className="text-stone-500 text-xs leading-relaxed mb-6 line-clamp-3">
                {example.introduction}
              </p>
            </div>
            <button 
              onClick={() => {
                navigate(`/cover-letter-examples/${example.slug}`);
                window.scrollTo({ top: 0, behavior: 'instant' });
              }}
              className="inline-flex items-center gap-1.5 text-xs font-bold text-[#2a8767] hover:text-[#1d6148] transition-colors mt-auto font-mono uppercase tracking-wider text-left cursor-pointer"
            >
              Examine cover letter <ChevronRight size={14} />
            </button>
          </div>
        ))}
      </div>

      {/* Call to action section */}
      <div className="bg-[#edf8fc] border border-[#d1effa] rounded-2xl p-8 text-center max-w-4xl mx-auto">
        <h3 className="font-serif text-2xl text-stone-900 mb-2 font-normal">Need to construct your own Cover Letter?</h3>
        <p className="text-stone-600 text-sm mb-6 max-w-xl mx-auto">
          Our browser-sandboxed interactive workspace helps you assemble tailored letter drafts instantly. Completely free of paywalls.
        </p>
        <button
          onClick={() => {
            navigate('/cover-letter-builder');
            window.scrollTo({ top: 0, behavior: 'instant' });
          }}
          className="inline-flex items-center gap-2 bg-[#2a8767] hover:bg-[#1d6148] text-white font-mono text-xs font-bold px-5 py-3 rounded-xl transition-all shadow-md active:scale-95 cursor-pointer"
        >
          Open Cover Letter Builder <ArrowRight size={14} />
        </button>
      </div>
    </div>
  );
};
