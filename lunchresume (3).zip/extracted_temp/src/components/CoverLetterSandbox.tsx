import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, Trash2, Printer, RefreshCw, Send, CheckCircle, Sparkles, FileText, ChevronRight, Check } from 'lucide-react';
import coverLetterTemplates from '../../content/coverLetterTemplates.json';
import { CoverLetterTemplate } from '../../types/content';

const typedCoverLetterTemplates = coverLetterTemplates as CoverLetterTemplate[];

interface CoverLetterData {
  personalInfo: {
    fullName: string;
    title: string;
    email: string;
    phone: string;
    location: string;
  };
  recipientInfo: {
    name: string;
    title: string;
    company: string;
    address: string;
  };
  date: string;
  salutation: string;
  body: string;
  signOff: string;
}

const COVER_LETTER_PRESETS: Record<string, CoverLetterData> = {
  software: {
    personalInfo: {
      fullName: "Alex Rivera",
      title: "Senior Full Stack Engineer",
      email: "alex.rivera@lunchresume.com",
      phone: "+1 (555) 342-9988",
      location: "San Francisco, CA"
    },
    recipientInfo: {
      name: "Sarah Jenkins",
      title: "Director of Engineering",
      company: "Linear App",
      address: "100 Brannan St, San Francisco, CA"
    },
    date: "June 20, 2026",
    salutation: "Dear Ms. Jenkins,",
    body: "I am writing to express my eager interest in the Senior Full Stack Engineer position at Linear. Having used Linear's toolsets daily for years, I have developed an immense appreciation for your team's relentless pursuit of high-speed performance, absolute design precision, and keyboard-first accessibility.\n\nIn my previous role at Stripe as a Senior Engineer with Core Payments, I spearheaded the structural optimization of payment routing microservices. By auditing memory allocations and pre-compiling network schemas, I achieved a 32% global latency reduction, directly improving checkout success percentages. Later during my tenure at Vercel, I engineered reusable server-rendered template engines that enhanced page-load responsiveness by 45% for over 12,000 corporate tenants.\n\nAt Linear, product craftsmanship and raw technical efficiency are core values. My focus has consistently been at the intersection of high-fidelity user experiences and solid back-end architecture. I am confident my performance-tuning experience and devotion to polished visual detailing will enable me to hit the ground running.\n\nThank you for your time, consideration, and for continuing to raise the bar for software design. I look forward to exploring how my background in latency control can support Linear's long-term product trajectory.",
    signOff: "Sincerely,"
  },
  marketing: {
    personalInfo: {
      fullName: "Marcus Chen",
      title: "VP of Growth & Digital Marketing",
      email: "marcus.chen@lunchresume.com",
      phone: "+1 (555) 883-2940",
      location: "New York, NY"
    },
    recipientInfo: {
      name: "David Vance",
      title: "Chief Marketing Officer",
      company: "Figma Inc.",
      address: "760 Market St, San Francisco, CA"
    },
    date: "June 20, 2026",
    salutation: "Dear Mr. Vance,",
    body: "I am writing to express my strong interest in the VP of Growth & Digital Marketing opening at Figma. Having built campaigns around design collaboration, I am deeply inspired by Figma’s ability to turn a technical browser experience into an active global community of millions of creators.\n\nIn my past role as VP of Growth at Notion, I designed a multi-channel viral engine that scaled self-serve organic signups by 55% using search-ranking optimizations and interactive template galleries. Over three years, we improved enterprise trial conversions by 42% and secured millions in self-serve pipeline. Furthermore, by restructuring our performance analytics stack, I lowered customer acquisition spend (CAC) by 24% while scaling qualified lead volumes by 2.2x year-over-year.\n\nFigma operates at a unique scale where community advocacy is the primary driver of digital growth. I specialize in engineering automated loops and performance-driven content templates that leverage community behavior. I would love the chance to discuss how my data frameworks can help Figma onboard the next generation of creative teams.\n\nThank you for reviewing my credentials. I welcome the opportunity for a discussion regarding your growth roadmap.",
    signOff: "Warmest regards,"
  },
  designer: {
    personalInfo: {
      fullName: "Maya Lin",
      title: "Lead Product Designer",
      email: "maya.lin@lunchresume.com",
      phone: "+1 (555) 774-1211",
      location: "Austin, TX"
    },
    recipientInfo: {
      name: "Sophia Rossi",
      title: "VP of Product Experience",
      company: "Arc Browser (The Browser Company)",
      address: "99 Hudson St, New York, NY"
    },
    date: "June 20, 2026",
    salutation: "Dear Ms. Rossi,",
    body: "I am writing to apply for the Lead Product Designer position at The Browser Company. I have closely watched your team question decades-old assumptions about what an internet browser should feel like. Arc's focus on micro-interactions, spaces, and fluid layouts is exactly the kind of design-driven product development I thrive in.\n\nOver the last five years, I have worked as a Lead Product Designer at Airbnb and Duolingo. At Airbnb, I was tasked with redesigning the host checkout flow, focusing on reducing friction in multi-step visual forms. By implementing tactile drag-and-drop mechanics and micro-animations, we increased checkout completion rates by 18%, saving millions of dollars in abandoned listings. At Duolingo, I designed gamified rewards widgets that boosted weekly retention metrics by 22% across 14 million daily learners.\n\nDesigning for a browser means designing an entire OS of people's digital lives. My philosophy is that software should be joyful, quiet, yet incredibly responsive. I bring a combination of rapid interactive prototyping, exhaustive user testing, and frontend-adjacent viewport constraints to the table.\n\nThank you for considering my application. I would be thrilled to show you my interactive prototypes and talk about the future of digital organization.",
    signOff: "Best regards,"
  }
};

export const CoverLetterSandbox: React.FC = () => {
  const [selectedPersona, setSelectedPersona] = useState<string>('software');
  const [letterData, setLetterData] = useState<CoverLetterData>(COVER_LETTER_PRESETS.software);
  const [activeFormTab, setActiveFormTab] = useState<'sender' | 'recipient' | 'content'>('sender');
  const [styleConfig, setStyleConfig] = useState<{
    template: 'classic' | 'modern' | 'minimalist';
    primaryColor: string;
    fontFamily: 'sans' | 'serif' | 'mono' | 'elegant' | 'slab' | 'space' | 'outfit';
    spacing: 'compact' | 'normal' | 'relaxed';
  }>({
    template: 'classic',
    primaryColor: 'gold',
    fontFamily: 'serif',
    spacing: 'normal'
  });

  const [showPrintOverlay, setShowPrintOverlay] = useState<boolean>(false);
  const [isDownloading, setIsDownloading] = useState<boolean>(false);

  const handleLoadPersona = (personaKey: string) => {
    setSelectedPersona(personaKey);
    const data = COVER_LETTER_PRESETS[personaKey];
    if (data) {
      setLetterData(JSON.parse(JSON.stringify(data)));
    }
  };

  const handleFieldChange = (section: 'personalInfo' | 'recipientInfo' | 'root', field: string, value: string) => {
    setLetterData(prev => {
      if (section === 'root') {
        return { ...prev, [field]: value };
      }
      return {
        ...prev,
        [section]: {
          ...prev[section],
          [field]: value
        }
      };
    });
  };

  const triggerPDFExport = () => {
    setIsDownloading(true);
    setTimeout(() => {
      setIsDownloading(false);
      setShowPrintOverlay(true);
    }, 1200);
  };

  const handleSystemPrint = () => {
    window.print();
  };

  const getAccentStyle = () => {
    switch (styleConfig.primaryColor) {
      case 'emerald': return { bg: 'bg-emerald-600', text: 'text-emerald-700', border: 'border-emerald-500', hex: '#059669' };
      case 'indigo': return { bg: 'bg-indigo-600', text: 'text-indigo-700', border: 'border-[#4f46e5]', hex: '#4f46e5' };
      case 'crimson': return { bg: 'bg-rose-600', text: 'text-rose-700', border: 'border-rose-500', hex: '#e11d48' };
      case 'violet': return { bg: 'bg-violet-600', text: 'text-violet-700', border: 'border-violet-500', hex: '#7c3aed' };
      case 'amber': return { bg: 'bg-amber-500', text: 'text-amber-700', border: 'border-amber-500', hex: '#f59e0b' };
      case 'sky': return { bg: 'bg-sky-500', text: 'text-sky-700', border: 'border-sky-500', hex: '#0ea5e9' };
      case 'gold':
      default:
        return { bg: 'bg-[#8cfbd4]', text: 'text-stone-900', border: 'border-[#8cfbd4]', hex: '#8cfbd4' };
    }
  };

  const fontClass = () => {
    switch (styleConfig.fontFamily) {
      case 'serif': return 'font-serif';
      case 'mono': return 'font-mono';
      case 'elegant': return 'font-elegant';
      case 'slab': return 'font-slab';
      case 'space': return 'font-space';
      case 'outfit': return 'font-outfit';
      case 'sans':
      default:
        return 'font-sans';
    }
  };

  const getSpacingStyle = () => {
    switch (styleConfig.spacing) {
      case 'compact':
        return {
          p: 'p-6 sm:p-8',
          mbHeader: 'pb-3 mb-4',
          mbSection: 'mb-4',
          spaceBody: 'space-y-2.5',
          mbSig: 'mt-5 pt-2'
        };
      case 'relaxed':
        return {
          p: 'p-12 sm:p-14',
          mbHeader: 'pb-7 mb-10',
          mbSection: 'mb-8',
          spaceBody: 'space-y-6',
          mbSig: 'mt-10 pt-5'
        };
      case 'normal':
      default:
        return {
          p: 'p-10 sm:p-12',
          mbHeader: 'pb-5 mb-8',
          mbSection: 'mb-6',
          spaceBody: 'space-y-4',
          mbSig: 'mt-8 pt-4'
        };
    }
  };

  const accent = getAccentStyle();
  const spacingVals = getSpacingStyle();

  return (
    <div className="w-full bg-[#FAF9F5] border border-stone-200 rounded-2xl shadow-xl overflow-hidden p-1 sm:p-4 my-8 relative">
      
      {/* Sandbox Header */}
      <div className="px-6 py-5 bg-stone-900 text-stone-100 flex flex-col md:flex-row justify-between items-center gap-4 rounded-xl border border-stone-850">
        <div>
          <div className="flex items-center gap-1.5 text-xs font-mono font-bold tracking-widest text-[#8cfbd4] uppercase font-bold">
            <Sparkles size={14} className="text-[#8cfbd4]" />
            <span>Interactive sandbox</span>
          </div>
          <h3 className="text-xl font-serif text-white mt-1">Design & Write Your Cover Letter</h3>
        </div>
        <div className="flex items-center gap-2 bg-stone-855 p-1.5 rounded-lg border border-stone-800">
          <span className="text-xs text-stone-400 font-mono">PERSONA:</span>
          {Object.keys(COVER_LETTER_PRESETS).map((key) => (
            <button 
              key={key}
              onClick={() => handleLoadPersona(key)} 
              className={`px-3 py-1 rounded-full text-xs font-semibold tracking-wide transition-all ${selectedPersona === key ? 'bg-[#8cfbd4] text-stone-950 font-bold shadow-md' : 'bg-stone-800 text-stone-300 hover:bg-stone-750'}`}
            >
              {key === 'software' ? 'Engineering' : key === 'marketing' ? 'Marketing' : 'Designer'}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 p-4">
        
        {/* LEFT COLUMN: EDITOR FORM CONTAINER */}
        <div className="xl:col-span-5 flex flex-col bg-white rounded-2xl border border-stone-220/80 p-5 shadow-sm max-h-[85vh] overflow-y-auto">
          
          {/* Layout controls */}
          <div className="mb-6 pb-6 border-b border-stone-150">
            <div className="text-xs font-bold font-mono text-stone-400 uppercase tracking-wider mb-3">LETTER BRANDING STYLE</div>
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div>
                <label className="text-[10px] font-bold text-stone-600 block mb-1">Typography</label>
                <select 
                  value={styleConfig.fontFamily}
                  onChange={(e) => setStyleConfig(prev => ({ ...prev, fontFamily: e.target.value as any }))}
                  className="w-full text-xs bg-stone-50 border border-stone-200 rounded-lg p-2 font-medium"
                >
                  <option value="sans">Minimalist Inter Sans</option>
                  <option value="serif">Classic Editorial Serif</option>
                  <option value="mono">Technical Space Mono</option>
                  <option value="elegant">EB Garamond Elegant</option>
                  <option value="slab">Arvo Retro Slab</option>
                  <option value="space">Space Grotesk Bold</option>
                  <option value="outfit">Outfit Modern Tech</option>
                </select>
              </div>
              <div>
                <label className="text-[10px] font-bold text-stone-600 block mb-1">Layout Preset</label>
                <select 
                  value={styleConfig.template}
                  onChange={(e) => setStyleConfig(prev => ({ ...prev, template: e.target.value as any }))}
                  className="w-full text-xs bg-stone-50 border border-stone-200 rounded-lg p-2 font-medium"
                >
                  {typedCoverLetterTemplates.map((t) => (
                    <option key={t.key} value={t.key}>{t.label}</option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-[10px] font-bold text-stone-600 block mb-1">Branding Accent</label>
                <div className="flex flex-wrap gap-1.5">
                  {[
                    { key: 'gold', color: 'bg-[#8cfbd4]', label: 'Mint' },
                    { key: 'emerald', color: 'bg-emerald-600', label: 'Emerald' },
                    { key: 'indigo', color: 'bg-indigo-600', label: 'Indigo' },
                    { key: 'crimson', color: 'bg-rose-600', label: 'Crimson' },
                    { key: 'violet', color: 'bg-violet-600', label: 'Violet' },
                    { key: 'amber', color: 'bg-amber-500', label: 'Amber' },
                    { key: 'sky', color: 'bg-sky-500', label: 'Sky Blue' }
                  ].map((c) => (
                    <button
                      key={c.key}
                      onClick={() => setStyleConfig(prev => ({ ...prev, primaryColor: c.key }))}
                      title={c.label}
                      className={`w-6 h-6 rounded-full flex items-center justify-center border-2 transition-all ${c.color} ${styleConfig.primaryColor === c.key ? 'border-stone-900 scale-110 shadow-sm ring-2 ring-white' : 'border-transparent'}`}
                    >
                      {styleConfig.primaryColor === c.key && <Check size={11} className={styleConfig.primaryColor === 'gold' ? 'text-stone-900 font-extrabold' : 'text-white font-bold'} />}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-[10px] font-bold text-stone-600 block mb-1">Density Spacing</label>
                <select 
                  value={styleConfig.spacing}
                  onChange={(e) => setStyleConfig(prev => ({ ...prev, spacing: e.target.value as any }))}
                  className="w-full text-xs bg-stone-50 border border-stone-200 rounded-lg p-2 font-medium text-stone-750"
                >
                  <option value="compact">Compact (Dense)</option>
                  <option value="normal">Standard (Classic)</option>
                  <option value="relaxed">Relaxed (Spacious)</option>
                </select>
              </div>
            </div>
          </div>

          {/* Form Tabs Navigation Bar */}
          <div className="flex border-b border-stone-100 mb-4 overflow-x-auto gap-1">
            <button 
              type="button"
              onClick={() => setActiveFormTab('sender')} 
              className={`py-1.5 px-3 text-xs font-semibold whitespace-nowrap transition-all border-b-2 ${activeFormTab === 'sender' ? 'border-[#8cfbd4] text-stone-900 font-bold' : 'border-transparent text-stone-500 hover:text-stone-800'}`}
            >
              1. Sender Details
            </button>
            <button 
              type="button"
              onClick={() => setActiveFormTab('recipient')} 
              className={`py-1.5 px-3 text-xs font-semibold whitespace-nowrap transition-all border-b-2 ${activeFormTab === 'recipient' ? 'border-[#8cfbd4] text-stone-900 font-bold' : 'border-transparent text-stone-500 hover:text-stone-800'}`}
            >
              2. Recipient / Co
            </button>
            <button 
              type="button"
              onClick={() => setActiveFormTab('content')} 
              className={`py-1.5 px-3 text-xs font-semibold whitespace-nowrap transition-all border-b-2 ${activeFormTab === 'content' ? 'border-[#8cfbd4] text-stone-900 font-bold' : 'border-transparent text-stone-500 hover:text-stone-800'}`}
            >
              3. Letter Body
            </button>
          </div>

          {/* Form fields */}
          <div className="space-y-4">
            
            {/* Sender Information */}
            {activeFormTab === 'sender' && (
              <div className="space-y-4 animate-fade-in">
                <div className="text-[10px] font-mono font-bold text-stone-400 uppercase tracking-widest">1. Your Sender Details</div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[9px] font-black text-stone-500 uppercase">Your Name</label>
                    <input 
                      type="text" 
                      value={letterData.personalInfo.fullName}
                      onChange={(e) => handleFieldChange('personalInfo', 'fullName', e.target.value)}
                      className="w-full p-2 text-xs bg-stone-50 border border-stone-200 rounded-lg text-stone-850 font-bold animate-none outline-none focus:ring-1 focus:ring-[#8cfbd4]"
                    />
                  </div>
                  <div>
                    <label className="text-[9px] font-black text-stone-500 uppercase">Your Title</label>
                    <input 
                      type="text" 
                      value={letterData.personalInfo.title}
                      onChange={(e) => handleFieldChange('personalInfo', 'title', e.target.value)}
                      className="w-full p-2 text-xs bg-stone-50 border border-stone-200 rounded-lg text-stone-855 outline-none focus:ring-1 focus:ring-[#8cfbd4]"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="text-[9px] font-black text-stone-500 uppercase">Email</label>
                    <input 
                      type="text" 
                      value={letterData.personalInfo.email}
                      onChange={(e) => handleFieldChange('personalInfo', 'email', e.target.value)}
                      className="w-full p-1.5 text-xs bg-stone-50 border border-stone-200 rounded text-stone-800"
                    />
                  </div>
                  <div>
                    <label className="text-[9px] font-black text-stone-500 uppercase">Phone</label>
                    <input 
                      type="text" 
                      value={letterData.personalInfo.phone}
                      onChange={(e) => handleFieldChange('personalInfo', 'phone', e.target.value)}
                      className="w-full p-1.5 text-xs bg-stone-50 border border-stone-200 rounded text-stone-800"
                    />
                  </div>
                  <div>
                    <label className="text-[9px] font-black text-stone-500 uppercase">Location</label>
                    <input 
                      type="text" 
                      value={letterData.personalInfo.location}
                      onChange={(e) => handleFieldChange('personalInfo', 'location', e.target.value)}
                      className="w-full p-1.5 text-xs bg-stone-50 border border-stone-200 rounded text-stone-800"
                    />
                  </div>
                </div>

                {/* CTA Next Section */}
                <div className="pt-3 border-t border-stone-150 flex justify-end">
                  <button
                    type="button"
                    onClick={() => setActiveFormTab('recipient')}
                    className="px-4 py-2 bg-stone-900 text-[#8cfbd4] hover:bg-stone-800 text-xs font-bold rounded-lg flex items-center gap-1 transition-colors shadow-sm cursor-pointer"
                  >
                    Next: Recipient Details <ChevronRight size={14} />
                  </button>
                </div>
              </div>
            )}

            {/* Recipient Details */}
            {activeFormTab === 'recipient' && (
              <div className="space-y-4 animate-fade-in">
                <div className="text-[10px] font-mono font-bold text-stone-400 uppercase tracking-widest">2. Recipient & Company</div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[9px] font-black text-stone-500 uppercase">Recipient Name</label>
                    <input 
                      type="text" 
                      value={letterData.recipientInfo.name}
                      onChange={(e) => handleFieldChange('recipientInfo', 'name', e.target.value)}
                      className="w-full p-2 text-xs bg-stone-50 border border-stone-200 rounded-lg text-stone-800 font-medium"
                    />
                  </div>
                  <div>
                    <label className="text-[9px] font-black text-stone-500 uppercase">Recipient Title</label>
                    <input 
                      type="text" 
                      value={letterData.recipientInfo.title}
                      onChange={(e) => handleFieldChange('recipientInfo', 'title', e.target.value)}
                      className="w-full p-2 text-xs bg-stone-50 border border-stone-200 rounded-lg text-stone-800"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[9px] font-black text-stone-500 uppercase">Company Name</label>
                    <input 
                      type="text" 
                      value={letterData.recipientInfo.company}
                      onChange={(e) => handleFieldChange('recipientInfo', 'company', e.target.value)}
                      className="w-full p-2 text-xs bg-stone-50 border border-stone-200 rounded-lg text-stone-800 font-bold"
                    />
                  </div>
                  <div>
                    <label className="text-[9px] font-black text-stone-500 uppercase">Company Address</label>
                    <input 
                      type="text" 
                      value={letterData.recipientInfo.address}
                      onChange={(e) => handleFieldChange('recipientInfo', 'address', e.target.value)}
                      className="w-full p-2 text-xs bg-stone-50 border border-stone-200 rounded-lg text-stone-800"
                    />
                  </div>
                </div>

                {/* Back and Next CTAs */}
                <div className="pt-3 border-t border-stone-150 flex justify-between items-center">
                  <button
                    type="button"
                    onClick={() => setActiveFormTab('sender')}
                    className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-600 text-xs font-semibold rounded-lg transition-all cursor-pointer"
                  >
                    ← Back
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveFormTab('content')}
                    className="px-4 py-2 bg-stone-900 text-[#8cfbd4] hover:bg-stone-800 text-xs font-bold rounded-lg flex items-center gap-1 transition-colors shadow-sm cursor-pointer"
                  >
                    Next: Letter Body <ChevronRight size={14} />
                  </button>
                </div>
              </div>
            )}

            {/* Letter Content */}
            {activeFormTab === 'content' && (
              <div className="space-y-4 animate-fade-in">
                <div className="text-[10px] font-mono font-bold text-stone-400 uppercase tracking-widest">3. Cover Letter Frame</div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[9px] font-black text-stone-500 uppercase">Date</label>
                    <input 
                      type="text" 
                      value={letterData.date}
                      onChange={(e) => handleFieldChange('root', 'date', e.target.value)}
                      className="w-full p-2 text-xs bg-stone-50 border border-stone-200 rounded-lg text-stone-800"
                    />
                  </div>
                  <div>
                    <label className="text-[9px] font-black text-stone-500 uppercase">Salutation</label>
                    <input 
                      type="text" 
                      value={letterData.salutation}
                      onChange={(e) => handleFieldChange('root', 'salutation', e.target.value)}
                      className="w-full p-2 text-xs bg-stone-50 border border-stone-200 rounded-lg text-stone-800 font-medium"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[9px] font-black text-stone-500 uppercase">Letter Body (Outcomes Oriented)</label>
                  <textarea 
                    rows={8} 
                    value={letterData.body}
                    onChange={(e) => handleFieldChange('root', 'body', e.target.value)}
                    className="w-full p-2.5 text-xs bg-stone-50 border border-stone-200 rounded-lg text-stone-800 leading-relaxed font-sans focus:outline-[#8cfbd4]"
                  />
                </div>

                <div>
                  <label className="text-[9px] font-black text-stone-500 uppercase">Sign Off</label>
                  <input 
                    type="text" 
                    value={letterData.signOff}
                    onChange={(e) => handleFieldChange('root', 'signOff', e.target.value)}
                    className="w-full p-2 text-xs bg-stone-50 border border-stone-200 rounded-lg text-stone-800 font-medium"
                  />
                </div>

                {/* Back and PDF Preview and Download CTAs */}
                <div className="pt-3 border-t border-stone-150 flex justify-between items-center bg-stone-50/50 p-2.5 rounded-lg border border-stone-100">
                  <button
                    type="button"
                    onClick={() => setActiveFormTab('recipient')}
                    className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-600 text-xs font-semibold rounded-lg transition-all cursor-pointer"
                  >
                    ← Back
                  </button>
                  <button
                    type="button"
                    onClick={triggerPDFExport}
                    className="px-4 py-2 bg-[#8cfbd4] text-stone-950 hover:bg-[#6ef7c0] text-xs font-bold rounded-lg flex items-center gap-1.5 transition-all border border-[#8cfbd4] hover:border-[#6ef7c0] shadow-md cursor-pointer"
                  >
                    {isDownloading ? (
                      <span className="flex items-center gap-1">⏱ Loading...</span>
                    ) : (
                      <>
                        <CheckCircle size={14} /> Download & Preview
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}

          </div>

          {/* Bottom Primary Generate Action */}
          <div className="mt-6 pt-5 border-t border-stone-150">
            <button
              onClick={triggerPDFExport}
              disabled={isDownloading}
              className="w-full py-3.5 bg-[#8cfbd4] text-stone-950 hover:bg-[#6ef7c0] text-xs font-black uppercase tracking-wider rounded-xl transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer"
            >
              {isDownloading ? (
                <>
                  <RefreshCw className="animate-spin" size={16} />
                  Calibrating Margins...
                </>
              ) : (
                <>
                  <Printer size={16} />
                  Compile & Print Letter
                </>
              )}
            </button>
          </div>
        </div>

        {/* RIGHT COLUMN: REFINED LIVE PREVIEW */}
        <div className="xl:col-span-7 bg-stone-200/50 rounded-2xl border border-stone-250 p-6 flex justify-center items-start overflow-y-auto max-h-[85vh] select-none shadow-inner relative">
          
          <div className="absolute top-4 left-4 bg-white/80 border border-stone-300 text-stone-500 px-2 py-1 rounded text-[9px] font-mono uppercase tracking-widest font-bold">
            Real-time Page Layout Output
          </div>

          {/* Letter Sheet */}
          <div 
            id="cover-letter-preview" 
            className={`w-[8.5in] min-h-[11in] bg-white text-stone-850 leading-relaxed shadow-lg max-w-full select-text my-4 text-left ${fontClass()} ${spacingVals.p}`}
            style={{ fontSize: '14.5px' }}
          >
            {/* Elegant Header Layout Style Choice */}
            {styleConfig.template === 'classic' && (
              <div className={`border-b border-stone-200 ${spacingVals.mbHeader}`}>
                <div className="flex justify-between items-start">
                  <div>
                    <h1 className="text-3xl font-bold tracking-tight text-stone-900">{letterData.personalInfo.fullName}</h1>
                    <div className="text-sm font-semibold tracking-wide text-stone-500 mt-1 uppercase">{letterData.personalInfo.title}</div>
                  </div>
                  <div className="text-right text-[11px] font-medium text-stone-500 space-y-0.5">
                    <div>📍 {letterData.personalInfo.location}</div>
                    <div>✉️ {letterData.personalInfo.email}</div>
                    <div>📞 {letterData.personalInfo.phone}</div>
                  </div>
                </div>
              </div>
            )}

            {styleConfig.template === 'modern' && (
              <div className={`flex gap-4 border-l-4 pl-5 ${spacingVals.mbHeader}`} style={{ borderColor: accent.hex }}>
                <div className="flex-1">
                  <h1 className="text-2xl font-bold tracking-tight text-stone-900">{letterData.personalInfo.fullName}</h1>
                  <span className="text-xs font-semibold text-stone-500 uppercase">{letterData.personalInfo.title}</span>
                </div>
                <div className="text-right text-[10px] text-stone-500 font-mono flex flex-col gap-1">
                  <span>{letterData.personalInfo.location} • {letterData.personalInfo.email} • {letterData.personalInfo.phone}</span>
                </div>
              </div>
            )}

            {styleConfig.template === 'minimalist' && (
              <div className={`${styleConfig.spacing === 'compact' ? 'mb-6' : styleConfig.spacing === 'relaxed' ? 'mb-12' : 'mb-10'} text-stone-800`}>
                <h1 className="text-xl font-bold tracking-wider uppercase">{letterData.personalInfo.fullName}</h1>
                <div className="text-xs tracking-widest text-stone-400 font-mono border-b border-stone-100 pb-3 mt-1 mb-3">{letterData.personalInfo.title.toUpperCase()}</div>
                <div className="text-[11px] text-stone-500 flex gap-4 uppercase font-mono tracking-wider">
                  <span>{letterData.personalInfo.location}</span>
                  <span>{letterData.personalInfo.email}</span>
                  <span>{letterData.personalInfo.phone}</span>
                </div>
              </div>
            )}

            {/* Date */}
            <div className={`text-stone-500 text-xs font-medium tracking-wide ${spacingVals.mbSection}`}>
              {letterData.date}
            </div>

            {/* Recipient Details */}
            <div className={`text-stone-700 text-xs flex flex-col gap-0.5 uppercase tracking-wide ${spacingVals.mbSection}`}>
              <span className="font-bold text-stone-900 text-sm normal-case tracking-normal">{letterData.recipientInfo.name}</span>
              <span>{letterData.recipientInfo.title}</span>
              <span className="font-semibold text-stone-800">{letterData.recipientInfo.company}</span>
              <span>{letterData.recipientInfo.address}</span>
            </div>

            {/* Salutation */}
            <div className="mb-4 font-semibold text-stone-900 text-[14px]">
              {letterData.salutation}
            </div>

            {/* Body */}
            <div className={`text-[13.5px] text-stone-700 leading-relaxed whitespace-pre-line text-justify font-normal pr-2 ${spacingVals.spaceBody}`}>
              {letterData.body}
            </div>

            {/* Signature Block */}
            <div className={`${spacingVals.mbSig}`}>
              <div className="text-stone-700 font-medium">{letterData.signOff}</div>
              <div className="text-stone-900 font-bold text-lg mt-6 leading-tight">{letterData.personalInfo.fullName}</div>
              <div className="text-[11px] text-stone-400 mt-1 uppercase tracking-wider font-mono">{letterData.personalInfo.title}</div>
            </div>

          </div>

        </div>

      </div>

      {/* RENDER SYSTEM OVERLAY MODAL ON EXPORT */}
      <AnimatePresence>
        {showPrintOverlay && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-55 bg-stone-900/60 backdrop-blur-xs flex items-center justify-center p-4"
          >
            <motion.div 
              initial={{ scale: 0.95, y: 15 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 15 }}
              className="bg-stone-100 max-w-4xl w-full rounded-2xl shadow-2xl overflow-hidden border border-stone-700 flex flex-col max-h-[92vh]"
            >
              <div className="bg-white px-6 py-4 border-b border-stone-200 flex justify-between items-center">
                <div>
                  <div className="text-xs uppercase font-extrabold tracking-widest text-[#8cfbd4] font-mono">PRINT PIPELINE</div>
                  <h4 className="text-lg font-serif text-stone-900">Your Structured Cover Letter file is active</h4>
                </div>
                <div className="flex gap-2">
                  <button 
                    onClick={handleSystemPrint}
                    className="px-4 py-2 bg-[#8cfbd4] text-stone-950 border border-[#8cfbd4] hover:bg-[#6ef7c0] hover:border-[#6ef7c0] text-xs font-black uppercase rounded-lg shadow transition-colors flex items-center gap-1.5 cursor-pointer"
                  >
                    <Printer size={14} /> Open System Print Mode (PDF)
                  </button>
                  <button 
                    onClick={() => setShowPrintOverlay(false)}
                    className="px-4 py-2 bg-stone-200 text-stone-700 text-xs font-bold uppercase rounded-lg hover:bg-stone-300 transition-colors cursor-pointer"
                  >
                    Keep Editing
                  </button>
                </div>
              </div>

              {/* Real Print frame */}
              <div className="flex-1 p-6 overflow-y-auto flex justify-center bg-stone-300/40">
                <div id="physical-page-print" className={`w-[8.5in] min-h-[11in] max-w-full bg-white shadow-2xl text-stone-850 select-text scale-90 sm:scale-100 origin-top ${spacingVals.p}`}>
                  
                  {/* Embedded matching styled printable layout */}
                  <div className={`w-full text-stone-850 leading-relaxed text-left ${fontClass()}`}>
                    
                    {styleConfig.template === 'classic' && (
                      <div className={`border-b border-stone-200 ${spacingVals.mbHeader}`}>
                        <div className="flex justify-between items-start">
                          <div>
                            <h1 className="text-3xl font-bold tracking-tight text-stone-900">{letterData.personalInfo.fullName}</h1>
                            <div className="text-sm font-semibold tracking-wide text-stone-500 mt-1 uppercase">{letterData.personalInfo.title}</div>
                          </div>
                          <div className="text-right text-[11px] font-medium text-stone-500 space-y-0.5 animate-none">
                            <div>📍 {letterData.personalInfo.location}</div>
                            <div>✉️ {letterData.personalInfo.email}</div>
                            <div>📞 {letterData.personalInfo.phone}</div>
                          </div>
                        </div>
                      </div>
                    )}

                    {styleConfig.template === 'modern' && (
                      <div className={`flex gap-4 border-l-4 pl-5 ${spacingVals.mbHeader}`} style={{ borderColor: accent.hex }}>
                        <div className="flex-1">
                          <h1 className="text-2xl font-bold tracking-tight text-stone-900">{letterData.personalInfo.fullName}</h1>
                          <span className="text-xs font-semibold text-stone-500 uppercase">{letterData.personalInfo.title}</span>
                        </div>
                        <div className="text-right text-[10px] text-stone-500 font-mono">
                          <div>{letterData.personalInfo.location} • {letterData.personalInfo.email} • {letterData.personalInfo.phone}</div>
                        </div>
                      </div>
                    )}

                    {styleConfig.template === 'minimalist' && (
                      <div className={`${styleConfig.spacing === 'compact' ? 'mb-6' : styleConfig.spacing === 'relaxed' ? 'mb-12' : 'mb-10'} text-stone-800`}>
                        <h1 className="text-xl font-bold tracking-wider uppercase">{letterData.personalInfo.fullName}</h1>
                        <div className="text-xs tracking-widest text-stone-400 font-mono border-b border-stone-100 pb-3 mt-1 mb-3">{letterData.personalInfo.title.toUpperCase()}</div>
                        <div className="text-[11px] text-stone-500 flex gap-4 uppercase font-mono tracking-wider">
                          <span>{letterData.personalInfo.location}</span>
                          <span>{letterData.personalInfo.email}</span>
                          <span>{letterData.personalInfo.phone}</span>
                        </div>
                      </div>
                    )}

                    {/* Date */}
                    <div className={`text-stone-500 text-xs font-medium ${spacingVals.mbSection}`}>
                      {letterData.date}
                    </div>

                    {/* Recipient Details */}
                    <div className={`text-stone-700 text-xs flex flex-col gap-0.5 uppercase tracking-wide ${spacingVals.mbSection}`}>
                      <span className="font-bold text-stone-900 text-sm normal-case tracking-normal">{letterData.recipientInfo.name}</span>
                      <span>{letterData.recipientInfo.title}</span>
                      <span className="font-semibold text-stone-800">{letterData.recipientInfo.company}</span>
                      <span>{letterData.recipientInfo.address}</span>
                    </div>

                    {/* Salutation */}
                    <div className="mb-4 font-semibold text-stone-900 text-[14px]">
                      {letterData.salutation}
                    </div>

                    {/* Body */}
                    <div className={`text-[13.5px] text-stone-700 leading-relaxed whitespace-pre-line text-justify ${spacingVals.spaceBody}`}>
                      {letterData.body}
                    </div>

                    {/* Signature */}
                    <div className={`${spacingVals.mbSig}`}>
                      <div className="text-stone-700 font-medium">{letterData.signOff}</div>
                      <div className="text-stone-900 font-bold text-lg mt-6">{letterData.personalInfo.fullName}</div>
                      <div className="text-[11px] text-stone-400 mt-1 uppercase tracking-wider font-mono">{letterData.personalInfo.title}</div>
                    </div>

                  </div>

                </div>
              </div>

              {/* Instructions footer */}
              <div className="p-4 bg-stone-950 text-stone-400 text-xs text-center flex flex-col sm:flex-row justify-between items-center gap-2">
                <span>💡 <strong>Tip:</strong> In the browser Print window, enable "Background graphics" and disable "Headers and footers" for perfect results.</span>
                <span className="text-[#8cfbd4] font-mono">LUNCHRESUME.COM</span>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
};
