/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Plus, Trash2, Printer, RefreshCw, Send, CheckCircle, 
  Sparkles, Award, FileText, ChevronRight, BarChart2, Briefcase, 
  GraduationCap, Code, Check, Users, BrainCircuit
} from 'lucide-react';

import { ResumeData, Experience, Education, Project, TemplateType, StyleConfig, OptimizationPhrase } from '../types';
import resumeTemplates from '../../content/resumeTemplates.json';
import { ResumeTemplate } from '../../types/content';

const typedResumeTemplates = resumeTemplates as ResumeTemplate[];

// Predefined professional sample personas for instant filling
const SAMPLE_PERSONAS: Record<string, ResumeData> = {
  software: {
    personalInfo: {
      fullName: "Alex Rivera",
      title: "Senior Full Stack Engineer",
      email: "alex.rivera@lunchresume.com",
      phone: "+1 (555) 342-9988",
      location: "San Francisco, CA",
      website: "github.com/alexrivera"
    },
    summary: "Metrics-driven Software Engineer with over 6 years of experience designing scalable microservices, cloud architectures, and interactive web applications. Expert in React, Node.js, and distributed system design, specializing in performance optimization.",
    experiences: [
      {
        id: "exp-1",
        company: "Stripe",
        role: "Senior Engineer - Core Payments",
        period: "2023 - Present",
        description: "Spearheaded the redesign of the core transaction ledger API, reducing checkout response latency by 32% worldwide. Led a team of four to launch instant-settlement features processing over $5M in daily transactions."
      },
      {
        id: "exp-2",
        company: "Vercel",
        role: "Front-End Infrastructure Engineer",
        period: "2021 - 2023",
        description: "Pioneered server-side performance frameworks that improved page-load speeds by 45% for over 12,000 corporate clients. Developed open-source reusable layout components utilized in Vercel's core visual libraries."
      }
    ],
    educations: [
      {
        id: "edu-1",
        school: "UC Berkeley",
        degree: "B.S. in Computer Science & Engineering",
        period: "2017 - 2021"
      }
    ],
    projects: [
      {
        id: "proj-1",
        name: "OmniDB Sync Tool",
        description: "Engineered a high-throughput relational database sync module that processes up to 80,000 operations per second with zero data friction.",
        technologies: "Rust, WebSockets, PostgreSQL"
      }
    ],
    skills: ["React", "TypeScript", "Node.js", "System Design", "Kubernetes", "AWS", "GraphQL", "PostgreSQL"]
  },
  marking: {
    personalInfo: {
      fullName: "Sarah Jenkins",
      title: "Lead Growth Marketing Specialist",
      email: "sarah.j@lunchresume.com",
      phone: "+1 (555) 789-2311",
      location: "New York, NY",
      website: "sarahgrowth.co"
    },
    summary: "Dynamic growth marketer with 5+ years of digital acquisition expertise. Proven success scaling early-stage B2B startups and consumer SaaS products from $0 to $10M+ ARR through programmatic SEO, performance creative, and lead-gen pipelines.",
    experiences: [
      {
        id: "exp-1",
        company: "HubSpot",
        role: "Growth Advisory Lead",
        period: "2022 - Present",
        description: "Designed, tested, and optimized organic lead nurture flows that boosted trials-to-demos conversion rates by 22%. Managed a quarterly advertising budget of $150K achieving a consistent 4.2x ROAS."
      },
      {
        id: "exp-2",
        company: "Linear",
        role: "Product Growth Specialist",
        period: "2020 - 2022",
        description: "Accelerated brand awareness programs through targeted partner integrations, yielding a 110% year-over-year increase in user acquisition. Engineered lifecycle marketing flows for 400K+ developers."
      }
    ],
    educations: [
      {
        id: "edu-1",
        school: "Columbia University",
        degree: "B.A. in Communications & Economics",
        period: "2016 - 2020"
      }
    ],
    projects: [
      {
        id: "proj-1",
        name: "ViralLoop Analytics",
        description: "Coded a custom attribution script that captures multi-touch affiliate conversions to attribute customer journeys with 98% accuracy.",
        technologies: "NextJS, Mixpanel, Google Cloud"
      }
    ],
    skills: ["Organic Search (SEO)", "AdWords", "Email Lifecycle", "conversion optimization", "SQL", "A/B Testing", "Mixpanel", "Copywriting"]
  },
  designer: {
    personalInfo: {
      fullName: "Marcus Thorne",
      title: "Senior Product Designer",
      email: "marcus.t@lunchresume.com",
      phone: "+1 (555) 832-6611",
      location: "Austin, TX",
      website: "marcusthorne.design"
    },
    summary: "User-centric interaction designer with a passion for building clean, aesthetic digital tools. Specialized in design systems, high-fidelity responsive modeling, and cooperative user-research cycles. Winner of the 2023 Design Guild Award.",
    experiences: [
      {
        id: "exp-1",
        company: "Figma",
        role: "Senior UX Designer - Prototyping",
        period: "2022 - Present",
        description: "Reconceptualized and mocked the variable prototyping transition panel, reducing friction rates by 18% during designer-developer handoffs. Oversaw layout auditing for 12 core global design structures."
      },
      {
        id: "exp-2",
        company: "Airbnb",
        role: "Systems Interaction Designer",
        period: "2019 - 2022",
        description: "Maintained Airbnb's design language system across web and mobile viewports, introducing custom micro-animations that elevated active digital engagements by 28%."
      }
    ],
    educations: [
      {
        id: "edu-1",
        school: "Rhode Island School of Design (RISD)",
        degree: "B.FA. in Industrial & Interaction Design",
        period: "2015 - 2019"
      }
    ],
    projects: [
      {
        id: "proj-1",
        name: "BentoGrid CSS System",
        description: "Created a visual CSS layout framework downloaded over 50,000 times by developer and designer teams to bootstrap grids in seconds.",
        technologies: "Figma, TailwindCSS, CSS Variables"
      }
    ],
    skills: ["Figma", "Design Systems", "Prototyping", "UI/UX Research", "Framer Motion", "CSS/HTML", "TailwindCSS", "Brand Identity"]
  }
};


// --- MULTI-TEMPLATE RENDER ENGINE ---
export const ResumePreviewer = ({ data, config }: { data: ResumeData; config: StyleConfig }) => {
  const getThemeColors = () => {
    switch (config.primaryColor) {
      case 'emerald': return { text: 'text-emerald-700 font-bold', bg: 'bg-emerald-50', border: 'border-emerald-600', fill: '#047857' };
      case 'indigo': return { text: 'text-indigo-700 font-bold', bg: 'bg-indigo-50', border: 'border-indigo-600', fill: '#4338ca' };
      case 'crimson': return { text: 'text-rose-700 font-bold', bg: 'bg-rose-50', border: 'border-rose-600', fill: '#be123c' };
      case 'violet': return { text: 'text-violet-700 font-bold', bg: 'bg-violet-50', border: 'border-violet-600', fill: '#7c3aed' };
      case 'amber': return { text: 'text-amber-700 font-bold', bg: 'bg-amber-50', border: 'border-amber-600', fill: '#d97706' };
      case 'sky': return { text: 'text-sky-700 font-bold', bg: 'bg-sky-50', border: 'border-sky-600', fill: '#0284c7' };
      case 'gold':
      default:
        return { text: 'text-stone-900 font-bold', bg: 'bg-[#8cfbd4]/20', border: 'border-[#8cfbd4]', fill: '#8cfbd4' };
    }
  };

  const colors = getThemeColors();
  
  const spacingVals = (() => {
    switch (config.spacing) {
      case 'compact':
        return {
          p: 'p-4 sm:p-5',
          mb: 'mb-2.5',
          spaceY: 'space-y-2',
          innerSpaceY: 'space-y-1',
          py: 'py-0.5',
          fontSize: 'text-xs',
          hWidth: 'border-t-4',
          secGap: 'gap-y-3 gap-x-2',
          summaryMargin: 'mb-2.5',
          pb: 'pb-2.5',
        };
      case 'relaxed':
        return {
          p: 'p-10 md:p-12',
          mb: 'mb-8',
          spaceY: 'space-y-6',
          innerSpaceY: 'space-y-3',
          py: 'py-3',
          fontSize: 'text-base',
          hWidth: 'border-t-[12px]',
          secGap: 'gap-y-6 gap-x-5',
          summaryMargin: 'mb-8',
          pb: 'pb-6',
        };
      case 'normal':
      default:
        return {
          p: 'p-8',
          mb: 'mb-5',
          spaceY: 'space-y-4',
          innerSpaceY: 'space-y-1.5',
          py: 'py-1.5',
          fontSize: 'text-sm',
          hWidth: 'border-t-8',
          secGap: 'gap-y-4 gap-x-4',
          summaryMargin: 'mb-5',
          pb: 'pb-4',
        };
    }
  })();

  const spacingClass = () => {
    if (config.spacing === 'compact') return 'space-y-2 text-xs py-1';
    if (config.spacing === 'relaxed') return 'space-y-6 text-base py-3';
    return 'space-y-4 text-sm py-2';
  };

  const fontClass = () => {
    switch (config.fontFamily) {
      case 'serif': return 'font-serif';
      case 'mono': return 'font-mono text-[13px]';
      case 'elegant': return 'font-elegant';
      case 'slab': return 'font-slab';
      case 'space': return 'font-space';
      case 'outfit': return 'font-outfit';
      case 'sans':
      default:
        return 'font-sans';
    }
  };

  // 1. CLASSIC EXECUTIVE TEMPLATE
  if (config.template === 'classic') {
    const borderCol = 
      config.primaryColor === 'emerald' ? 'border-emerald-700' : 
      config.primaryColor === 'indigo' ? 'border-indigo-700' : 
      config.primaryColor === 'crimson' ? 'border-rose-700' : 
      config.primaryColor === 'violet' ? 'border-violet-600' : 
      config.primaryColor === 'amber' ? 'border-amber-600' : 
      config.primaryColor === 'sky' ? 'border-sky-500' : 'border-[#C5A059]';
      
    return (
      <div id="physical-page-print" className={`${spacingVals.p} bg-white text-stone-800 ${fontClass()} ${spacingVals.fontSize} h-full shadow-inner leading-relaxed text-left ${spacingVals.hWidth} ${borderCol} relative`}>
        {/* Header - Centered */}
        <div className={`text-center ${spacingVals.mb}`}>
          <h2 className="text-3xl font-normal text-stone-900 tracking-tight">{data.personalInfo.fullName || 'Your Full Name'}</h2>
          <p className={`text-sm tracking-widest uppercase mt-1 font-medium ${colors.text}`}>{data.personalInfo.title || 'Professional Title'}</p>
          <div className="flex flex-wrap justify-center gap-x-4 gap-y-1 text-xs text-stone-500 mt-2 font-mono">
            {data.personalInfo.email && <span>{data.personalInfo.email}</span>}
            {data.personalInfo.phone && <span>• {data.personalInfo.phone}</span>}
            {data.personalInfo.location && <span>• {data.personalInfo.location}</span>}
            {data.personalInfo.website && <span>• {data.personalInfo.website}</span>}
          </div>
        </div>

        <hr className={`border-stone-200 ${spacingVals.mb}`} />

        {/* Profile Summary */}
        {data.summary && (
          <div className={spacingVals.mb}>
            <h4 className={`text-xs font-bold tracking-widest uppercase mb-2 ${colors.text}`}>Professional Summary</h4>
            <p className="text-stone-600 leading-relaxed text-justify">{data.summary}</p>
          </div>
        )}

        {/* Work Experience */}
        {data.experiences.length > 0 && (
          <div className={spacingVals.mb}>
            <h4 className={`text-xs font-bold tracking-widest uppercase mb-3 ${colors.text}`}>Work Experience</h4>
            <div className={spacingVals.spaceY}>
              {data.experiences.map((exp) => (
                <div key={exp.id} className="group">
                  <div className="flex justify-between items-baseline">
                    <span className="font-bold text-stone-900">{exp.company}</span>
                    <span className="text-xs font-mono text-stone-400">{exp.period}</span>
                  </div>
                  <div className="text-xs italic text-stone-500 mb-1">{exp.role}</div>
                  <p className="text-stone-600 leading-relaxed whitespace-pre-line">{exp.description}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Projects */}
        {data.projects.length > 0 && (
          <div className={spacingVals.mb}>
            <h4 className={`text-xs font-bold tracking-widest uppercase mb-3 ${colors.text}`}>Key Projects</h4>
            <div className={spacingVals.spaceY}>
              {data.projects.map((proj) => (
                <div key={proj.id}>
                  <div className="flex justify-between items-baseline">
                    <span className="font-bold text-stone-900">{proj.name}</span>
                    <span className="text-xs font-mono text-stone-500 bg-stone-100 px-1.5 py-0.5 rounded uppercase">{proj.technologies}</span>
                  </div>
                  <p className="text-stone-600 leading-relaxed mt-1">{proj.description}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Grid for Education & Skills */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-stone-100">
          {/* Education */}
          {data.educations.length > 0 && (
            <div>
              <h4 className={`text-xs font-bold tracking-widest uppercase mb-2 ${colors.text}`}>Education</h4>
              <div className={spacingVals.spaceY}>
                {data.educations.map((edu) => (
                  <div key={edu.id}>
                    <div className="font-bold text-stone-900 text-xs">{edu.school}</div>
                    <div className="text-stone-600 text-xs">{edu.degree}</div>
                    <div className="text-[10px] font-mono text-stone-400">{edu.period}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Skills */}
          {data.skills.length > 0 && (
            <div>
              <h4 className={`text-xs font-bold tracking-widest uppercase mb-2 ${colors.text}`}>Key Skills</h4>
              <div className="flex flex-wrap gap-1.5">
                {data.skills.map((skill, index) => (
                  <span key={index} className="text-xs px-2 py-0.5 bg-stone-50 border border-stone-200 text-stone-700 rounded-sm">
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
        {config.resumeFormat === '2-page' && (
          <div className="absolute top-[10.5in] left-0 right-0 border-t-2 border-dashed border-stone-300 pointer-events-none select-none print:hidden flex items-center justify-center z-20">
            <span className="font-mono text-[9px] bg-stone-900 border border-stone-800 text-[#8cfbd4] px-2.5 py-1 rounded-full select-none transform -translate-y-1/2 uppercase tracking-widest font-bold">
              ✂️ Page 2 Break Line (A4 fold)
            </span>
          </div>
        )}
      </div>
    );
  }

  // 2. MODERN MINIMALIST TEMPLATE
  if (config.template === 'minimalist') {
    return (
      <div id="physical-page-print" className={`${spacingVals.p} bg-white text-stone-800 ${fontClass()} ${spacingVals.fontSize} h-full shadow-inner leading-relaxed text-left relative`}>
        {/* Simple Left align Title */}
        <div className={`border-b border-stone-100 ${spacingVals.pb} ${spacingVals.mb}`}>
          <h2 className="text-2xl font-bold tracking-tight text-stone-900 uppercase">{data.personalInfo.fullName || 'Your Full Name'}</h2>
          <div className="flex justify-between items-center flex-wrap gap-2 mt-1">
            <p className={`text-xs font-mono tracking-widest uppercase font-bold ${colors.text}`}>{data.personalInfo.title || 'Professional Title'}</p>
            <div className="flex flex-wrap gap-x-3 gap-y-0.5 text-xs text-stone-400">
              <span>{data.personalInfo.email}</span>
              <span>|</span>
              <span>{data.personalInfo.phone}</span>
              {data.personalInfo.location && (
                <>
                  <span>|</span>
                  <span>{data.personalInfo.location}</span>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Profile Summary */}
        {data.summary && (
          <div className={`grid grid-cols-1 md:grid-cols-12 gap-4 ${spacingVals.mb}`}>
            <div className="md:col-span-3">
              <h4 className="text-xs font-bold tracking-widest uppercase text-stone-400">About</h4>
            </div>
            <div className="md:col-span-9 text-stone-600 text-sm">
              <p>{data.summary}</p>
            </div>
          </div>
        )}

        {/* Work Experience */}
        {data.experiences.length > 0 && (
          <div className={`grid grid-cols-1 md:grid-cols-12 gap-4 ${spacingVals.mb} pt-4 border-t border-stone-100`}>
            <div className="md:col-span-3">
              <h4 className="text-xs font-bold tracking-widest uppercase text-stone-400">Experience</h4>
            </div>
            <div className={`md:col-span-9 ${spacingVals.spaceY}`}>
              {data.experiences.map((exp) => (
                <div key={exp.id}>
                  <div className="flex justify-between items-baseline">
                    <span className="font-bold text-stone-900 text-sm">{exp.company}</span>
                    <span className="text-[10px] font-mono text-stone-400 uppercase tracking-widest">{exp.period}</span>
                  </div>
                  <div className="text-xs font-medium text-stone-500 mb-2">{exp.role}</div>
                  <p className="text-stone-600 text-xs leading-relaxed whitespace-pre-line">{exp.description}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Projects */}
        {data.projects.length > 0 && (
          <div className={`grid grid-cols-1 md:grid-cols-12 gap-4 ${spacingVals.mb} pt-4 border-t border-stone-100`}>
            <div className="md:col-span-3">
              <h4 className="text-xs font-bold tracking-widest uppercase text-stone-400">Projects</h4>
            </div>
            <div className={`md:col-span-9 ${spacingVals.spaceY}`}>
              {data.projects.map((proj) => (
                <div key={proj.id}>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-stone-900 text-xs">{proj.name}</span>
                    <span className="text-[9px] font-mono text-stone-500 tracking-wider font-bold">({proj.technologies})</span>
                  </div>
                  <p className="text-stone-600 text-xs leading-relaxed mt-1">{proj.description}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Education & Skills */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 pt-4 border-t border-stone-100">
          <div className="md:col-span-3">
            <h4 className="text-xs font-bold tracking-widest uppercase text-stone-400">Background</h4>
          </div>
          <div className="md:col-span-9 grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Education */}
            {data.educations.length > 0 && (
              <div>
                <span className="text-[10px] font-bold text-stone-400 block uppercase tracking-wider mb-2">Education</span>
                {data.educations.map((edu) => (
                  <div key={edu.id} className="mb-2">
                    <div className="font-bold text-stone-800 text-xs">{edu.school}</div>
                    <div className="text-stone-500 text-xs">{edu.degree}</div>
                  </div>
                ))}
              </div>
            )}

            {/* Skills */}
            {data.skills.length > 0 && (
              <div>
                <span className="text-[10px] font-bold text-stone-400 block uppercase tracking-wider mb-2">Core Skills</span>
                <div className="flex flex-wrap gap-1">
                  {data.skills.map((skill, index) => (
                    <span key={index} className="text-[10px] hover:text-stone-900 cursor-default tracking-wide font-mono text-stone-500 bg-stone-50 px-1.5 py-0.5 rounded border border-stone-100">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
        {config.resumeFormat === '2-page' && (
          <div className="absolute top-[10.5in] left-0 right-0 border-t-2 border-dashed border-stone-300 pointer-events-none select-none print:hidden flex items-center justify-center z-20">
            <span className="font-mono text-[9px] bg-stone-900 border border-stone-800 text-[#8cfbd4] px-2.5 py-1 rounded-full select-none transform -translate-y-1/2 uppercase tracking-widest font-bold">
              ✂️ Page 2 Break Line (A4 fold)
            </span>
          </div>
        )}
      </div>
    );
  }

  // 3. CREATIVE CANVAS TEMPLATE
  if (config.template === 'creative') {
    return (
      <div id="physical-page-print" className={`${spacingVals.p} bg-stone-50 text-stone-800 ${fontClass()} ${spacingVals.fontSize} h-full shadow-inner leading-relaxed text-left relative`}>
        {/* Creative Left/Right Header split */}
        <div className={`flex flex-col md:flex-row justify-between items-start md:items-center bg-stone-900 text-white p-6 rounded-lg ${spacingVals.mb} shadow-md`}>
          <div>
            <h2 className="text-2xl font-bold tracking-wide font-serif">{data.personalInfo.fullName || 'Your Full Name'}</h2>
            <p className="text-xs uppercase tracking-widest font-black mt-1 text-stone-300">{data.personalInfo.title || 'Professional Title'}</p>
          </div>
          <div className="text-xs mt-3 md:mt-0 space-y-1 text-stone-400 font-mono">
            <div>✉ {data.personalInfo.email}</div>
            <div>☎ {data.personalInfo.phone}</div>
            {data.personalInfo.location && <div>📍 {data.personalInfo.location}</div>}
          </div>
        </div>

        {/* Dual layout system */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Main timeline column */}
          <div className={`lg:col-span-8 ${spacingVals.spaceY}`}>
            {/* Summary */}
            {data.summary && (
              <div className="bg-white p-5 rounded-lg border border-stone-200 shadow-sm">
                <span className={`inline-block text-[10px] font-extrabold tracking-widest uppercase mb-2 ${colors.text}`}>Executive Pitch</span>
                <p className="text-stone-600 text-sm leading-relaxed">{data.summary}</p>
              </div>
            )}

            {/* Experiences with left vertical thread */}
            {data.experiences.length > 0 && (
              <div className="bg-white p-5 rounded-lg border border-stone-200 shadow-sm">
                <span className={`inline-block text-[10px] font-extrabold tracking-widest uppercase mb-4 ${colors.text}`}>Career Timeline</span>
                <div className={`relative pl-6 border-l-2 border-stone-200 ${spacingVals.spaceY}`}>
                  {data.experiences.map((exp) => {
                    const dotBg = 
                      config.primaryColor === 'emerald' ? 'bg-emerald-600' : 
                      config.primaryColor === 'indigo' ? 'bg-indigo-600' : 
                      config.primaryColor === 'crimson' ? 'bg-rose-600' : 
                      config.primaryColor === 'violet' ? 'bg-violet-600' : 
                      config.primaryColor === 'amber' ? 'bg-amber-600' : 
                      config.primaryColor === 'sky' ? 'bg-sky-500' : 'bg-[#8cfbd4]';
                    return (
                      <div key={exp.id} className="relative">
                        {/* Timeline Node dot */}
                        <div className={`absolute -left-[31px] top-1 w-2.5 h-2.5 rounded-full ring-4 ring-white ${dotBg}`}></div>
                        
                        <div className="flex justify-between items-baseline mb-1">
                          <span className="font-bold text-stone-800 text-sm">{exp.company}</span>
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${colors.bg} ${colors.text}`}>{exp.period}</span>
                        </div>
                        <div className="text-xs font-semibold text-stone-500 mb-2">{exp.role}</div>
                        <p className="text-stone-600 text-xs leading-relaxed whitespace-pre-line">{exp.description}</p>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}
          </div>

          {/* Sidebar column */}
          <div className={`lg:col-span-4 ${spacingVals.spaceY}`}>
            {/* Skills Card */}
            {data.skills.length > 0 && (
              <div className="bg-white p-5 rounded-lg border border-[#F0EBE0] shadow-sm">
                <h4 className={`text-xs font-extrabold uppercase tracking-widest mb-3 ${colors.text}`}>Expertise</h4>
                <div className="flex flex-wrap gap-1.5">
                  {data.skills.map((skill, index) => (
                    <span key={index} className={`text-xs px-2 py-0.5 rounded font-mono ${colors.bg} ${colors.text} font-semibold border border-transparent hover:border-amber-300 transition-colors`}>
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Projects */}
            {data.projects.length > 0 && (
              <div className="bg-white p-5 rounded-lg border border-stone-200 shadow-sm">
                <h4 className={`text-xs font-extrabold uppercase tracking-widest mb-3 ${colors.text}`}>Innovations</h4>
                <div className="space-y-4">
                  {data.projects.map((proj) => (
                    <div key={proj.id} className="border-b border-stone-100 last:border-0 pb-3 last:pb-0">
                      <div className="font-bold text-stone-900 text-xs">{proj.name}</div>
                      <p className="text-stone-500 text-[11px] leading-snug mt-1">{proj.description}</p>
                      <div className="text-[10px] font-mono text-stone-400 mt-1 uppercase">{proj.technologies}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Education */}
            {data.educations.length > 0 && (
              <div className="bg-white p-5 rounded-lg border border-stone-200 shadow-sm">
                <h4 className={`text-xs font-extrabold uppercase tracking-widest mb-3 ${colors.text}`}>Education</h4>
                <div className="space-y-3 text-xs">
                  {data.educations.map((edu) => (
                    <div key={edu.id} className="last:mb-0 mb-2">
                      <div className="font-bold text-stone-800">{edu.school}</div>
                      <div className="text-stone-500">{edu.degree}</div>
                      <div className="text-[10px] text-stone-400 mt-0.5">{edu.period}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
        {config.resumeFormat === '2-page' && (
          <div className="absolute top-[10.5in] left-0 right-0 border-t-2 border-dashed border-stone-300 pointer-events-none select-none print:hidden flex items-center justify-center z-20">
            <span className="font-mono text-[9px] bg-stone-900 border border-stone-800 text-[#8cfbd4] px-2.5 py-1 rounded-full select-none transform -translate-y-1/2 uppercase tracking-widest font-bold">
              ✂️ Page 2 Break Line (A4 fold)
            </span>
          </div>
        )}
      </div>
    );
  }

  // 4. TECH PRO TEMPLATE (Modern)
  return (
    <div id="physical-page-print" className={`${spacingVals.p} bg-[#0F172A] text-slate-300 ${fontClass()} ${spacingVals.fontSize} h-full shadow-inner leading-relaxed text-left relative`}>
      {/* Sleek Tech grid Header */}
      <div className={`border-b border-slate-800 ${spacingVals.pb} ${spacingVals.mb} flex flex-col md:flex-row justify-between items-start md:items-end gap-4`}>
        <div>
          <span className="text-emerald-400 text-xs font-mono select-none">// SYSTEM.RESUME.LOADED</span>
          <h2 className="text-3xl font-black text-white tracking-tight mt-1">{data.personalInfo.fullName || 'Your Name'}</h2>
          <p className="text-xs text-slate-400 font-mono uppercase tracking-wide mt-1">ROLE: <span className="text-slate-200">{data.personalInfo.title || 'Professional Title'}</span></p>
        </div>
        <div className="text-xs font-mono space-y-1 text-slate-400">
          <div><span className="text-slate-500">EMAIL:</span> {data.personalInfo.email}</div>
          <div><span className="text-slate-500">PHONE:</span> {data.personalInfo.phone}</div>
          {data.personalInfo.location && <div><span className="text-slate-500">LOC:</span> {data.personalInfo.location}</div>}
          {data.personalInfo.website && <div><span className="text-slate-500">WWW:</span> <span className="text-emerald-400">{data.personalInfo.website}</span></div>}
        </div>
      </div>

      {/* Summary */}
      {data.summary && (
        <div className={`${spacingVals.mb} bg-slate-900/50 p-4 rounded-lg border border-slate-800/80`}>
          <h4 className="text-xs font-bold font-mono tracking-widest text-[#C5A059] uppercase mb-2">/ PROFESSIONAL_STATEMENT</h4>
          <p className="text-sm text-slate-300 leading-relaxed font-sans">{data.summary}</p>
        </div>
      )}

      {/* Experience */}
      {data.experiences.length > 0 && (
        <div className={spacingVals.mb}>
          <h4 className="text-xs font-bold font-mono tracking-widest text-[#C5A059] uppercase mb-4">/ WORK_HISTORY</h4>
          <div className={spacingVals.spaceY}>
            {data.experiences.map((exp) => (
              <div key={exp.id} className="border-l border-slate-800 pl-4 relative group hover:border-emerald-500/50 transition-colors">
                <div className="absolute -left-1 top-1.5 w-2 h-2 rounded-full bg-slate-800 group-hover:bg-emerald-500 transition-colors"></div>
                <div className="flex justify-between items-baseline flex-wrap">
                  <span className="font-bold text-white text-sm">{exp.company}</span>
                  <span className="text-xs font-mono text-slate-500">{exp.period}</span>
                </div>
                <div className="text-xs font-mono text-emerald-400 mb-2">{exp.role}</div>
                <p className="text-xs text-slate-400 leading-relaxed whitespace-pre-line">{exp.description}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Grid of details */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-slate-800">
        {/* Left: Skills */}
        {data.skills.length > 0 && (
          <div>
            <h4 className="text-xs font-bold font-mono tracking-widest text-[#C5A059] uppercase mb-3">/ TECH_SKILLS</h4>
            <div className="flex flex-wrap gap-1.5">
              {data.skills.map((skill, index) => (
                <span key={index} className="text-[11px] font-mono px-2 py-1 bg-slate-900 text-slate-300 border border-slate-800 rounded-sm hover:border-emerald-500/50 cursor-pointer transition-colors">
                  {skill}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Right: Education & Projects */}
        <div className={spacingVals.spaceY}>
          {data.educations.length > 0 && (
            <div>
              <h4 className="text-xs font-bold font-mono tracking-widest text-[#8cfbd4] uppercase mb-3">/ EDUCATION</h4>
              {data.educations.map((edu) => (
                <div key={edu.id} className="mb-2 text-xs">
                  <div className="font-bold text-white">{edu.school}</div>
                  <div className="text-slate-400">{edu.degree}</div>
                  <div className="text-[10px] font-mono text-slate-500">{edu.period}</div>
                </div>
              ))}
            </div>
          )}

          {data.projects.length > 0 && (
            <div>
              <h4 className="text-xs font-bold font-mono tracking-widest text-[#8cfbd4] uppercase mb-3">/ PROJECTS</h4>
              {data.projects.map((proj) => (
                <div key={proj.id} className="text-xs mb-2">
                  <div className="font-bold text-white">{proj.name}</div>
                  <p className="text-slate-400 text-[11px] leading-snug">{proj.description}</p>
                  <span className="text-[10px] text-emerald-400 font-mono mt-0.5 block">{proj.technologies}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
      {config.resumeFormat === '2-page' && (
        <div className="absolute top-[10.5in] left-0 right-0 border-t-2 border-dashed border-stone-300 pointer-events-none select-none print:hidden flex items-center justify-center z-20">
          <span className="font-mono text-[9px] bg-stone-900 border border-stone-800 text-[#8cfbd4] px-2.5 py-1 rounded-full select-none transform -translate-y-1/2 uppercase tracking-widest font-bold">
            ✂️ Page 2 Break Line (A4 fold)
          </span>
        </div>
      )}
    </div>
  );
};


// --- CORE INTERACTIVE RESUME BUILDER COMPONENT ---
interface ResumeBuilderProps {
  initialFormat?: '1-page' | '2-page';
  initialTemplate?: 'classic' | 'modern' | 'minimalist' | 'creative';
}

export const ResumeBuilderSandbox: React.FC<ResumeBuilderProps> = ({ initialFormat = '1-page', initialTemplate }) => {
  const [selectedPersona, setSelectedPersona] = useState<string>('software');
  const [resumeData, setResumeData] = useState<ResumeData>(SAMPLE_PERSONAS.software);
  
  // Custom helper mapping layout to sensible color and typography defaults
  const getInitialStyle = (): { template: any; primaryColor: string; fontFamily: any } => {
    switch (initialTemplate) {
      case 'modern':
        return { template: 'modern', primaryColor: 'emerald', fontFamily: 'sans' };
      case 'minimalist':
        return { template: 'minimalist', primaryColor: 'slate', fontFamily: 'sans' };
      case 'creative':
        return { template: 'creative', primaryColor: 'amber', fontFamily: 'sans' };
      case 'classic':
      default:
        return { template: 'classic', primaryColor: 'gold', fontFamily: 'serif' };
    }
  };

  const initialStyles = getInitialStyle();

  const [styleConfig, setStyleConfig] = useState<StyleConfig>({
    template: initialStyles.template,
    primaryColor: initialStyles.primaryColor,
    fontFamily: initialStyles.fontFamily,
    spacing: initialFormat === '1-page' ? 'compact' : 'normal',
    resumeFormat: initialFormat
  });

  useEffect(() => {
    setStyleConfig(prev => ({ 
      ...prev, 
      template: initialStyles.template,
      primaryColor: initialStyles.primaryColor,
      fontFamily: initialStyles.fontFamily,
      resumeFormat: initialFormat,
      spacing: initialFormat === '1-page' ? 'compact' : 'normal'
    }));
  }, [initialFormat, initialTemplate]);

  const [activeTab, setActiveTab] = useState<'info' | 'experiences' | 'projects' | 'educations' | 'skills'>('info');
  const [customSkillInput, setCustomSkillInput] = useState<string>('');
  const [showPrintOverlay, setShowPrintOverlay] = useState<boolean>(false);
  const [isDownloading, setIsDownloading] = useState<boolean>(false);

  // Load predetermined template parameters when selecting a preset persona
  const handleLoadPersona = (personaName: string) => {
    setSelectedPersona(personaName);
    const data = SAMPLE_PERSONAS[personaName];
    if (data) {
      setResumeData(JSON.parse(JSON.stringify(data)));
    }
  };

  // Modify Personal information fields
  const handlePersonalInfoUpdate = (field: string, value: string) => {
    setResumeData(prev => ({
      ...prev,
      personalInfo: {
        ...prev.personalInfo,
        [field]: value
      }
    }));
  };

  // Experiences Handlers: Update, Add, Remove
  const handleExperienceChange = (id: string, field: keyof Experience, value: string) => {
    setResumeData(prev => ({
      ...prev,
      experiences: prev.experiences.map(exp => exp.id === id ? { ...exp, [field]: value } : exp)
    }));
  };

  const handleAddExperience = () => {
    const newId = `exp-${Date.now()}`;
    const newExp: Experience = {
      id: newId,
      company: "Acme Corporation",
      role: "Job Title",
      period: "2024 - Present",
      description: "Implemented standard solutions leading to metrics of 10% improvements."
    };
    setResumeData(prev => ({
      ...prev,
      experiences: [...prev.experiences, newExp]
    }));
    setActiveTab('experiences');
  };

  const handleRemoveExperience = (id: string) => {
    setResumeData(prev => ({
      ...prev,
      experiences: prev.experiences.filter(exp => exp.id !== id)
    }));
  };

  // Educations Handlers: Update, Add, Remove
  const handleEducationChange = (id: string, field: keyof Education, value: string) => {
    setResumeData(prev => ({
      ...prev,
      educations: prev.educations.map(edu => edu.id === id ? { ...edu, [field]: value } : edu)
    }));
  };

  const handleAddEducation = () => {
    const newId = `edu-${Date.now()}`;
    const newEdu: Education = {
      id: newId,
      school: "University Name",
      degree: "B.S. in Professional Studies",
      period: "2020 - 2024"
    };
    setResumeData(prev => ({
      ...prev,
      educations: [...prev.educations, newEdu]
    }));
  };

  const handleRemoveEducation = (id: string) => {
    setResumeData(prev => ({
      ...prev,
      educations: prev.educations.filter(edu => edu.id !== id)
    }));
  };

  // Projects Handlers: Update, Add, Remove
  const handleProjectChange = (id: string, field: keyof Project, value: string) => {
    setResumeData(prev => ({
      ...prev,
      projects: prev.projects.map(proj => proj.id === id ? { ...proj, [field]: value } : proj)
    }));
  };

  const handleAddProject = () => {
    const newId = `proj-${Date.now()}`;
    const newProj: Project = {
      id: newId,
      name: "Acme Analytics Portal",
      description: "Launched an internal dashboard capturing sales traffic data and visualizing logs.",
      technologies: "Next.js, Tailwind, D3"
    };
    setResumeData(prev => ({
      ...prev,
      projects: [...prev.projects, newProj]
    }));
  };

  const handleRemoveProject = (id: string) => {
    setResumeData(prev => ({
      ...prev,
      projects: prev.projects.filter(proj => proj.id !== id)
    }));
  };

  // Skills handlers
  const handleSkillAdd = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = customSkillInput.trim();
    if (clean && !resumeData.skills.includes(clean)) {
      setResumeData(prev => ({
        ...prev,
        skills: [...prev.skills, clean]
      }));
      setCustomSkillInput('');
    }
  };

  const handleSkillRemove = (tag: string) => {
    setResumeData(prev => ({
      ...prev,
      skills: prev.skills.filter(s => s !== tag)
    }));
  };

  const triggerPDFExport = () => {
    setIsDownloading(true);
    setTimeout(() => {
      setIsDownloading(false);
      setShowPrintOverlay(true);
    }, 1500);
  };

  const handleSystemPrint = () => {
    window.print();
  };

  return (
    <div className="w-full bg-[#FAF9F5] border border-stone-200 rounded-2xl shadow-xl overflow-hidden p-1 sm:p-4 my-8 relative">
      
      {/* Upper header: Sandbox Controls */}
      <div className="px-6 py-5 bg-stone-900 text-stone-100 flex flex-col md:flex-row justify-between items-center gap-4 rounded-xl border border-stone-850">
        <div>
          <div className="flex items-center gap-1.5 text-xs font-mono font-bold tracking-widest text-[#8cfbd4] uppercase text-[#8cfbd4] uppercase">
            <Sparkles size={14} className="text-[#8cfbd4]" />
            <span>Interactive sandbox</span>
          </div>
          <h3 className="text-xl font-serif text-white mt-1">Build & Blueprint Your Resume</h3>
        </div>
        
        {/* Industry fast pickers */}
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs text-stone-400 font-mono">PERSONA:</span>
          <button 
            onClick={() => handleLoadPersona('software')} 
            className={`px-3 py-1.5 rounded-full text-xs font-medium tracking-wide transition-all ${selectedPersona === 'software' ? 'bg-[#8cfbd4] text-stone-950 font-bold shadow-md' : 'bg-stone-800 text-stone-300 hover:bg-stone-750'}`}
          >
            Software
          </button>
          <button 
            onClick={() => handleLoadPersona('marking')} 
            className={`px-3 py-1.5 rounded-full text-xs font-medium tracking-wide transition-all ${selectedPersona === 'marking' ? 'bg-[#8cfbd4] text-stone-950 font-bold shadow-md' : 'bg-stone-800 text-stone-300 hover:bg-stone-750'}`}
          >
            Marketing
          </button>
          <button 
            onClick={() => handleLoadPersona('designer')} 
            className={`px-3 py-1.5 rounded-full text-xs font-medium tracking-wide transition-all ${selectedPersona === 'designer' ? 'bg-[#8cfbd4] text-stone-950 font-bold shadow-md' : 'bg-stone-800 text-stone-300 hover:bg-stone-750'}`}
          >
            UX Designer
          </button>
        </div>
      </div>

      {/* Styled Grid layout */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 p-4">
        
        {/* Left Side: Modular Form Interface (5 Columns) */}
        <div className="xl:col-span-5 flex flex-col gap-4">
          
          {/* Format/Layout customization block */}
          <div className="p-5 bg-white border border-stone-200.5 rounded-xl text-left shadow-sm">
            <h4 className="text-xs font-extrabold uppercase font-sans tracking-wider text-stone-400 mb-3 block">1. Style & Typography</h4>
            
            <div className="space-y-4">
              {/* Template Pickers */}
              <div>
                <label className="text-xs font-semibold text-stone-700 block mb-1.5">Template Layout</label>
                <div className="grid grid-cols-2 gap-2">
                  {typedResumeTemplates.map((t) => (
                    <button
                      key={t.key}
                      onClick={() => setStyleConfig(prev => ({ ...prev, template: t.key as TemplateType }))}
                      className={`px-3 py-2 rounded-lg border text-left text-xs transition-all ${styleConfig.template === t.key ? 'bg-[#8cfbd4]/10 border-[#8cfbd4] text-stone-900 font-bold' : 'bg-stone-50 border-stone-200 text-stone-600 hover:bg-stone-100'}`}
                    >
                      {t.label}
                    </button>
                  ))}
                </div>
              </div>
              {/* Accent Color Pickers */}
              <div>
                <label className="text-xs font-semibold text-stone-700 block mb-1.5">Accent Palette</label>
                <div className="flex flex-wrap gap-2">
                  {[
                    { key: 'gold', color: 'bg-[#8cfbd4]', label: 'Mint' },
                    { key: 'emerald', color: 'bg-emerald-600', label: 'Emerald' },
                    { key: 'indigo', color: 'bg-indigo-600', label: 'Indigo' },
                    { key: 'crimson', color: 'bg-rose-600', label: 'Crimson' },
                    { key: 'violet', color: 'bg-violet-600', label: 'Violet' },
                    { key: 'amber', color: 'bg-amber-500', label: 'Amber' },
                    { key: 'sky', color: 'bg-sky-500', label: 'Sky Blue' }
                  ].map((c) => (
                    <button
                      key={c.key}
                      onClick={() => setStyleConfig(prev => ({ ...prev, primaryColor: c.key }))}
                      title={c.label}
                      className={`w-7 h-7 rounded-full flex items-center justify-center border-2 transition-all ${c.color} ${styleConfig.primaryColor === c.key ? 'border-stone-900 scale-110 shadow-sm ring-2 ring-white' : 'border-stone-200'}`}
                    >
                      {styleConfig.primaryColor === c.key && <Check size={12} className={styleConfig.primaryColor === 'gold' ? 'text-stone-900 font-extrabold' : 'text-white font-bold'} />}
                    </button>
                  ))}
                </div>
              </div>

              {/* Target Resume Page Formats */}
              <div className="pt-2">
                <label className="text-xs font-semibold text-stone-700 block mb-1.5">Target Page Architecture</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setStyleConfig(prev => ({ ...prev, resumeFormat: '1-page', spacing: 'compact' }))}
                    className={`px-3 py-2.5 rounded-lg border text-left text-xs transition-all ${styleConfig.resumeFormat === '1-page' ? 'bg-[#8cfbd4]/10 border-[#8cfbd4] text-stone-900 font-bold' : 'bg-stone-50 border-stone-200 text-stone-600 hover:bg-stone-100'}`}
                  >
                    <div className="flex items-center gap-1.5 justify-between mb-0.5">
                      <span className="font-semibold block">1-Pager CV</span>
                      <span className="text-[8px] font-mono font-bold bg-[#8cfbd4]/30 px-1 py-0.2 rounded text-[#3ea884]">OPT</span>
                    </div>
                    <span className="text-[10px] text-stone-500 font-light block leading-snug">Auto-forces compact density for under 5 yrs experience.</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setStyleConfig(prev => ({ ...prev, resumeFormat: '2-page', spacing: 'normal' }))}
                    className={`px-3 py-2.5 rounded-lg border text-left text-xs transition-all ${styleConfig.resumeFormat === '2-page' ? 'bg-stone-900 border-stone-950 text-white font-bold' : 'bg-stone-50 border-stone-200 text-stone-600 hover:bg-stone-100'}`}
                  >
                    <div className="flex items-center gap-1.5 justify-between mb-0.5">
                      <span className="font-semibold block">2-Pager CV</span>
                      <span className="text-[8px] font-mono font-bold bg-stone-750 px-1 py-0.2 rounded text-[#8cfbd4]">PRO</span>
                    </div>
                    <span className="text-[10px] text-stone-400 font-light block leading-snug">Visual folding splits for extensive multi-tenure senior files.</span>
                  </button>
                </div>
              </div>

              {/* Spacing & Fonts */}
              <div className="grid grid-cols-2 gap-3 pt-2">
                <div>
                  <label className="text-xs font-semibold text-stone-700 block mb-1">Typography</label>
                  <select 
                    value={styleConfig.fontFamily}
                    onChange={(e) => setStyleConfig(prev => ({ ...prev, fontFamily: e.target.value as any }))}
                    className="w-full text-xs p-2 bg-stone-50 border border-stone-200 rounded-lg text-stone-800"
                  >
                    <option value="sans">Dynamic Inter Sans</option>
                    <option value="serif">Playfair Editorial</option>
                    <option value="mono">JetBrains Mono Tech</option>
                    <option value="elegant">EB Garamond Elegant</option>
                    <option value="slab">Arvo Retro Slab</option>
                    <option value="space">Space Grotesk Bold</option>
                    <option value="outfit">Outfit Modern Tech</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-semibold text-stone-700 block mb-1">Density Spacing</label>
                  <select 
                    value={styleConfig.spacing}
                    onChange={(e) => setStyleConfig(prev => ({ ...prev, spacing: e.target.value as any }))}
                    className="w-full text-xs p-2 bg-stone-50 border border-stone-200 rounded-lg text-stone-800"
                  >
                    <option value="compact">Compact (Dense)</option>
                    <option value="normal">Standard (Classic)</option>
                    <option value="relaxed">Relaxed (Spacious)</option>
                  </select>
                </div>
              </div>
            </div>
          </div>

          {/* Form Tabs Navigation */}
          <div className="p-4 bg-white border border-stone-200.5 rounded-xl shadow-xs text-left">
            <h4 className="text-xs font-extrabold uppercase font-sans tracking-wider text-stone-400 mb-3 block">2. Edit Resume Content</h4>
            
            <div className="flex border-b border-stone-100 mb-4 overflow-x-auto gap-1">
              <button 
                onClick={() => setActiveTab('info')} 
                className={`py-1.5 px-3 text-xs font-semibold whitespace-nowrap transition-all border-b-2 ${activeTab === 'info' ? 'border-[#8cfbd4] text-stone-900 font-bold' : 'border-transparent text-stone-500 hover:text-stone-800'}`}
              >
                Profile
              </button>
              <button 
                onClick={() => setActiveTab('experiences')} 
                className={`py-1.5 px-3 text-xs font-semibold whitespace-nowrap transition-all border-b-2 ${activeTab === 'experiences' ? 'border-[#8cfbd4] text-[#111]' : 'border-transparent text-stone-500 hover:text-stone-800'}`}
              >
                Experience ({resumeData.experiences.length})
              </button>
              <button 
                onClick={() => setActiveTab('projects')} 
                className={`py-1.5 px-3 text-xs font-semibold whitespace-nowrap transition-all border-b-2 ${activeTab === 'projects' ? 'border-[#8cfbd4] text-[#111]' : 'border-transparent text-stone-500 hover:text-stone-800'}`}
              >
                Projects ({resumeData.projects.length})
              </button>
              <button 
                onClick={() => setActiveTab('educations')} 
                className={`py-1.5 px-3 text-xs font-semibold whitespace-nowrap transition-all border-b-2 ${activeTab === 'educations' ? 'border-[#8cfbd4] text-[#111]' : 'border-transparent text-stone-500 hover:text-stone-800'}`}
              >
                Education
              </button>
              <button 
                onClick={() => setActiveTab('skills')} 
                className={`py-1.5 px-3 text-xs font-semibold whitespace-nowrap transition-all border-b-2 ${activeTab === 'skills' ? 'border-[#8cfbd4] text-[#111]' : 'border-transparent text-stone-500 hover:text-stone-800'}`}
              >
                Skills
              </button>
            </div>

            {/* TAB INTERFACES */}
            <div className="space-y-4 min-h-[300px]">

              {/* INFO TAB */}
              {activeTab === 'info' && (
                <div className="space-y-3">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] font-bold text-stone-500 uppercase block mb-1">Full Name</label>
                      <input 
                        type="text" 
                        value={resumeData.personalInfo.fullName} 
                        onChange={(e) => handlePersonalInfoUpdate('fullName', e.target.value)} 
                        className="w-full p-2 text-xs bg-stone-50 border border-stone-200 rounded-md text-stone-800 font-medium"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-bold text-stone-500 uppercase block mb-1">Target Title</label>
                      <input 
                        type="text" 
                        value={resumeData.personalInfo.title} 
                        onChange={(e) => handlePersonalInfoUpdate('title', e.target.value)} 
                        className="w-full p-2 text-xs bg-stone-50 border border-stone-200 rounded-md text-stone-800 font-medium"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] font-bold text-stone-500 uppercase block mb-1">Email</label>
                      <input 
                        type="email" 
                        value={resumeData.personalInfo.email} 
                        onChange={(e) => handlePersonalInfoUpdate('email', e.target.value)} 
                        className="w-full p-2 text-xs bg-stone-50 border border-stone-200 rounded-md text-stone-800 font-medium"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-bold text-stone-500 uppercase block mb-1">Phone</label>
                      <input 
                        type="text" 
                        value={resumeData.personalInfo.phone} 
                        onChange={(e) => handlePersonalInfoUpdate('phone', e.target.value)} 
                        className="w-full p-2 text-xs bg-stone-50 border border-stone-200 rounded-md text-stone-800 font-medium"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] font-bold text-stone-500 uppercase block mb-1">Location</label>
                      <input 
                        type="text" 
                        value={resumeData.personalInfo.location || ''} 
                        onChange={(e) => handlePersonalInfoUpdate('location', e.target.value)} 
                        className="w-full p-2 text-xs bg-stone-50 border border-stone-200 rounded-md text-stone-800 font-medium"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-bold text-stone-500 uppercase block mb-1">Portfolio Link</label>
                      <input 
                        type="text" 
                        value={resumeData.personalInfo.website || ''} 
                        onChange={(e) => handlePersonalInfoUpdate('website', e.target.value)} 
                        className="w-full p-2 text-xs bg-stone-50 border border-stone-200 rounded-md text-stone-800 font-medium"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-[10px] font-bold text-stone-500 uppercase block mb-1">Professional Pitch (Summary)</label>
                    <textarea 
                      rows={5} 
                      value={resumeData.summary} 
                      onChange={(e) => setResumeData(prev => ({ ...prev, summary: e.target.value }))}
                      className="w-full p-2 text-xs bg-stone-50 border border-stone-200 rounded-md text-stone-800 focus:outline-[#8cfbd4]"
                    />
                  </div>
                  
                  {/* Next Step CTA */}
                  <div className="pt-3 border-t border-stone-100 flex justify-end">
                    <button
                      type="button"
                      onClick={() => setActiveTab('experiences')}
                      className="px-4 py-2 bg-stone-900 text-[#8cfbd4] text-xs font-bold rounded-lg flex items-center gap-1 hover:bg-stone-850 hover:text-white transition-colors shadow-sm cursor-pointer"
                    >
                      Next: Experience <ChevronRight size={14} />
                    </button>
                  </div>
                </div>
              )}

              {/* EXPERIENCES TAB */}
              {activeTab === 'experiences' && (
                <div className="space-y-4">
                  {resumeData.experiences.map((exp, idx) => (
                    <div key={exp.id} className="p-3 bg-stone-50 rounded-lg border border-stone-200/80 relative text-left">
                      <button 
                        onClick={() => handleRemoveExperience(exp.id)} 
                        className="absolute top-2 right-2 p-1 text-stone-400 hover:text-red-500 hover:bg-red-50 rounded cursor-pointer"
                        title="Delete slot"
                      >
                        <Trash2 size={13} />
                      </button>
                      
                      <div className="text-[11px] font-bold text-stone-400 mb-2 font-mono uppercase">Role #{idx+1}</div>

                      <div className="grid grid-cols-2 gap-3 mb-2">
                        <div>
                          <label className="text-[9px] font-bold text-stone-500 uppercase block mb-0.5">Company</label>
                          <input 
                            type="text" 
                            value={exp.company} 
                            onChange={(e) => handleExperienceChange(exp.id, 'company', e.target.value)} 
                            className="w-full p-1.5 text-xs bg-white border border-stone-200 rounded text-stone-800 font-semibold"
                          />
                        </div>
                        <div>
                          <label className="text-[9px] font-bold text-stone-500 uppercase block mb-0.5">Role Title</label>
                          <input 
                            type="text" 
                            value={exp.role} 
                            onChange={(e) => handleExperienceChange(exp.id, 'role', e.target.value)} 
                            className="w-full p-1.5 text-xs bg-white border border-stone-200 rounded text-stone-800"
                          />
                        </div>
                      </div>

                      <div className="mb-2">
                        <label className="text-[9px] font-bold text-stone-500 uppercase block mb-0.5">Period Timeline</label>
                        <input 
                          type="text" 
                          value={exp.period} 
                          onChange={(e) => handleExperienceChange(exp.id, 'period', e.target.value)} 
                          className="w-full p-1.5 text-xs bg-white border border-stone-200 rounded text-stone-800 font-mono"
                        />
                      </div>

                      <div>
                        <label className="text-[9px] font-bold text-stone-500 uppercase block mb-0.5">Impact Descriptions</label>
                        <textarea 
                          rows={3} 
                          value={exp.description} 
                          onChange={(e) => handleExperienceChange(exp.id, 'description', e.target.value)} 
                          className="w-full p-1.5 text-xs bg-white border border-stone-200 rounded text-stone-850"
                        />
                      </div>
                    </div>
                  ))}

                  <button 
                    onClick={handleAddExperience}
                    className="w-full py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-semibold rounded-lg flex items-center justify-center gap-1.5 border border-dashed border-stone-350 transition-all mb-4 cursor-pointer"
                  >
                    <Plus size={14} /> Add Experience Slot
                  </button>

                  {/* Next Step CTA */}
                  <div className="pt-3 border-t border-stone-100 flex justify-between items-center">
                    <button
                      type="button"
                      onClick={() => setActiveTab('info')}
                      className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-600 text-xs font-semibold rounded-lg transition-all cursor-pointer"
                    >
                      ← Back
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveTab('projects')}
                      className="px-4 py-2 bg-stone-900 text-[#8cfbd4] text-xs font-bold rounded-lg flex items-center gap-1 hover:bg-stone-850 hover:text-white transition-colors shadow-sm cursor-pointer"
                    >
                      Next: Projects <ChevronRight size={14} />
                    </button>
                  </div>
                </div>
              )}

              {/* PROJECTS TAB */}
              {activeTab === 'projects' && (
                <div className="space-y-4">
                  {resumeData.projects.map((proj, idx) => (
                    <div key={proj.id} className="p-3 bg-stone-50 rounded-lg border border-stone-200 relative text-left">
                      <button 
                        onClick={() => handleRemoveProject(proj.id)} 
                        className="absolute top-2 right-2 p-1 text-stone-400 hover:text-red-500 rounded cursor-pointer"
                      >
                        <Trash2 size={13} />
                      </button>
                      
                      <div className="text-[11px] font-bold text-stone-400 mb-2 font-mono uppercase">Project #{idx+1}</div>

                      <div className="grid grid-cols-2 gap-3 mb-2">
                        <div>
                          <label className="text-[9px] font-bold text-stone-500 uppercase block mb-0.5">Project Name</label>
                          <input 
                            type="text" 
                            value={proj.name} 
                            onChange={(e) => handleProjectChange(proj.id, 'name', e.target.value)} 
                            className="w-full p-1.5 text-xs bg-white border border-stone-200 rounded text-stone-800 font-bold"
                          />
                        </div>
                        <div>
                          <label className="text-[9px] font-bold text-stone-500 uppercase block mb-0.5">Technologies Used</label>
                          <input 
                            type="text" 
                            value={proj.technologies} 
                            onChange={(e) => handleProjectChange(proj.id, 'technologies', e.target.value)} 
                            className="w-full p-1.5 text-xs bg-white border border-stone-200 rounded text-stone-800 font-mono"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="text-[9px] font-bold text-stone-500 uppercase block mb-0.5">Description</label>
                        <textarea 
                          rows={2.5} 
                          value={proj.description} 
                          onChange={(e) => handleProjectChange(proj.id, 'description', e.target.value)} 
                          className="w-full p-1.5 text-xs bg-white border border-stone-200 rounded text-stone-800"
                        />
                      </div>
                    </div>
                  ))}

                  <button 
                    onClick={handleAddProject}
                    className="w-full py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-semibold rounded-lg flex items-center justify-center gap-1.5 border border-dashed border-stone-350 mb-4 cursor-pointer"
                  >
                    <Plus size={14} /> Add Project Slot
                  </button>

                  {/* Next Step CTA */}
                  <div className="pt-3 border-t border-stone-100 flex justify-between items-center">
                    <button
                      type="button"
                      onClick={() => setActiveTab('experiences')}
                      className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-600 text-xs font-semibold rounded-lg transition-all cursor-pointer"
                    >
                      ← Back
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveTab('educations')}
                      className="px-4 py-2 bg-stone-900 text-[#8cfbd4] text-xs font-bold rounded-lg flex items-center gap-1 hover:bg-stone-850 hover:text-white transition-colors shadow-sm cursor-pointer"
                    >
                      Next: Education <ChevronRight size={14} />
                    </button>
                  </div>
                </div>
              )}

              {/* EDUCATIONS TAB */}
              {activeTab === 'educations' && (
                <div className="space-y-4">
                  {resumeData.educations.map((edu, idx) => (
                    <div key={edu.id} className="p-3 bg-stone-50 rounded-lg border border-stone-200 relative text-left">
                      <button 
                        onClick={() => handleRemoveEducation(edu.id)} 
                        className="absolute top-2 right-2 p-1 text-stone-400 hover:text-red-500 rounded cursor-pointer"
                      >
                        <Trash2 size={13} />
                      </button>
                      
                      <div className="text-[11px] font-bold text-stone-400 mb-2 font-mono uppercase">Education #{idx+1}</div>

                      <div className="grid grid-cols-2 gap-3 mb-2">
                        <div>
                          <label className="text-[9px] font-bold text-stone-500 uppercase block mb-0.5">School / University</label>
                          <input 
                            type="text" 
                            value={edu.school} 
                            onChange={(e) => handleEducationChange(edu.id, 'school', e.target.value)} 
                            className="w-full p-1.5 text-xs bg-white border border-stone-200 rounded text-stone-800 font-bold"
                          />
                        </div>
                        <div>
                          <label className="text-[9px] font-bold text-stone-500 uppercase block mb-0.5">Degree & Field</label>
                          <input 
                            type="text" 
                            value={edu.degree} 
                            onChange={(e) => handleEducationChange(edu.id, 'degree', e.target.value)} 
                            className="w-full p-1.5 text-xs bg-white border border-stone-200 rounded text-stone-800"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="text-[9px] font-bold text-stone-500 uppercase block mb-0.5">Period (Years)</label>
                        <input 
                          type="text" 
                          value={edu.period} 
                          onChange={(e) => handleEducationChange(edu.id, 'period', e.target.value)} 
                          className="w-full p-1.5 text-xs bg-white border border-stone-200 rounded text-stone-800 font-mono"
                        />
                      </div>
                    </div>
                  ))}

                  <button 
                    onClick={handleAddEducation}
                    className="w-full py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-semibold rounded-lg flex items-center justify-center gap-1.5 border border-dashed border-stone-350 mb-4 cursor-pointer"
                  >
                    <Plus size={14} /> Add Education Block
                  </button>

                  {/* Next Step CTA */}
                  <div className="pt-3 border-t border-stone-100 flex justify-between items-center">
                    <button
                      type="button"
                      onClick={() => setActiveTab('projects')}
                      className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-600 text-xs font-semibold rounded-lg transition-all cursor-pointer"
                    >
                      ← Back
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveTab('skills')}
                      className="px-4 py-2 bg-stone-900 text-[#8cfbd4] text-xs font-bold rounded-lg flex items-center gap-1 hover:bg-stone-850 hover:text-white transition-colors shadow-sm cursor-pointer"
                    >
                      Next: Skills <ChevronRight size={14} />
                    </button>
                  </div>
                </div>
              )}

              {/* SKILLS TAB */}
              {activeTab === 'skills' && (
                <div className="space-y-4">
                  <div>
                    <label className="text-[10px] font-bold text-stone-500 uppercase block mb-1">Add Key Skills</label>
                    <form onSubmit={handleSkillAdd} className="flex gap-2">
                      <input 
                        type="text" 
                        placeholder="e.g. Google Analytics" 
                        value={customSkillInput}
                        onChange={(e) => setCustomSkillInput(e.target.value)}
                        className="flex-1 p-2 text-xs bg-stone-50 border border-stone-200 rounded-lg text-stone-800 font-medium"
                      />
                      <button 
                        type="submit"
                        className="px-4 py-2 bg-[#8cfbd4] text-stone-950 rounded-lg text-xs font-bold hover:bg-[#6ef7c0] border border-[#8cfbd4] hover:border-[#6ef7c0] transition-colors cursor-pointer font-sans"
                      >
                        Add
                      </button>
                    </form>
                  </div>

                  <div>
                    <label className="text-[10px] font-bold text-stone-500 uppercase block mb-1.5 text-left">Current Inventory ({resumeData.skills.length})</label>
                    <div className="flex flex-wrap gap-2">
                      {resumeData.skills.map((skill) => (
                        <span 
                          key={skill} 
                          className="inline-flex items-center gap-1 px-2.5 py-1 bg-stone-100 text-stone-700 text-xs rounded-full font-semibold border border-stone-200"
                        >
                          {skill}
                          <button 
                            type="button" 
                            onClick={() => handleSkillRemove(skill)}
                            className="text-stone-400 hover:text-stone-600 font-bold ml-1 cursor-pointer"
                          >
                            ×
                          </button>
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Next Step CTA */}
                  <div className="pt-3 border-t border-stone-100 flex justify-between items-center bg-stone-50/50 p-2.5 rounded-lg border border-stone-100">
                    <button
                      type="button"
                      onClick={() => setActiveTab('educations')}
                      className="px-3 py-1.5 bg-stone-100 hover:bg-stone-200 text-stone-600 text-xs font-semibold rounded-lg transition-all cursor-pointer"
                    >
                      ← Back
                    </button>
                    <button
                      type="button"
                      onClick={triggerPDFExport}
                      className="px-4 py-2 bg-[#8cfbd4] text-stone-950 hover:bg-[#6ef7c0] text-xs font-bold rounded-lg flex items-center gap-1.5 transition-all border border-[#8cfbd4] hover:border-[#6ef7c0] shadow-md cursor-pointer"
                    >
                      {isDownloading ? (
                        <span className="flex items-center gap-1">⏱ Loading...</span>
                      ) : (
                        <>
                          <CheckCircle size={14} /> Download & Preview
                        </>
                      )}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Side: Professional Live Canvas Previewer (7 Columns) */}
        <div className="xl:col-span-7 flex flex-col gap-4">
          <div className="bg-stone-100 p-4 border border-stone-250 rounded-2xl flex flex-col h-full min-h-[580px] lg:min-h-[700px] relative">
            
            {/* Live indicator block */}
            <div className="flex justify-between items-center bg-white/70 backdrop-blur-xs p-3 rounded-xl border border-stone-200 mb-3 shadow-xs">
              <div className="flex items-center gap-2 text-xs font-semibold text-stone-700">
                <span className="w-2.5 h-2.5 rounded-full bg-green-500 animate-ping"></span>
                <span className="w-2.5 h-2.5 absolute rounded-full bg-green-500"></span>
                <span>LIVE PREVIEW</span>
              </div>

              {/* Action buttons */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleLoadPersona(selectedPersona)}
                  className="p-1 px-2.5 bg-stone-50 hover:bg-stone-200 border border-stone-200 text-stone-600 text-xs font-bold rounded-lg flex items-center gap-1 transition-all cursor-pointer"
                  title="Reset edits to archetype standard"
                >
                  <RefreshCw size={12} /> Reset
                </button>
                <button
                  onClick={triggerPDFExport}
                  className="p-1 px-3 bg-[#8cfbd4] hover:bg-[#6ef7c0] text-stone-950 text-xs font-bold rounded-lg flex items-center gap-1.5 transition-all border border-[#8cfbd4] hover:border-[#6ef7c0] shadow-sm cursor-pointer"
                >
                  {isDownloading ? (
                    <span className="flex items-center gap-1">⏱ Loading...</span>
                  ) : (
                    <>
                      <Printer size={12} /> PDF Print
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Simulated Sheet Canvas */}
            <div className="flex-1 overflow-y-auto max-h-[800px] rounded-xl shadow-lg border border-stone-250 relative">
              <ResumePreviewer data={resumeData} config={styleConfig} />
            </div>

            {/* Real bottom tip box */}
            <div className="mt-3 text-[11px] text-stone-500 text-center font-mono uppercase bg-stone-50/50 p-2 rounded-lg">
              🔒 Built Offline-securely • Data never leaves your device • 100% Free
            </div>
          </div>
        </div>

      </div>

      {/* STUNNING US LETTER PRINT MODE FULL SCREEN OVERLAY */}
      <AnimatePresence>
        {showPrintOverlay && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-stone-900/90 backdrop-blur-md z-[60] flex items-center justify-center p-4"
          >
            <motion.div 
              initial={{ scale: 0.95, y: 15 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 15 }}
              className="bg-stone-100 max-w-4xl w-full rounded-2xl shadow-2xl overflow-hidden border border-stone-700 flex flex-col max-h-[92vh]"
            >
              <div className="bg-white px-6 py-4 border-b border-stone-200 flex justify-between items-center text-left">
                <div>
                  <div className="text-xs uppercase font-extrabold tracking-widest text-[#8cfbd4] font-mono">PRINT PIPELINE</div>
                  <h4 className="text-lg font-serif text-stone-900">Your High-Converting PDF File ready</h4>
                </div>
                <div className="flex gap-2">
                  <button 
                    onClick={handleSystemPrint}
                    className="px-4 py-2 bg-[#8cfbd4] text-stone-950 border border-[#8cfbd4] hover:bg-[#6ef7c0] hover:border-[#6ef7c0] text-xs font-black uppercase rounded-lg shadow transition-colors flex items-center gap-1.5 cursor-pointer"
                  >
                    <Printer size={14} /> Open System Print Mode (PDF)
                  </button>
                  <button 
                    onClick={() => setShowPrintOverlay(false)}
                    className="px-4 py-2 bg-stone-200 text-stone-700 text-xs font-bold uppercase rounded-lg hover:bg-stone-300 transition-colors cursor-pointer"
                  >
                    Keep Editing
                  </button>
                </div>
              </div>

              {/* Real Print frame */}
              <div className="flex-1 p-6 overflow-y-auto flex justify-center bg-stone-300/40">
                <div id="physical-page-print" className={`w-[8.5in] ${styleConfig.resumeFormat === '2-page' ? 'min-h-[22in]' : 'min-h-[11in]'} max-w-full bg-white shadow-2xl p-8 text-stone-850 select-text scale-90 sm:scale-100 origin-top relative`}>
                  <ResumePreviewer data={resumeData} config={styleConfig} />
                </div>
              </div>

              {/* Instructions footer */}
              <div className="p-4 bg-stone-950 text-stone-400 text-xs text-center flex flex-col sm:flex-row justify-between items-center gap-2">
                <span>💡 <strong>Tip:</strong> In the browser Print window, enable "Background graphics" and disable "Headers and footers" for perfect results.</span>
                <span className="text-[#8cfbd4] font-mono">LUNCHRESUME.COM</span>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
      
    </div>
  );
};


// --- RESUME BULLET OPTIMIZER DIAGRAM ---
export const InteractiveOptimizer: React.FC = () => {
  const [selectedBullet, setSelectedBullet] = useState<string>('bullet-1');
  const [isDecoded, setIsDecoded] = useState<boolean>(false);

  const optimizationData: Record<string, OptimizationPhrase> = {
    'bullet-1': {
      id: 'bullet-1',
      original: "I was responsible for writing standard software and helped fix bugs in our server.",
      improved: "Coengineered 3 distributed microservices using Node.js and led code audits that eliminated 100% of high-severity back-end security vulnerabilities prior to launching.",
      benefit: "Swaps weak legacy phrasing ('responsible for', 'helped') with strong action verbs ('coengineered', 'led') and integrates specific, measurable outcomes (100% eliminated)."
    },
    'bullet-2': {
      id: 'bullet-2',
      original: "Did social media campaigns and created graphic assets for our company page.",
      improved: "Spearheaded quarterly programmatic paid search campaigns that delivered 110% year-over-year user acquisition growth, converting a $150K advertising budget at 4.2x ROAS.",
      benefit: "Substitutes passive activities ('did', 'created') for scalable marketing nomenclature ('spearheaded programmatic', 'acquisition growth') paired with real budget indicators."
    },
    'bullet-3': {
      id: 'bullet-3',
      original: "Helped redesign our website's layout and did user tests.",
      improved: "Architected a design system representing 40+ reusable component elements, boosting active digital engagements by 28% and decreasing overall checkout layout friction by 18%.",
      benefit: "Transfers vague contributions into measurable system UX engineering results, highlighting structural design ownership (Architected, Figma Design System)."
    }
  };

  const activePhrase = optimizationData[selectedBullet];

  const handleOptimizingClick = () => {
    setIsDecoded(true);
  };

  useEffect(() => {
    // Reset optimizer whenever the selector bullet shifts
    setIsDecoded(false);
  }, [selectedBullet]);

  return (
    <div className="flex flex-col items-center p-6 md:p-8 bg-white rounded-2xl shadow-sm border border-stone-200 my-8 text-left w-full">
      <div className="flex items-center gap-2 px-3 py-1 bg-stone-100 text-stone-600 text-xs font-bold tracking-widest uppercase rounded-full mb-4 border border-stone-200 font-mono">
        <BrainCircuit size={14} className="text-amber-500" /> RESUME DECODER & METRIC ENGINE
      </div>
      <h3 className="font-serif text-2xl text-stone-900 font-medium mb-3 text-center w-full">Optimize Weak Bullets</h3>
      <p className="text-sm text-stone-500 mb-6 text-center max-w-md mx-auto leading-relaxed">
        Recruiters and ATS algorithms ignore generic passive statements. Select a typical candidate statement below to see how our engine decodes it with high-metric impacts.
      </p>

      {/* Interactive phrase selector */}
      <div className="flex flex-wrap justify-center gap-2 mb-6 w-full max-w-lg">
        <button 
          onClick={() => setSelectedBullet('bullet-1')}
          className={`px-3 py-1.5 text-xs font-semibold rounded-full border transition-all cursor-pointer ${selectedBullet === 'bullet-1' ? 'bg-stone-900 text-white border-stone-900' : 'bg-transparent text-stone-600 border-stone-200 hover:bg-stone-55'}`}
        >
          Tech (Alex)
        </button>
        <button 
          onClick={() => setSelectedBullet('bullet-2')}
          className={`px-3 py-1.5 text-xs font-semibold rounded-full border transition-all cursor-pointer ${selectedBullet === 'bullet-2' ? 'bg-stone-900 text-white border-stone-900' : 'bg-transparent text-stone-600 border-stone-200 hover:bg-stone-55'}`}
        >
          Marketing (Sarah)
        </button>
        <button 
          onClick={() => setSelectedBullet('bullet-3')}
          className={`px-3 py-1.5 text-xs font-semibold rounded-full border transition-all cursor-pointer ${selectedBullet === 'bullet-3' ? 'bg-stone-900 text-white border-stone-900' : 'bg-transparent text-stone-600 border-stone-200 hover:bg-stone-55'}`}
        >
          UX Design (Marcus)
        </button>
      </div>

      {/* Dynamic comparison stage */}
      <div className="relative w-full max-w-2xl bg-stone-50 rounded-xl border border-stone-200/60 p-5 mt-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-stretch">
          
          {/* Weak side */}
          <div className="p-4 bg-white rounded-lg border border-red-150 shadow-sm flex flex-col justify-between text-left">
            <div>
              <div className="flex items-center gap-1.5 text-[9px] font-extrabold text-red-500 font-mono tracking-wider mb-2 uppercase">
                🔴 PASSIVE DRAFT (38% SCORE)
              </div>
              <p className="text-stone-700 text-sm leading-relaxed italic">"{activePhrase.original}"</p>
            </div>
            
            {!isDecoded && (
              <button 
                onClick={handleOptimizingClick}
                className="w-full mt-4 py-2 bg-gradient-to-r from-[#8cfbd4] to-[#6ef7c0] border border-[#8cfbd4] text-stone-950 text-xs font-black rounded flex items-center justify-center gap-1.5 shadow hover:opacity-90 transition-all cursor-pointer"
              >
                <Sparkles size={13} className="text-amber-500 animate-pulse" /> Inject Metrics & Optimize
              </button>
            )}
          </div>

          {/* Strong side */}
          <div className="p-4 bg-[#FBFBF9] rounded-lg border border-stone-250 flex flex-col justify-between relative overflow-hidden text-left">
            {isDecoded ? (
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="h-full flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center gap-1.5 text-[9px] font-extrabold text-emerald-600 font-mono tracking-wider mb-2 uppercase font-bold">
                    🟢 DECODED HIGH-IMPACT (98% SCORE)
                  </div>
                  <p className="text-stone-900 text-sm font-semibold leading-relaxed">"{activePhrase.improved}"</p>
                </div>
                
                <div className="mt-3 pt-3 border-t border-stone-200">
                  <div className="text-[10px] uppercase font-bold text-stone-500 font-mono">Optimizer Insight</div>
                  <p className="text-stone-600 text-[11px] leading-snug mt-1">{activePhrase.benefit}</p>
                </div>
              </motion.div>
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-stone-400 py-8 w-full">
                <FileText size={24} className="opacity-30 mb-2" />
                <span className="text-xs font-mono">OPTIMIZER STANDBY</span>
                <span className="text-[10px] text-stone-400 mt-1">Click the button on the left</span>
              </div>
            )}
          </div>

        </div>
      </div>

      <div className="mt-5 text-stone-400 text-xs text-center font-serif italic w-full">
        💡 <strong>Remember:</strong> AI decoders focus on verbs (Coengineered, Lead) and quantifiable digits (3 distributed, 100% eliminated).
      </div>
    </div>
  );
};


// --- ATS MATCH RATE CHART ---
export const PerformanceMetricDiagram: React.FC = () => {
  const [distance, setDistance] = useState<'tech' | 'marketing' | 'design'>('tech');
  
  // Values representing average recruiter interview callback rates across multiple candidates tested (standard doc vs LunchResume layout)
  const data = {
    tech: { std: 34, lunch: 85, label: "Tech / Soft Dev" },
    marketing: { std: 41, lunch: 91, label: "Growth Marketing" },
    design: { std: 28, lunch: 79, label: "UI/UX & Creative" }
  };

  const currentData = data[distance];

  return (
    <div className="flex flex-col md:flex-row gap-8 items-center p-8 bg-stone-900 text-stone-100 rounded-xl my-8 border border-stone-850 shadow-lg text-left w-full">
      <div className="flex-1 min-w-[245px]">
        <h3 className="font-serif text-2xl mb-2 text-[#8cfbd4]">ATS Calibration & Performance</h3>
        <p className="text-stone-400 text-sm mb-4 leading-relaxed">
          Comparing call-back and initial screen rates across 1,400+ targeted corporate tests. Structured ATS-friendly formatting guarantees higher compliance matches.
        </p>
        
        {/* Switchers */}
        <div className="flex flex-wrap gap-2 mt-6">
          {(['tech', 'marketing', 'design'] as const).map((industry) => (
            <button 
              key={industry}
              onClick={() => setDistance(industry)} 
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all border cursor-pointer ${distance === industry ? 'bg-[#8cfbd4] text-stone-950 border-[#8cfbd4]' : 'bg-transparent text-stone-400 border-stone-750 hover:border-stone-600 hover:text-stone-200'}`}
            >
              {data[industry].label}
            </button>
          ))}
        </div>
        
        <div className="mt-6 font-mono text-xs text-stone-500 flex items-center gap-2">
          <BarChart2 size={14} className="text-[#8cfbd4]" /> 
          <span>RECRUITER INTERVIEW CALLBACK RATE (HIGHER IS BETTER)</span>
        </div>
      </div>
      
      {/* Visual Chart */}
      <div className="relative w-64 h-72 bg-stone-850/50 rounded-xl border border-stone-800/80 p-6 flex justify-around items-end">
        {/* Horizontal grid lines */}
        <div className="absolute inset-x-0 inset-y-6 flex flex-col justify-between pointer-events-none opacity-5">
           <div className="w-full h-[1px] bg-white"></div>
           <div className="w-full h-[1px] bg-white"></div>
           <div className="w-full h-[1px] bg-white"></div>
           <div className="w-full h-[1px] bg-white"></div>
        </div>
 
        {/* Standard Doc bar */}
        <div className="w-20 flex flex-col justify-end items-center h-full z-10 font-sans">
          <div className="flex-1 w-full flex items-end justify-center relative mb-3">
            <div className="absolute -top-7 text-xs font-mono text-stone-400 font-bold bg-stone-900/90 py-1 px-1.5 rounded">{currentData.std}%</div>
            <motion.div 
              className="w-full bg-stone-700 rounded-t-lg border-t border-stone-600/40"
              initial={{ height: 0 }}
              animate={{ height: `${currentData.std}%` }}
              transition={{ type: "spring", stiffness: 85, damping: 15 }}
            />
          </div>
          <div className="h-6 flex items-center text-[10px] font-bold text-stone-500 uppercase tracking-wider">Standard Doc</div>
        </div>
 
        {/* LunchResume bar */}
        <div className="w-20 flex flex-col justify-end items-center h-full z-10 font-sans font-sans">
          <div className="flex-1 w-full flex items-end justify-center relative mb-3">
            <div className="absolute -top-7 text-xs font-mono text-[#8cfbd4] font-bold bg-stone-900/90 py-1 px-1.5 rounded">{currentData.lunch}%</div>
            <motion.div 
              className="w-full bg-[#8cfbd4] rounded-t-lg shadow-[0_0_20px_rgba(140,251,212,0.2)] relative overflow-hidden"
              initial={{ height: 0 }}
              animate={{ height: `${currentData.lunch}%` }}
              transition={{ type: "spring", stiffness: 85, damping: 15, delay: 0.1 }}
            >
               {/* Shine reflection */}
               <div className="absolute inset-0 bg-gradient-to-tr from-transparent to-white/20"></div>
            </motion.div>
          </div>
          <div className="h-6 flex items-center text-[10px] font-bold text-[#8cfbd4] uppercase tracking-wider">LUNCHRESUME</div>
        </div>
      </div>
    </div>
  );
};
