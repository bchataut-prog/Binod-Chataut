import fs from 'fs';
import { execSync } from 'child_process';

async function main() {
  const url = 'https://raw.githubusercontent.com/bchataut-prog/Binod-Chataut/main/lunchresume_-free-resume-builder%20(1).zip';
  console.log('Downloading zip from:', url);
  const res = await fetch(url);
  if (!res.ok) {
    throw new Error(`Failed to download: ${res.statusText}`);
  }
  const buffer = Buffer.from(await res.arrayBuffer());
  fs.writeFileSync('temp.zip', buffer);
  console.log('Downloaded temp.zip of size:', buffer.length);
  
  try {
    execSync('unzip -o temp.zip -d temp_unzipped');
    console.log('Extracted successfully into temp_unzipped/ directory');
  } catch (err) {
    console.log('System unzip failed, trying other methods', err.message);
  }
}

main().catch(console.error);
