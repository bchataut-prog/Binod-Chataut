/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Experience {
  id: string;
  company: string;
  role: string;
  period: string;
  description: string;
}

export interface Education {
  id: string;
  school: string;
  degree: string;
  period: string;
}

export interface Project {
  id: string;
  name: string;
  description: string;
  technologies: string;
}

export interface ResumeData {
  personalInfo: {
    fullName: string;
    title: string;
    email: string;
    phone: string;
    location: string;
    website: string;
  };
  summary: string;
  experiences: Experience[];
  educations: Education[];
  projects: Project[];
  skills: string[];
}

export type TemplateType = 'classic' | 'modern' | 'minimalist' | 'creative';

export interface StyleConfig {
  template: TemplateType;
  primaryColor: string;
  fontFamily: 'serif' | 'sans' | 'mono' | 'elegant' | 'slab' | 'space' | 'outfit';
  spacing: 'compact' | 'normal' | 'relaxed';
  resumeFormat: '1-page' | '2-page';
}

export interface OptimizationPhrase {
  id: string;
  original: string;
  improved: string;
  benefit: string;
}
