/**
 * @license
 * SPDX-License-Identifier: Apache-2.5
 */

import React, { useState, useEffect } from 'react';
import { HeroScene, QuantumComputerScene } from './components/QuantumScene';
import { ResumeBuilderSandbox, InteractiveOptimizer, PerformanceMetricDiagram } from './components/Diagrams';
import { CoverLetterSandbox } from './components/CoverLetterSandbox';
import { 
  ArrowDown, Menu, X, FileText, ChevronRight, HelpCircle, 
  CheckCircle, Heart, Lock, ShieldCheck, ArrowLeft, BookOpen, 
  Clock, PenTool, Award, ExternalLink, Sparkles, Layers
} from 'lucide-react';

const BLOG_POSTS = [
  {
    id: "ats-secrets",
    title: "Algorithms Over Aesthetics: How the ATS Parsing Funnel Actually Operates",
    excerpt: "Most job seekers design for the human eye first, but their resumes never get scanned by a recruiter. Learn how databases index your technical tags and filter out complex column formats.",
    category: "ATS Calibration",
    readTime: "5 min read",
    date: "June 18, 2026",
    content: "The Applicant Tracking System (ATS) is not a sophisticated artificial intelligence; it is a glorified database parser. When you submit a resume, the software strips away formatting, reads text left-to-right, top-to-bottom, and crawls for matching keywords requested in the company's job posting.\n\n### The Multi-Column Fallacy\nMany graphic editors encourage candidates to build dual-column resumes. In theory, this maximizes visual balance. In practice, generic ATS parsers read columns straight across. If your left column lists a job title and your right column lists description details, the parser merges them into a single incomprehensible sentence, completely breaking your skills metadata association.\n\n### Rules for ATS Compliance:\n1. **Use Single-Column Grids:** Keep information stacked cleanly to guarantee predictable left-to-right scanning.\n2. **Avoid SVG Decorators:** Decorative progress bars or graphical skill scales are invisible to parsers, and frequently trigger extraction errors.\n3. **Integrate Exact Keywords:** Customize your subheadings to match the exact phrasing in the requirements of the job specification.\n\nKeep headers and spacing standard, avoiding unreadable overlapping layouts."
  },
  {
    id: "impact-metrics",
    title: "Grammar of Achievement: Replacing Passive Descriptions with Quantified Metrics",
    excerpt: "Avoid starting bullets with passive phrases like 'Responsible for' or 'Helped with'. Discover the STAR method to transform basic job listings into high-converting achievement metrics.",
    category: "Resume Engineering",
    readTime: "7 min read",
    date: "June 15, 2026",
    content: "Recruiters scan through hundreds of profiles every hour. They immediately filter out profiles that read like a copy-paste of a generic job description. To transition from a passive candidate to an active elite hire, every bullet point must be coengineered using precise action verbs and quantifiable results.\n\n### The Formula for High-Converting Bullets\nEvery descriptive sentence should follow this simple syntax:\n`[Strong Action Verb] + [Specific Technical Choice or Process] + [Measurable Business Metric Target]`\n\n### Passive vs. Metric-Driven Examples:\n* **Passive (0% callbacks):** 'Responsible for looking after customer payments and helping team deploy new website.'\n* **Active (32% improvement):** 'Coengineered payment routing microservices with Node.js, achieving a 32% global latency reduction that secured an additional $5M in weekly processed volumes.'\n\nFocus on speed, cost, precision, or scaling numbers is the easiest path to secure call-backs."
  },
  {
    id: "six-second-scan",
    title: "The Six-Second Rule: Setting Up Direct Hierarchical Scanning Paths",
    excerpt: "Studies show recruiters spend an average of six seconds scanning a profile before rendering a decision. Learn how typography grid lines and margins guide attention directly to your highlights.",
    category: "Visual Science",
    readTime: "4 min read",
    date: "May 29, 2026",
    content: "When a human reviewer finally opens your PDF file, you have exactly six seconds to convey key credentials: your Name, current Target Role, your 2 strongest employment tenures, and your core technical skills.\n\n### Scanning Path Design\nHuman readers naturally follow an 'F-shaped' visual hierarchy. They scan the top header block first, then trace down the left border margin, scanning the beginning of your professional roles. Here is how our presets are built to leverage this:\n\n* **Primary Heading:** Rendered in elegant serif or high-contrast modern sans to instantly lock user attention on name and identity.\n* **Generous White Space:** Maintaining an 18-24px visual padding is crucial. Cramming too much text into narrow margins causes visual fatigue, forcing the reader to click away early.\n* **Skill Tagging Block:** Placed in simple tables or separated by elegant delimiters so they can be instantly parsed in under 1 second."
  }
];

const App: React.FC = () => {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [currentView, setCurrentView] = useState<'home' | 'builder' | 'coverletter' | 'blogs'>('home');
  const [selectedBlogId, setSelectedBlogId] = useState<string | null>(null);
  const [builderInitialFormat, setBuilderInitialFormat] = useState<'1-page' | '2-page'>('1-page');

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navigateTo = (view: 'home' | 'builder' | 'coverletter' | 'blogs', sectionId?: string) => (e?: React.MouseEvent) => {
    if (e) e.preventDefault();
    setMenuOpen(false);
    setCurrentView(view);
    setSelectedBlogId(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
    
    if (sectionId) {
      setTimeout(() => {
        const element = document.getElementById(sectionId);
        if (element) {
          const headerOffset = 80;
          const elementPosition = element.getBoundingClientRect().top;
          const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
          window.scrollTo({
            top: offsetPosition,
            behavior: 'smooth'
          });
        }
      }, 150);
    }
  };

  const scrollToSection = (id: string) => (e: React.MouseEvent) => {
    e.preventDefault();
    setMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      const headerOffset = 80;
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
    }
  };

  return (
    <div className="min-h-screen bg-white text-stone-850 font-sans selection:bg-[#8cfbd4] selection:text-stone-900">
      
      {/* Dynamic Navigation (Inspired by Resume.io) */}
      <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? 'bg-white shadow-sm py-3 border-b border-stone-150' : 'bg-white/95 backdrop-blur-md py-4 border-b border-stone-100'}`}>
        <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
          
          {/* Logo & Brand Container */}
          <div className="flex items-center gap-10">
            <div className="flex items-center gap-2 cursor-pointer" onClick={navigateTo('home')}>
              {/* Modern Minimalists Bookmark/Doc Icon in #8cfbd4 */}
              <div className="w-8 h-8 bg-stone-900 text-[#8cfbd4] rounded-lg flex items-center justify-center font-poppins font-black text-base shadow-xs border border-stone-855">
                LR
              </div>
              <span className="font-poppins font-bold text-lg tracking-tight text-stone-900 flex items-center">
                lunch<span className="text-stone-800 font-light">resume</span>
                <span className="w-1.5 h-1.5 rounded-full bg-[#8cfbd4] ml-1"></span>
              </span>
            </div>

            {/* Desktop Center Links (Resume.io Sentence-Case Layout) */}
            <div className="hidden lg:flex items-center gap-7 text-[14px] font-medium text-stone-605">
              <div className="relative group">
                <a 
                  href="#templates" 
                  onClick={navigateTo('builder')} 
                  className={`hover:text-[#8cfbd4] active:text-stone-900 transition-colors flex items-center gap-1 cursor-pointer py-1 ${currentView === 'builder' ? 'text-stone-900 font-bold' : ''}`}
                >
                  Templates
                  <svg className="w-3 h-3 text-stone-400 group-hover:text-[#8cfbd4] transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M19 9l-7 7-7-7" />
                  </svg>
                </a>
                {/* Stunning 1-Pager vs 2-Pager Interactive Dropdown */}
                <div className="absolute top-full left-1/2 -translate-x-1/2 mt-1 w-80 bg-white border border-stone-200 rounded-xl shadow-xl py-3.5 px-4 hidden group-hover:block animate-fade-in z-50 text-left">
                  <div className="mb-2.5 pb-2 border-b border-stone-100">
                    <span className="text-[10px] font-mono uppercase tracking-widest text-[#3ea884] font-bold">Select Template Architecture</span>
                  </div>
                  <div className="space-y-1">
                    <a 
                      href="#templates-1-page"
                      onClick={(e) => {
                        e.preventDefault();
                        setBuilderInitialFormat('1-page');
                        navigateTo('builder')();
                      }}
                      className="group/item flex items-start gap-3 p-2.5 rounded-lg hover:bg-stone-50 transition-all text-left"
                    >
                      <div className="w-8 h-8 rounded-lg bg-[#8cfbd4]/15 text-[#3ea884] flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                        1P
                      </div>
                      <div>
                        <div className="text-xs font-bold text-stone-900 group-hover/item:text-[#3ea884] transition-colors flex items-center gap-1">
                          1-Pager Resume Templates
                        </div>
                        <p className="text-[11px] text-stone-500 font-light mt-0.5 leading-normal">Optimized single layout structure. Designed for entry to mid-level (under 5 years of experience).</p>
                      </div>
                    </a>

                    <a 
                      href="#templates-2-page"
                      onClick={(e) => {
                        e.preventDefault();
                        setBuilderInitialFormat('2-page');
                        navigateTo('builder')();
                      }}
                      className="group/item flex items-start gap-3 p-2.5 rounded-lg hover:bg-stone-50 transition-all text-left"
                    >
                      <div className="w-8 h-8 rounded-lg bg-stone-900 text-[#8cfbd4] flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
                        2P
                      </div>
                      <div>
                        <div className="text-xs font-bold text-stone-900 group-hover/item:text-[#3ea884] transition-colors flex items-center gap-1">
                          2-Pager Resume Templates
                        </div>
                        <p className="text-[11px] text-stone-500 font-light mt-0.5 leading-normal">Multi-page structure for senior, leadership, and highly detailed tenure lists.</p>
                      </div>
                    </a>
                  </div>
                </div>
                {/* Subtle Hover Indicator bar */}
                <div className={`absolute bottom-0 left-0 right-0 h-0.5 bg-[#8cfbd4] transition-transform duration-200 ${currentView === 'builder' ? 'scale-x-100' : 'scale-x-0 group-hover:scale-x-100'}`}></div>
              </div>

              <div className="relative group">
                <a 
                  href="#builder" 
                  onClick={navigateTo('builder')} 
                  className={`hover:text-[#8cfbd4] transition-colors flex items-center gap-1 cursor-pointer py-1 ${currentView === 'builder' ? 'text-stone-900 font-bold' : ''}`}
                >
                  Resume Builder
                </a>
                <div className={`absolute bottom-0 left-0 right-0 h-0.5 bg-[#8cfbd4] transition-transform duration-200 ${currentView === 'builder' ? 'scale-x-100' : 'scale-x-0 group-hover:scale-x-100'}`}></div>
              </div>

              <div className="relative group">
                <a 
                  href="#cover-letter" 
                  onClick={navigateTo('coverletter')} 
                  className={`hover:text-[#8cfbd4] transition-colors flex items-center gap-1 cursor-pointer py-1 ${currentView === 'coverletter' ? 'text-stone-900 font-bold' : ''}`}
                >
                  Cover Letter
                </a>
                <div className={`absolute bottom-0 left-0 right-0 h-0.5 bg-[#8cfbd4] transition-transform duration-200 ${currentView === 'coverletter' ? 'scale-x-100' : 'scale-x-0 group-hover:scale-x-100'}`}></div>
              </div>

              <div className="relative group">
                <a 
                  href="#blogs" 
                  onClick={navigateTo('blogs')} 
                  className={`hover:text-[#8cfbd4] transition-colors flex items-center gap-1 cursor-pointer py-1 ${currentView === 'blogs' ? 'text-stone-900 font-bold' : ''}`}
                >
                  Blogs
                </a>
                <div className={`absolute bottom-0 left-0 right-0 h-0.5 bg-[#8cfbd4] transition-transform duration-200 ${currentView === 'blogs' ? 'scale-x-100' : 'scale-x-0 group-hover:scale-x-100'}`}></div>
              </div>
            </div>
          </div>
          
          {/* Desktop Right Buttons (Pristine SaaS Action Style) */}
          <div className="hidden md:flex items-center gap-6">
            <a 
              href="#login" 
              onClick={navigateTo('builder')} 
              className="text-[14.5px] font-medium text-stone-600 hover:text-stone-900 transition-colors cursor-pointer"
            >
              Log in
            </a>
            <button 
              onClick={navigateTo('builder')}
              className="px-5 py-2.5 bg-[#8cfbd4] text-stone-950 font-bold text-[13.5px] tracking-wide rounded-lg hover:bg-[#6ef7c0] hover:scale-[1.02] active:scale-95 transition-all shadow-xs cursor-pointer border border-[#8cfbd4] hover:border-[#6ef7c0]"
            >
              Create My Resume
            </button>
          </div>

          {/* Mobile hamburger */}
          <button className="md:hidden text-stone-950 p-2 hover:bg-stone-50 rounded-lg transition-colors" onClick={() => setMenuOpen(!menuOpen)}>
            {menuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </nav>

      {/* Mobile drawer (Refined Modern Overlay) */}
      {menuOpen && (
        <div className="fixed inset-0 z-40 bg-white flex flex-col justify-between p-8 pt-24 shadow-2xl animate-fade-in">
          {/* Nav Links */}
          <div className="flex flex-col gap-5 text-lg font-poppins font-semibold">
            <div className="py-2 border-b border-stone-105 select-none">
              <span className="text-[10px] font-mono text-stone-400 uppercase tracking-widest block mb-1">Resume Templates</span>
              <div className="flex flex-col gap-2.5 pl-2 mt-1.5">
                <a 
                  href="#templates-1-page" 
                  onClick={(e) => {
                    e.preventDefault();
                    setBuilderInitialFormat('1-page');
                    navigateTo('builder')();
                  }} 
                  className="text-stone-900 hover:text-[#8cfbd4] text-[15px] hover:font-bold py-1 flex justify-between items-center transition-all"
                >
                  <span>1-Pager Templates (Entry / Mid)</span>
                  <span className="text-[9.5px] font-mono bg-[#8cfbd4]/25 text-[#2c8d6a] px-1.5 py-0.2 rounded font-bold">1P</span>
                </a>
                <a 
                  href="#templates-2-page" 
                  onClick={(e) => {
                    e.preventDefault();
                    setBuilderInitialFormat('2-page');
                    navigateTo('builder')();
                  }} 
                  className="text-stone-900 hover:text-[#8cfbd4] text-[15px] hover:font-bold py-1 flex justify-between items-center transition-all"
                >
                  <span>2-Pager Templates (Senior / Pro)</span>
                  <span className="text-[9.5px] font-mono bg-stone-900 text-[#8cfbd4] px-1.5 py-0.2 rounded font-bold">2P</span>
                </a>
              </div>
            </div>
            <a href="#builder" onClick={navigateTo('builder')} className="text-stone-900 hover:text-[#8cfbd4] transition-colors flex justify-between items-center py-2 border-b border-stone-105">
              <span>Resume Builder</span>
              <ChevronRight size={18} className="text-stone-400" />
            </a>
            <a href="#cover-letter" onClick={navigateTo('coverletter')} className="text-stone-900 hover:text-[#8cfbd4] transition-colors flex justify-between items-center py-2 border-b border-stone-105">
              <span>Cover Letter</span>
              <ChevronRight size={18} className="text-stone-400" />
            </a>
            <a href="#blogs" onClick={navigateTo('blogs')} className="text-stone-900 hover:text-[#8cfbd4] transition-colors flex justify-between items-center py-2 border-b border-stone-105">
              <span>Blogs</span>
              <ChevronRight size={18} className="text-stone-400" />
            </a>
          </div>

          {/* Action Footer for Mobile */}
          <div className="flex flex-col gap-4 mt-8">
            <a 
              href="#login" 
              onClick={navigateTo('builder')}
              className="w-full text-center py-3 text-stone-700 font-medium hover:text-stone-900 transition-colors"
            >
              Log in
            </a>
            <button 
              onClick={navigateTo('builder')}
              className="w-full text-center py-3.5 bg-[#8cfbd4] text-stone-950 font-bold border border-[#8cfbd4] hover:bg-[#6ef7c0] hover:border-[#6ef7c0] rounded-xl shadow-md cursor-pointer text-[14.5px] uppercase tracking-wider text-center"
            >
              Create My Resume
            </button>
          </div>
        </div>
      )}

      {/* --- CONDITIONAL VIEW ROUTING --- */}
      
      {currentView === 'home' && (
        <>
          {/* Hero Header */}
          <header className="relative min-h-[92vh] flex items-center justify-center overflow-hidden pt-16 bg-[#edf8fc]">
            <HeroScene />
            
            {/* Soft Radial Ambient Layer to maintain contrast */}
            <div className="absolute inset-0 z-0 pointer-events-none bg-[radial-gradient(circle_at_center,rgba(237,248,252,0.5)_0%,rgba(237,248,252,0.85)_100%)]" />

            <div className="relative z-10 container mx-auto px-6 py-12 text-center max-w-5xl bg-white/80 backdrop-blur-md rounded-3xl border border-[#cbe6f2] shadow-xl md:p-14 my-8">
              {/* Badge */}
              <div className="inline-flex items-center gap-1.5 mb-6 px-4.5 py-1.5 border border-stone-300 text-stone-700 text-[10px] tracking-[0.25em] uppercase font-extrabold rounded-full backdrop-blur-sm bg-white/70 shadow-xs">
                ✨ NO SIGN-UPS • NO PAYWALLS • 100% FREE
              </div>
              
              {/* Main heading */}
              <h1 className="font-serif text-4xl md:text-6xl lg:text-7xl font-semibold leading-tight md:leading-[1.1] mb-6 text-stone-900 tracking-tight">
                Craft a professional <br />
                <span className="italic font-normal text-stone-600">resume over lunch.</span>
              </h1>
              
              {/* Subheading */}
              <p className="max-w-2xl mx-auto text-base md:text-lg text-stone-600 font-light leading-relaxed mb-10">
                A free, open-source, ATS-calibrated resume builder. Create, customize templates, inject premium bullet metrics, and print flawless PDFs in under 15 minutes.
              </p>
              
              {/* Primary actions */}
              <div className="flex flex-col sm:flex-row justify-center gap-3.5 mb-14">
                <button 
                  onClick={navigateTo('builder')}
                  className="px-7 py-3.5 bg-[#8cfbd4] text-stone-950 border border-[#8cfbd4] rounded-xl font-bold uppercase tracking-wider text-xs hover:bg-[#6ef7c0] hover:border-[#6ef7c0] hover:-translate-y-0.5 transition-all shadow-md cursor-pointer"
                >
                  Open Builder Sandbox
                </button>
                <a 
                  href="#optimization" 
                  onClick={scrollToSection('optimization')}
                  className="px-7 py-3.5 bg-white text-stone-800 border border-stone-250 rounded-xl font-bold uppercase tracking-wider text-xs hover:bg-stone-50 hover:-translate-y-0.5 transition-all shadow-xs cursor-pointer text-center"
                >
                  Explore AI Optimizer
                </a>
              </div>
              
              {/* Small scroll vector indicator */}
              <div className="flex justify-center">
                 <a href="#utility" onClick={scrollToSection('utility')} className="group flex flex-col items-center gap-1.5 text-xs font-mono font-bold tracking-widest text-[#8cfbd4] hover:text-stone-900 transition-colors cursor-pointer">
                    <span>CANDIDATE UTILITY</span>
                    <span className="p-2 border border-stone-250 rounded-full group-hover:border-stone-900 transition-colors bg-white/60 shadow-xs">
                        <ArrowDown size={14} />
                    </span>
                 </a>
              </div>
            </div>
          </header>

          <main>
            {/* SECTION 0.5: CANDIDATE UTILITY CORE BENCHMARKS */}
            <section id="utility" className="py-24 bg-white border-t border-stone-150 relative">
              <div className="max-w-7xl mx-auto px-6">
                
                {/* Header */}
                <div className="text-center max-w-3xl mx-auto mb-16">
                  <div className="inline-flex items-center gap-1.5 mb-3.5 px-4.5 py-1.5 border border-stone-300 text-stone-700 text-[10px] tracking-[0.25em] uppercase font-extrabold rounded-full bg-white/70 shadow-xs">
                    🛡️ CANDIDATE-FIRST MANIFESTO
                  </div>
                  <h2 className="font-space text-3xl md:text-5xl font-bold text-stone-900 tracking-tight leading-tight mb-3">
                    A True Candidate Utility
                  </h2>
                  <p className="text-[#3ea884] font-mono text-xs uppercase tracking-[0.12em] font-bold">
                    Built Strictly to Sidestep Resume Game-Playing
                  </p>
                </div>

                {/* 4 Pillars Grid (Demonstrating Elite Font Families) */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
                          {/* Pillar 1: Zero Logins Requested */}
                  <div className="p-6 bg-[#edf8fc] rounded-2xl border border-[#cbe6f2] shadow-xs hover:border-[#96daf3] hover:shadow-md transition-all duration-300 group text-left flex flex-col justify-between min-h-[225px]">
                    <div>
                      <div className="w-12 h-12 bg-stone-900 text-[#8cfbd4] rounded-xl flex items-center justify-center mb-5 group-hover:scale-105 transition-transform duration-300 shadow-sm">
                        <Lock size={20} />
                      </div>
                      <h3 className="font-sans text-lg font-bold text-stone-900 mb-2">
                        Zero Logins Requested
                      </h3>
                      <p className="text-stone-605 text-xs md:text-sm leading-relaxed font-light">
                        We never collect your phone number, email list or logins. Your work records remain privately inside your client browser.
                      </p>
                    </div>
                    <div className="mt-4 pt-2 border-t border-stone-100 flex items-center justify-between text-[10px] font-mono text-stone-400">
                      <span>TYPE PRESET</span>
                      <span className="text-[#3ea884] font-bold">Inter Sans</span>
                    </div>
                  </div>

                  {/* Pillar 2: Unlimited Free PDFs */}
                  <div className="p-6 bg-[#e7fff4] rounded-2xl border border-[#c2f7dc] shadow-xs hover:border-[#8ae8b5] hover:shadow-md transition-all duration-300 group text-left flex flex-col justify-between min-h-[225px]">
                    <div>
                      <div className="w-12 h-12 bg-stone-900 text-[#8cfbd4] rounded-xl flex items-center justify-center mb-5 group-hover:scale-105 transition-transform duration-300 shadow-sm">
                        <FileText size={20} />
                      </div>
                      <h3 className="font-elegant text-xl font-bold text-stone-900 mb-1 leading-none">
                        Unlimited Free PDFs
                      </h3>
                      <p className="text-stone-650 text-xs md:text-sm leading-relaxed font-light">
                        No locked templates or paywalls at checkout. Export clean recruiter-grade A4 layouts instantly without generic system watermarks.
                      </p>
                    </div>
                    <div className="mt-4 pt-2 border-t border-stone-100 flex items-center justify-between text-[10px] font-mono text-stone-400">
                      <span>TYPE PRESET</span>
                      <span className="text-stone-800 font-bold font-elegant">EB Garamond</span>
                    </div>
                  </div>

                  {/* Pillar 3: ATS Match-Verified */}
                  <div className="p-6 bg-[#e7fff4] rounded-2xl border border-[#c2f7dc] shadow-xs hover:border-[#8ae8b5] hover:shadow-md transition-all duration-300 group text-left flex flex-col justify-between min-h-[225px]">
                    <div>
                      <div className="w-12 h-12 bg-stone-900 text-[#8cfbd4] rounded-xl flex items-center justify-center mb-5 group-hover:scale-105 transition-transform duration-300 shadow-sm">
                        <ShieldCheck size={20} />
                      </div>
                      <h3 className="font-space text-lg font-bold text-stone-900 mb-2">
                        ATS Match-Verified
                      </h3>
                      <p className="text-stone-605 text-xs md:text-sm leading-relaxed font-light">
                        Our single-column layout structures strictly avoid parser-breaking elements (complex canvas widgets, side columns, text boxes).
                      </p>
                    </div>
                    <div className="mt-4 pt-2 border-t border-stone-100 flex items-center justify-between text-[10px] font-mono text-stone-400">
                      <span>TYPE PRESET</span>
                      <span className="text-stone-800 font-bold font-space">Space Grotesk</span>
                    </div>
                  </div>

                  {/* Pillar 4: Google XYZ AI Tuning */}
                  <div className="p-6 bg-[#e7fff4] rounded-2xl border border-[#c2f7dc] shadow-xs hover:border-[#8ae8b5] hover:shadow-md transition-all duration-300 group text-left flex flex-col justify-between min-h-[225px]">
                    <div>
                      <div className="w-12 h-12 bg-stone-900 text-[#8cfbd4] rounded-xl flex items-center justify-center mb-5 group-hover:scale-105 transition-transform duration-300 shadow-sm">
                        <Sparkles size={20} />
                      </div>
                      <h3 className="font-outfit text-lg font-bold text-stone-900 mb-2">
                        Google XYZ AI Tuning
                      </h3>
                      <p className="text-stone-605 text-xs md:text-sm leading-relaxed font-light">
                        We proxy secure server-side calls utilizing Gemini to review metric-oriented achievements, replacing weak logs with strong output ratios.
                      </p>
                    </div>
                    <div className="mt-4 pt-2 border-t border-stone-100 flex items-center justify-between text-[10px] font-mono text-stone-400">
                      <span>TYPE PRESET</span>
                      <span className="text-stone-800 font-bold font-outfit">Outfit Modern</span>
                    </div>
                  </div>
                </div>

                {/* 1-pager & 2-pager Dedicated Interactive Selector split */}
                <div className="mb-20">
                  <div className="text-center max-w-2xl mx-auto mb-10">
                    <span className="inline-block px-2.5 py-0.5 bg-[#8cfbd4]/15 border border-[#8cfbd4]/30 text-[#2c8d6a] text-[10px] font-mono tracking-widest font-bold uppercase rounded-full mb-2">
                      FLEXIBLE LAYOUTS FOR ALL EXPERIENCE LIMITS
                    </span>
                    <h3 className="font-space text-2xl md:text-3.5xl font-bold text-stone-900 mb-2">
                      Select Your Layout Target Format
                    </h3>
                    <p className="text-stone-600 text-sm font-light leading-relaxed">
                      Losing recruiter attention via broken second-page overflows is a critical failure. Pre-select a custom layout optimized explicitly for your level of professional duration:
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* card 1: 1-pager */}
                    <div className="bg-white p-7 rounded-2xl border border-stone-200 hover:border-[#8cfbd4] hover:shadow-lg transition-all duration-300 text-left flex flex-col justify-between relative group">
                      <div className="absolute top-4 right-6 text-6xl font-black text-stone-100 group-hover:text-[#8cfbd4]/10 transition-colors pointer-events-none select-none font-sans">
                        1P
                      </div>
                      <div>
                        <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 bg-emerald-50 text-emerald-700 text-[9px] font-mono font-bold uppercase rounded mb-3 border border-emerald-100">
                          ENTRY &amp; MID LEVEL
                        </div>
                        <h4 className="font-space text-lg font-bold text-stone-900 mb-2">
                          1-Pager Resume Templates
                        </h4>
                        <p className="text-stone-500 text-xs md:text-sm leading-relaxed font-light mb-6">
                          Strictly configured layout template to fit your education and initial tenures safely onto one high-density page. Auto-compact spacing prevents accidental white breaks and watermarks, keeping recruiters visually focused on core merits. Best for under 5 years experience.
                        </p>
                      </div>
                      <button
                        onClick={() => {
                          setBuilderInitialFormat('1-page');
                          navigateTo('builder')();
                        }}
                        className="w-full py-3 bg-[#8cfbd4]/10 hover:bg-[#8cfbd4] text-stone-900 font-bold text-xs uppercase tracking-wider rounded-xl transition-all border border-[#8cfbd4]/20 hover:border-[#8cfbd4] cursor-pointer"
                      >
                        Choose 1-Pager Templates
                      </button>
                    </div>

                    {/* card 2: 2-pager */}
                    <div className="bg-white p-7 rounded-2xl border border-stone-200 hover:border-stone-900 hover:shadow-lg transition-all duration-300 text-left flex flex-col justify-between relative group">
                      <div className="absolute top-4 right-6 text-6xl font-black text-stone-100 group-hover:text-stone-200/55 transition-colors pointer-events-none select-none font-sans">
                        2P
                      </div>
                      <div>
                        <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 bg-stone-100 text-stone-800 text-[9px] font-mono font-bold uppercase rounded mb-3 border border-stone-200">
                          SENIOR &amp; LEADERSHIP
                        </div>
                        <h4 className="font-space text-lg font-bold text-stone-900 mb-2">
                          2-Pager Resume Templates
                        </h4>
                        <p className="text-stone-500 text-xs md:text-sm leading-relaxed font-light mb-6">
                          Engineered for profiles with extensive work records (5+ years). Automatically sets up spacing constraints, visual page division fold markers, and balanced alignment elements so your second page printed results look pristine and highly calibrated.
                        </p>
                      </div>
                      <button
                        onClick={() => {
                          setBuilderInitialFormat('2-page');
                          navigateTo('builder')();
                        }}
                        className="w-full py-3 bg-stone-900 hover:bg-stone-850 text-[#8cfbd4] font-bold text-xs uppercase tracking-wider rounded-xl transition-all border border-stone-950 cursor-pointer"
                      >
                        Choose 2-Pager Templates
                      </button>
                    </div>
                  </div>
                </div>

                {/* 3 Steps Roadmap */}
                <div className="border-t border-stone-150 pt-20">
                  <div className="text-center max-w-3xl mx-auto mb-16">
                    <span className="inline-block px-3 py-1 bg-stone-105 border border-stone-200 text-stone-700 text-[10px] tracking-widest font-mono font-bold uppercase rounded-full mb-3 shadow-xs">
                      ⏱️ 15-MINUTE EXPORT
                    </span>
                    <h3 className="font-space text-2xl md:text-3.5xl font-bold text-stone-900 leading-tight mb-2">
                      Fast Recruiter Setup
                    </h3>
                    <p className="text-stone-500 font-mono text-xs uppercase tracking-wider">
                      How to Build, Calibrate &amp; Export in 3 Steps
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    
                    {/* Step 1 */}
                    <div className="text-left relative p-7 bg-white rounded-2xl border border-stone-200 hover:border-stone-350 hover:shadow-sm transition-all duration-300 group">
                      <div className="absolute top-4 right-6 text-5xl font-extrabold text-stone-200/50 font-mono group-hover:text-[#8cfbd4]/30 pointer-events-none transition-colors duration-300">
                        01
                      </div>
                      <div className="w-9 h-9 bg-stone-950 text-[#8cfbd4] rounded-full flex items-center justify-center font-bold text-sm mb-6 font-mono border border-stone-850 shadow-sm">
                        1
                      </div>
                      <h4 className="font-serif text-lg font-bold text-stone-900 mb-2.5">
                        Select Your Template
                      </h4>
                      <p className="text-stone-600 text-xs md:text-sm leading-relaxed font-light">
                        Pick from our list of 6 free, ATS-validated designs. Switch between lookups at any stage without losing a single character.
                      </p>
                    </div>

                    {/* Step 2 */}
                    <div className="text-left relative p-7 bg-white rounded-2xl border border-stone-200 hover:border-stone-350 hover:shadow-sm transition-all duration-300 group">
                      <div className="absolute top-4 right-6 text-5xl font-extrabold text-stone-200/50 font-mono group-hover:text-[#8cfbd4]/30 pointer-events-none transition-colors duration-300">
                        02
                      </div>
                      <div className="w-9 h-9 bg-stone-950 text-[#8cfbd4] rounded-full flex items-center justify-center font-bold text-sm mb-6 font-mono border border-stone-850 shadow-sm">
                        2
                      </div>
                      <h4 className="font-serif text-lg font-bold text-stone-900 mb-2.5">
                        Fill Up Experience Bullets
                      </h4>
                      <p className="text-stone-600 text-xs md:text-sm leading-relaxed font-light">
                        Input your work history, skills, and details. Prefill with standard developer or marketer examples on a single click.
                      </p>
                    </div>

                    {/* Step 3 */}
                    <div className="text-left relative p-7 bg-white rounded-2xl border border-stone-200 hover:border-stone-350 hover:shadow-sm transition-all duration-300 group">
                      <div className="absolute top-4 right-6 text-5xl font-extrabold text-stone-200/50 font-mono group-hover:text-[#8cfbd4]/30 pointer-events-none transition-colors duration-300">
                        03
                      </div>
                      <div className="w-9 h-9 bg-stone-950 text-[#8cfbd4] rounded-full flex items-center justify-center font-bold text-sm mb-6 font-mono border border-stone-850 shadow-sm">
                        3
                      </div>
                      <h4 className="font-serif text-lg font-bold text-stone-900 mb-2.5">
                        Run critique &amp; Download
                      </h4>
                      <p className="text-stone-600 text-xs md:text-sm leading-relaxed font-light">
                        Generate instant AI critique to rewrite weak bullets with high-impact action ratios, then hit Export to generate A4 print preview.
                      </p>
                    </div>

                  </div>
                </div>

              </div>
            </section>

            {/* SECTION 1: THE NOISE BARRIER */}
            <section id="about" className="py-24 bg-white border-t border-stone-150">
              <div className="container mx-auto px-6 md:px-12 grid grid-cols-1 md:grid-cols-12 gap-12 items-center">
                
                <div className="md:col-span-5">
                  <div className="inline-block mb-3 text-[10px] font-bold tracking-widest text-stone-400 uppercase font-mono">The Recruitment Funnel</div>
                  <h2 className="font-serif text-3xl md:text-4xl mb-6 leading-tight text-stone-900">The Hiring Noise Barrier</h2>
                  <div className="w-16 h-1 bg-[#8cfbd4] mb-6"></div>
                  
                  <div className="p-4 bg-stone-50 rounded-xl border border-stone-200 text-xs font-mono tracking-wide text-stone-500 space-y-2">
                    <div>📊 Recruiter study index:</div>
                    <div className="text-stone-800 font-bold text-sm">💡 Six seconds standard response</div>
                    <p className="leading-relaxed">That's the average timeframe a human reviewer spends on your profile before decisioning a binary path.</p>
                  </div>
                </div>

                <div className="md:col-span-7 text-sm md:text-base text-stone-600 leading-relaxed space-y-6 text-left">
                  <p className="text-lg text-stone-850">
                    <span className="text-5xl float-left mr-3 mt-[-8px] font-serif text-[#8cfbd4] font-normal">S</span>tanding out doesn't require crazy color swirls or multi-column graphical bars. In fact, complex graphics often confuse the <strong>Applicant Tracking Systems (ATS)</strong> that crawl databases before a human ever looks at them.
                  </p>
                  <p>
                    What guarantees an interview callback is <strong>readability (strict visual hierarchy)</strong> combined with <strong>metrics-driven contributions</strong>.
                  </p>
                  <p>
                    The LunchResume formula has been coengineered to ensure your file loads cleanly into standard parser frameworks while structuring information to capture immediate attention during that critical six-second window.
                  </p>
                </div>

              </div>
            </section>

            {/* SECTION 2: THE DECODER & OPTIMIZER */}
            <section id="optimization" className="py-24 bg-white border-t border-stone-150">
              <div className="container mx-auto px-6">
                <InteractiveOptimizer />
              </div>
            </section>

            {/* SECTION 3: RECRUITER CALLBACKS COMPARATIVES */}
            <section className="py-24 bg-stone-950 text-white relative overflow-hidden">
              {/* Subtle decoration vectors */}
              <div className="absolute top-0 right-0 w-80 h-80 rounded-full bg-stone-800/20 blur-[90px] pointer-events-none"></div>
              <div className="absolute bottom-0 left-0 w-80 h-80 rounded-full bg-[#8cfbd4]/10 blur-[90px] pointer-events-none"></div>

              <div className="container mx-auto px-6 relative z-10">
                <div className="max-w-4xl mx-auto">
                  <PerformanceMetricDiagram />
                </div>
              </div>
            </section>

            {/* SECTION 4: MANIFESTO & SYSTEM ARCHIPELAGO */}
            <section id="manifesto" className="py-24 bg-white border-t border-stone-150 relative">
              <div className="container mx-auto px-6 grid grid-cols-1 lg:grid-cols-12 gap-16 items-center">
                
                {/* Left Column: Visual stacking cards representing CV standard templates */}
                <div className="lg:col-span-5 relative aspect-square bg-[#F7F6F2] rounded-2xl overflow-hidden border border-stone-200 flex items-center justify-center">
                  <QuantumComputerScene />
                  <div className="absolute bottom-4 left-0 right-0 text-center text-[10px] text-stone-500 font-mono uppercase tracking-widest bg-white/70 backdrop-blur-sm py-1.5 mx-8 rounded-lg border border-stone-200">
                    ⚡ Real-time Layout Engine Presets
                  </div>
                </div>

                {/* Right Column: Narrative manifesto */}
                <div className="lg:col-span-7 flex flex-col justify-center text-left">
                  <div className="inline-flex items-center gap-1 text-[10px] font-bold tracking-widest text-[#8cfbd4] uppercase font-mono mb-3">
                    <Heart size={12} className="text-rose-500" /> Transparent commitment
                  </div>
                  <h2 className="font-serif text-3xl md:text-4xl mb-6 text-stone-950 leading-tight">Why is LunchResume 100% Free?</h2>
                  
                  <div className="space-y-5 text-stone-600 text-sm leading-relaxed">
                    <p>
                      Most \"free\" resume builders lure you in under the guise of zero costs, wait for you to spend 60 minutes typing your entire employment history, and then lock your download behind an unavoidable $19.99 monthly subscription paywall. We think that is exhausting and highly predatory for people actively seeking opportunities.
                    </p>
                    <p>
                      <strong>LunchResume is built differently:</strong>
                    </p>
                    <ul className="space-y-3 pl-1 font-sans">
                      <li className="flex items-start gap-2">
                        <CheckCircle size={15} className="text-emerald-500 shrink-0 mt-0.5" />
                        <span><strong>No Hidden Credit Cards:</strong> You will never be asked to write financial fields to obtain your layout files.</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle size={15} className="text-emerald-500 shrink-0 mt-0.5" />
                        <span><strong>Security by default:</strong> Your personal data runs locally directly inside your browser cache. Zero servers storing your contact details.</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <CheckCircle size={15} className="text-emerald-500 shrink-0 mt-0.5" />
                        <span><strong>100% Clean Code files:</strong> Produced outcomes are completely standard semantic HTML text blocks, ensuring absolute ATS compatibility.</span>
                      </li>
                    </ul>

                    <p className="mt-4 pt-4 border-t border-stone-100 italic text-stone-500">
                      Supported purely by voluntary tips, community donations, and software developers contributing open-source components during their lunch hours.
                    </p>
                  </div>
                </div>

              </div>
            </section>

            {/* SECTION 5: FAQS */}
            <section id="faqs" className="py-20 bg-white border-t border-stone-200">
              <div className="container mx-auto px-6 max-w-4xl">
                <h3 className="font-serif text-2xl md:text-3.5xl text-center mb-12 text-stone-900">Frequently Asked Questions</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-left">
                  <div>
                    <h4 className="font-bold text-stone-900 text-base mb-2 flex items-center gap-1.5"><HelpCircle size={15} className="text-[#8cfbd4]" /> Are these files ATS-friendly?</h4>
                    <p className="text-stone-600 text-xs md:text-sm leading-relaxed">
                      Yes, thoroughly. Most applicant tracking tools crawl the raw PDF text nodes. Our templates avoid complex floating graphics and columns that typically corrupt text flows in generic design builders, guaranteeing maximum parsing scores.
                    </p>
                  </div>

                  <div>
                    <h4 className="font-bold text-stone-900 text-base mb-2 flex items-center gap-1.5"><HelpCircle size={15} className="text-[#8cfbd4]" /> Where is my information stored?</h4>
                    <p className="text-stone-600 text-xs md:text-sm leading-relaxed">
                      Nowhere but your current device browser. We run a fully sandboxed client-side compilation model. Your inputs never touch external clouds, preventing risk of private data scraping or sales.
                    </p>
                  </div>

                  <div>
                    <h4 className="font-bold text-stone-900 text-base mb-2 flex items-center gap-1.5"><HelpCircle size={15} className="text-[#8cfbd4]" /> How do I download as PDF?</h4>
                    <p className="text-[#111] text-xs md:text-sm leading-relaxed">
                      Click the <strong>PDF Print</strong> button on the top-right. Standard print styles configure the page into flawless, high-resolution printable grids. You can choose "Save as PDF" directly in your browser's print dialog!
                    </p>
                  </div>

                  <div>
                    <h4 className="font-bold text-stone-900 text-base mb-2 flex items-center gap-1.5"><HelpCircle size={15} className="text-[#8cfbd4]" /> Can I write custom sections?</h4>
                    <p className="text-stone-600 text-xs md:text-sm leading-relaxed">
                      You can edit, add, and remove experiences or projects instantaneously. Our flexible fields allow adapting any text slot or tagging specific skills on-the-fly.
                    </p>
                  </div>
                </div>
              </div>
            </section>
          </main>
        </>
      )}

      {currentView === 'builder' && (
        <div className="pt-28 pb-20 max-w-7xl mx-auto px-4 sm:px-6">
          <div className="max-w-3xl mx-auto text-center mb-10">
            <div className="inline-flex items-center gap-1.5 mb-3 px-3 py-1 bg-[#8cfbd4]/10 text-stone-800 text-[10px] tracking-widest uppercase font-extrabold rounded-full border border-[#8cfbd4]/20">
              🛠️ RESUME WORKSPACE
            </div>
            <h1 className="font-serif text-3xl md:text-5xl text-stone-900 mb-4 font-normal">Playground Editor Sandbox</h1>
            <p className="text-stone-600 text-sm md:text-base leading-relaxed">
              Click on the preset industry profiles to instant-fill the form, then customize colors, spacing, and content. Click <strong>PDF Print</strong> to calibrate your printable profile file.
            </p>
          </div>
          
          {/* Main workspace */}
          <ResumeBuilderSandbox initialFormat={builderInitialFormat} />
        </div>
      )}

      {currentView === 'coverletter' && (
        <div className="pt-28 pb-20 max-w-7xl mx-auto px-4 sm:px-6">
          <div className="max-w-3xl mx-auto text-center mb-10">
            <div className="inline-flex items-center gap-1.5 mb-3 px-3 py-1 bg-[#8cfbd4]/10 text-stone-800 text-[10px] tracking-widest uppercase font-extrabold rounded-full border border-[#8cfbd4]/20">
              ✉️ COVER LETTER GENERATOR
            </div>
            <h1 className="font-serif text-3xl md:text-5xl text-stone-900 mb-4 font-normal">Cover Letter Workspace</h1>
            <p className="text-stone-600 text-sm md:text-base leading-relaxed">
              Draft outcomes-focused cover letters aligned perfectly to your resume branding. Select an industry profile, write custom outcomes, and print your matching PDF file.
            </p>
          </div>
          
          {/* Cover letter builder */}
          <CoverLetterSandbox />
        </div>
      )}

      {currentView === 'blogs' && (
        <div className="pt-28 pb-24 max-w-7xl mx-auto px-6">
          <div className="max-w-3xl mx-auto text-center mb-16">
            <div className="inline-flex items-center gap-1.5 mb-3 px-3 py-1 bg-[#8cfbd4]/10 text-stone-800 text-[10px] tracking-widest uppercase font-extrabold rounded-full border border-[#8cfbd4]/20">
              📚 RECRUITER INSIGHTS BLOGS
            </div>
            <h1 className="font-serif text-3xl md:text-5xl text-stone-900 mb-4 font-normal">The LunchResume Library</h1>
            <p className="text-stone-600 text-sm md:text-base leading-relaxed">
              Actionable guides on navigating ATS algorithm filters, structuring quantified accomplishments, and commanding attention in under six seconds.
            </p>
          </div>

          {selectedBlogId ? (
            // Full article reading view
            (() => {
              const post = BLOG_POSTS.find(p => p.id === selectedBlogId);
              if (!post) return null;
              return (
                <div className="max-w-3xl mx-auto bg-white border border-stone-200 rounded-2xl p-6 sm:p-12 shadow-sm text-left">
                  <button 
                    onClick={() => setSelectedBlogId(null)}
                    className="inline-flex items-center gap-2 text-xs font-mono font-bold text-stone-500 hover:text-stone-900 transition-colors uppercase mb-8"
                  >
                    <ArrowLeft size={14} /> Back to Insights
                  </button>
                  
                  <div className="flex items-center gap-2 text-xs font-mono font-bold text-[#3ea884] uppercase mb-4">
                    <span>{post.category}</span>
                    <span>•</span>
                    <span>{post.readTime}</span>
                  </div>

                  <h2 className="font-serif text-3xl sm:text-4.5xl text-stone-900 leading-tight mb-6 font-bold">{post.title}</h2>
                  
                  <div className="border-b border-stone-100 pb-4 mb-8 text-stone-400 text-xs font-mono">
                    Published: {post.date}
                  </div>

                  <div className="prose prose-stone prose-sm max-w-none text-stone-700 leading-relaxed text-sm whitespace-pre-line space-y-6">
                    {post.content}
                  </div>

                  <div className="mt-12 pt-8 border-t border-stone-150 flex justify-between items-center bg-stone-50 p-6 rounded-xl border border-stone-200">
                    <div>
                      <h4 className="font-serif text-base text-stone-900 font-bold mb-1">Empowered to calibrate?</h4>
                      <p className="text-stone-500 text-xs">Load standard, highly parseable profiles directly inside our free editor.</p>
                    </div>
                    <button 
                      onClick={navigateTo('builder')}
                      className="px-4 py-2.5 bg-[#8cfbd4] text-stone-950 font-bold text-xs uppercase tracking-wider rounded-lg hover:bg-[#6ef7c0] transition-all"
                    >
                      Open Creator Sandbox
                    </button>
                  </div>
                </div>
              );
            })()
          ) : (
            // Grid representation
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {BLOG_POSTS.map((post) => (
                <div 
                  key={post.id} 
                  className="bg-white rounded-2xl border border-stone-200/80 p-6 shadow-xs flex flex-col justify-between hover:shadow-md hover:border-stone-300 transition-all text-left"
                >
                  <div>
                    <div className="flex items-center gap-2 text-[10px] font-mono font-bold text-[#3ea884] uppercase mb-3.5">
                      <span>{post.category}</span>
                      <span>•</span>
                      <span>{post.readTime}</span>
                    </div>
                    <h3 className="font-serif text-xl font-bold text-stone-900 mb-3 hover:text-stone-750 cursor-pointer" onClick={() => setSelectedBlogId(post.id)}>
                      {post.title}
                    </h3>
                    <p className="text-stone-500 text-xs leading-relaxed mb-6">
                      {post.excerpt}
                    </p>
                  </div>
                  <button 
                    onClick={() => setSelectedBlogId(post.id)}
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-[#2a8767] hover:text-[#1d6148] transition-colors mt-auto font-mono uppercase tracking-wider text-left"
                  >
                    Read article <ChevronRight size={14} />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* FOOTER */}
      <footer className="bg-stone-900 text-stone-400 py-16 border-t border-stone-850">
        <div className="container mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-8">
            <div className="text-center md:text-left">
                <div className="text-white font-serif font-bold text-xl mb-2 tracking-wide cursor-pointer" onClick={navigateTo('home')}>
                  LUNCH<span className="text-[#8cfbd4]">RESUME</span>
                </div>
                <p className="text-xs text-stone-400 max-w-xs">Elevate your career credentials over lunch. Clear layouts, metric outcomes, zero costs.</p>
            </div>
            
            <div className="flex gap-4 text-xs font-mono justify-center items-center flex-wrap">
              <button onClick={navigateTo('home')} className="hover:text-white transition-colors">Home</button>
              <span>•</span>
              <button onClick={navigateTo('builder')} className="hover:text-white transition-colors">Resume Builder</button>
              <span>•</span>
              <button onClick={navigateTo('coverletter')} className="hover:text-white transition-colors">Cover Letter</button>
              <span>•</span>
              <button onClick={navigateTo('blogs')} className="hover:text-white transition-colors">Blogs insights</button>
            </div>
        </div>
        
        {/* Verification Seals */}
        <div className="container mx-auto px-6 mt-8 pt-8 border-t border-stone-850 flex flex-col sm:flex-row justify-between items-center gap-4 text-[11px] text-stone-500">
          <div className="flex items-center gap-1.5">
            <ShieldCheck size={14} className="text-[#8cfbd4]" />
            <span>Browser Sandboxed Security Certified</span>
          </div>
          <div className="text-center sm:text-right">
            <span>© 2026 LunchResume. Built for lunchresume.com. All Rights Reserved.</span>
          </div>
        </div>
      </footer>

    </div>
  );
};

export default App;
